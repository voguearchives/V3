#pragma once

#include "inner.h"

//void sample_mlp(const std::string &data_dir);

void sample_cnn(const std::string &data_dir);
void sample_cnn_mnist(const std::string &data_dir);