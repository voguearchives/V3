#pragma once

#include "fit_config"
#include <math21_c.h>

//#include "../../include/net_ori.h"
#include <net_ori.h>
#include "../src/print/files.h"

#ifdef __cplusplus
extern "C" {
#endif


NumB math21_ml_is_function_paras_file(const char *filename);

#ifdef __cplusplus
}
#endif
