#include "activation_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

layer make_activation_layer(int batch, int inputs, ACTIVATION activation)
{
    layer l = {0};
    l.type = ACTIVE;

    l.inputs = inputs;
    l.outputs = inputs;
    l.batch=batch;

    l.output = math21_ml_net_io_calloc(batch*inputs, sizeof(float*));
    l.delta = math21_ml_net_io_calloc(batch*inputs, sizeof(float*));

    l.forward = forward_activation_layer;
    l.backward = backward_activation_layer;
#ifdef GPU
    l.forward_gpu = forward_activation_layer_gpu;
    l.backward_gpu = backward_activation_layer_gpu;

    l.output_gpu = math21_cuda_make_vector_from_cpu(l.output, inputs*batch);
    l.delta_gpu = math21_cuda_make_vector_from_cpu(l.delta, inputs*batch);
#endif
    l.activation = activation;
    fprintf(stderr, "Activation Layer: %d inputs\n", inputs);
    return l;
}

void forward_activation_layer(layer l, network net)
{
    math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, net.input, 1, l.output, 1);
    math21_ml_net_activation_vector_cpu(l.output, l.outputs*l.batch, l.activation);
}

void backward_activation_layer(layer l, network net)
{
    math21_ml_net_activation_gradient_vector_cpu(l.output, l.outputs*l.batch, l.activation, l.delta);
    math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.delta, 1, net.delta, 1);
}

#ifdef GPU

void forward_activation_layer_gpu(layer l, network net)
{
    math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, net.input_gpu, 1, l.output_gpu, 1);
    math21_ml_net_activation_vector_gpu(l.output_gpu, l.outputs*l.batch, l.activation);
}

void backward_activation_layer_gpu(layer l, network net)
{
    math21_ml_net_activation_gradient_vector_gpu(l.output_gpu, l.outputs*l.batch, l.activation, l.delta_gpu);
    math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.delta_gpu, 1, net.delta_gpu, 1);
}
#endif
