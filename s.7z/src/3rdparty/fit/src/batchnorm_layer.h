#ifndef BATCHNORM_LAYER_H
#define BATCHNORM_LAYER_H

#include "image.h"
#include "layer.h"
#include "network.h"

layer math21_ml_net_batch_normalization_layer_create(int batch, int w, int h, int c);
void math21_ml_net_batchnorm_layer_forward(layer l, network net);
void math21_ml_net_batchnorm_layer_backward(layer l, network net);

#ifdef GPU
void math21_ml_net_batchnorm_layer_forward_gpu(layer l, network net);
void math21_ml_net_batchnorm_layer_backward_gpu(layer l, network net);
void pull_batchnorm_layer(layer l);
void push_batchnorm_layer(layer l);
#endif

#endif
