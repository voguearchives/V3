#include "gru_layer.h"
#include "connected_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void increment_layer(layer *l, int steps)
{
    int num = l->outputs*l->batch*steps;
    l->output += num;
    l->delta += num;
    l->x += num;
    l->x_norm += num;

#ifdef GPU
    l->output_gpu += num;
    l->delta_gpu += num;
    l->x_gpu += num;
    l->x_norm_gpu += num;
#endif
}

layer make_gru_layer(int batch, int inputs, int outputs, int steps, int batch_normalize, int adam)
{
    fprintf(stderr, "GRU Layer: %d inputs, %d outputs\n", inputs, outputs);
    batch = batch / steps;
    layer l = {0};
    l.batch = batch;
    l.type = GRU;
    l.steps = steps;
    l.inputs = inputs;

    l.uz = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.uz) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.uz->batch = batch;

    l.wz = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wz) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wz->batch = batch;

    l.ur = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.ur) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.ur->batch = batch;

    l.wr = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wr) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wr->batch = batch;



    l.uh = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.uh) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.uh->batch = batch;

    l.wh = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wh) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wh->batch = batch;

    l.batch_normalize = batch_normalize;


    l.outputs = outputs;
    l.output = math21_vector_calloc_cpu(outputs*batch*steps, sizeof(float));
    l.delta = math21_vector_calloc_cpu(outputs*batch*steps, sizeof(float));
    l.state = math21_vector_calloc_cpu(outputs*batch, sizeof(float));
    l.prev_state = math21_vector_calloc_cpu(outputs*batch, sizeof(float));
    l.forgot_state = math21_vector_calloc_cpu(outputs*batch, sizeof(float));
    l.forgot_delta = math21_vector_calloc_cpu(outputs*batch, sizeof(float));

    l.r_cpu = math21_vector_calloc_cpu(outputs*batch, sizeof(float));
    l.z_cpu = math21_vector_calloc_cpu(outputs*batch, sizeof(float));
    l.h_cpu = math21_vector_calloc_cpu(outputs*batch, sizeof(float));

    l.forward = forward_gru_layer;
    l.backward = backward_gru_layer;
    l.update = update_gru_layer;

#ifdef GPU
    l.forward_gpu = forward_gru_layer_gpu;
    l.backward_gpu = backward_gru_layer_gpu;
    l.update_gpu = update_gru_layer_gpu;

    l.forgot_state_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.forgot_delta_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.prev_state_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.state_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.output_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs*steps);
    l.delta_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs*steps);
    l.r_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.z_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.h_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);

#endif

    return l;
}

void update_gru_layer(layer l, update_args a)
{
    math21_ml_net_fully_connected_layer_update(*(l.ur), a);
    math21_ml_net_fully_connected_layer_update(*(l.uz), a);
    math21_ml_net_fully_connected_layer_update(*(l.uh), a);
    math21_ml_net_fully_connected_layer_update(*(l.wr), a);
    math21_ml_net_fully_connected_layer_update(*(l.wz), a);
    math21_ml_net_fully_connected_layer_update(*(l.wh), a);
}

void forward_gru_layer(layer l, network net)
{
    network s = net;
    s.train = net.train;
    int i;
    layer uz = *(l.uz);
    layer ur = *(l.ur);
    layer uh = *(l.uh);

    layer wz = *(l.wz);
    layer wr = *(l.wr);
    layer wh = *(l.wh);

    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, uz.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, ur.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, uh.delta, 1);

    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wz.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wr.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wh.delta, 1);
    if(net.train) {
        math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, l.delta, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state, 1, l.prev_state, 1);
    }

    for (i = 0; i < l.steps; ++i) {
        s.input = l.state;
        math21_ml_net_fully_connected_layer_forward(wz, s);
        math21_ml_net_fully_connected_layer_forward(wr, s);

        s.input = net.input;
        math21_ml_net_fully_connected_layer_forward(uz, s);
        math21_ml_net_fully_connected_layer_forward(ur, s);
        math21_ml_net_fully_connected_layer_forward(uh, s);


        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uz.output, 1, l.z_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wz.output, 1, l.z_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, ur.output, 1, l.r_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wr.output, 1, l.r_cpu, 1);

        math21_ml_net_activation_vector_cpu(l.z_cpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_cpu(l.r_cpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state, 1, l.forgot_state, 1);
        mul_cpu(l.outputs*l.batch, l.r_cpu, 1, l.forgot_state, 1);

        s.input = l.forgot_state;
        math21_ml_net_fully_connected_layer_forward(wh, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uh.output, 1, l.h_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wh.output, 1, l.h_cpu, 1);

        if(l.tanh){
            math21_ml_net_activation_vector_cpu(l.h_cpu, l.outputs*l.batch, TANH);
        } else {
            math21_ml_net_activation_vector_cpu(l.h_cpu, l.outputs*l.batch, LOGISTIC);
        }

        weighted_sum_cpu(l.state, l.h_cpu, l.z_cpu, l.outputs*l.batch, l.output);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output, 1, l.state, 1);

        net.input += l.inputs*l.batch;
        l.output += l.outputs*l.batch;
        increment_layer(&uz, 1);
        increment_layer(&ur, 1);
        increment_layer(&uh, 1);

        increment_layer(&wz, 1);
        increment_layer(&wr, 1);
        increment_layer(&wh, 1);
    }
}

void backward_gru_layer(layer l, network net)
{
}

#ifdef GPU

void pull_gru_layer(layer l)
{
}

void push_gru_layer(layer l)
{
}

void update_gru_layer_gpu(layer l, update_args a)
{
    math21_ml_net_fully_connected_layer_update_gpu(*(l.ur), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.uz), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.uh), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wr), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wz), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wh), a);
}

void forward_gru_layer_gpu(layer l, network net)
{
    network s = {0};
    s.train = net.train;
    int i;
    layer uz = *(l.uz);
    layer ur = *(l.ur);
    layer uh = *(l.uh);

    layer wz = *(l.wz);
    layer wr = *(l.wr);
    layer wh = *(l.wh);

    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, uz.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, ur.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, uh.delta_gpu, 1);

    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wz.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wr.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wh.delta_gpu, 1);
    if(net.train) {
        math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, l.delta_gpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state_gpu, 1, l.prev_state_gpu, 1);
    }

    for (i = 0; i < l.steps; ++i) {
        s.input_gpu = l.state_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(wz, s);
        math21_ml_net_fully_connected_layer_forward_gpu(wr, s);

        s.input_gpu = net.input_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(uz, s);
        math21_ml_net_fully_connected_layer_forward_gpu(ur, s);
        math21_ml_net_fully_connected_layer_forward_gpu(uh, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uz.output_gpu, 1, l.z_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wz.output_gpu, 1, l.z_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, ur.output_gpu, 1, l.r_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wr.output_gpu, 1, l.r_gpu, 1);

        math21_ml_net_activation_vector_gpu(l.z_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.r_gpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state_gpu, 1, l.forgot_state_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.r_gpu, 1, l.forgot_state_gpu, 1);

        s.input_gpu = l.forgot_state_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(wh, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uh.output_gpu, 1, l.h_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wh.output_gpu, 1, l.h_gpu, 1);

        if(l.tanh){
            math21_ml_net_activation_vector_gpu(l.h_gpu, l.outputs*l.batch, TANH);
        } else {
            math21_ml_net_activation_vector_gpu(l.h_gpu, l.outputs*l.batch, LOGISTIC);
        }

        weighted_sum_gpu(l.state_gpu, l.h_gpu, l.z_gpu, l.outputs*l.batch, l.output_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output_gpu, 1, l.state_gpu, 1);

        net.input_gpu += l.inputs*l.batch;
        l.output_gpu += l.outputs*l.batch;
        increment_layer(&uz, 1);
        increment_layer(&ur, 1);
        increment_layer(&uh, 1);

        increment_layer(&wz, 1);
        increment_layer(&wr, 1);
        increment_layer(&wh, 1);
    }
}

void backward_gru_layer_gpu(layer l, network net)
{
    network s = {0};
    s.train = net.train;
    int i;
    layer uz = *(l.uz);
    layer ur = *(l.ur);
    layer uh = *(l.uh);

    layer wz = *(l.wz);
    layer wr = *(l.wr);
    layer wh = *(l.wh);

    increment_layer(&uz, l.steps - 1);
    increment_layer(&ur, l.steps - 1);
    increment_layer(&uh, l.steps - 1);

    increment_layer(&wz, l.steps - 1);
    increment_layer(&wr, l.steps - 1);
    increment_layer(&wh, l.steps - 1);

    net.input_gpu += l.inputs*l.batch*(l.steps-1);
    if(net.delta_gpu) net.delta_gpu += l.inputs*l.batch*(l.steps-1);
    l.output_gpu += l.outputs*l.batch*(l.steps-1);
    l.delta_gpu += l.outputs*l.batch*(l.steps-1);
    float *end_state = l.output_gpu;
    for (i = l.steps-1; i >= 0; --i) {
        if(i != 0) math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output_gpu - l.outputs*l.batch, 1, l.state_gpu, 1);
        else math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.prev_state_gpu, 1, l.state_gpu, 1);
        float *prev_delta_gpu = (i == 0) ? 0 : l.delta_gpu - l.outputs*l.batch;

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uz.output_gpu, 1, l.z_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wz.output_gpu, 1, l.z_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, ur.output_gpu, 1, l.r_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wr.output_gpu, 1, l.r_gpu, 1);

        math21_ml_net_activation_vector_gpu(l.z_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.r_gpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uh.output_gpu, 1, l.h_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, wh.output_gpu, 1, l.h_gpu, 1);

        if(l.tanh){
            math21_ml_net_activation_vector_gpu(l.h_gpu, l.outputs*l.batch, TANH);
        } else {
            math21_ml_net_activation_vector_gpu(l.h_gpu, l.outputs*l.batch, LOGISTIC);
        }

        weighted_delta_gpu(l.state_gpu, l.h_gpu, l.z_gpu, prev_delta_gpu, uh.delta_gpu, uz.delta_gpu, l.outputs*l.batch, l.delta_gpu);

        if(l.tanh){
            math21_ml_net_activation_gradient_vector_gpu(l.h_gpu, l.outputs*l.batch, TANH, uh.delta_gpu);
        } else {
            math21_ml_net_activation_gradient_vector_gpu(l.h_gpu, l.outputs*l.batch, LOGISTIC, uh.delta_gpu);
        }

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uh.delta_gpu, 1, wh.delta_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state_gpu, 1, l.forgot_state_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.r_gpu, 1, l.forgot_state_gpu, 1);
        math21_vector_set_wrapper(l.outputs*l.batch, 0, l.forgot_delta_gpu, 1);

        s.input_gpu = l.forgot_state_gpu;
        s.delta_gpu = l.forgot_delta_gpu;

        math21_ml_net_fully_connected_layer_backward_gpu(wh, s);
        if(prev_delta_gpu) mult_add_into_gpu(l.outputs*l.batch, l.forgot_delta_gpu, l.r_gpu, prev_delta_gpu);
        mult_add_into_gpu(l.outputs*l.batch, l.forgot_delta_gpu, l.state_gpu, ur.delta_gpu);

        math21_ml_net_activation_gradient_vector_gpu(l.r_gpu, l.outputs*l.batch, LOGISTIC, ur.delta_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, ur.delta_gpu, 1, wr.delta_gpu, 1);

        math21_ml_net_activation_gradient_vector_gpu(l.z_gpu, l.outputs*l.batch, LOGISTIC, uz.delta_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, uz.delta_gpu, 1, wz.delta_gpu, 1);

        s.input_gpu = l.state_gpu;
        s.delta_gpu = prev_delta_gpu;

        math21_ml_net_fully_connected_layer_backward_gpu(wr, s);
        math21_ml_net_fully_connected_layer_backward_gpu(wz, s);

        s.input_gpu = net.input_gpu;
        s.delta_gpu = net.delta_gpu;

        math21_ml_net_fully_connected_layer_backward_gpu(uh, s);
        math21_ml_net_fully_connected_layer_backward_gpu(ur, s);
        math21_ml_net_fully_connected_layer_backward_gpu(uz, s);


        net.input_gpu -= l.inputs*l.batch;
        if(net.delta_gpu) net.delta_gpu -= l.inputs*l.batch;
        l.output_gpu -= l.outputs*l.batch;
        l.delta_gpu -= l.outputs*l.batch;
        increment_layer(&uz, -1);
        increment_layer(&ur, -1);
        increment_layer(&uh, -1);

        increment_layer(&wz, -1);
        increment_layer(&wr, -1);
        increment_layer(&wh, -1);
    }
    math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, end_state, 1, l.state_gpu, 1);
}
#endif
