#pragma once

#include "fit.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef GPU

cublasHandle_t blas_handle();
int *cuda_make_int_array(int *x, size_t n);
void cuda_random(float *x_gpu, size_t n);
float cuda_compare(float *x_gpu, float *x, size_t n, char *s);

#endif

#ifdef __cplusplus
}
#endif
