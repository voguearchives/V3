#ifndef COL2IM_H
#define COL2IM_H

void math21_ml_conv_dX_prime_to_dX_cpu(const float* data_col,
        int channels, int height, int width,
        int ksize, int stride, int pad, float* data_im);

#ifdef GPU
void math21_ml_conv_dX_prime_to_dX_gpu(float *data_col,
        int channels, int height, int width,
        int ksize, int stride, int pad, float *data_im);
#endif
#endif
