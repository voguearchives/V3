#include "lstm_layer.h"
#include "connected_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void increment_layer(layer *l, int steps)
{
    int num = l->outputs*l->batch*steps;
    l->output += num;
    l->delta += num;
    l->x += num;
    l->x_norm += num;

#ifdef GPU
    l->output_gpu += num;
    l->delta_gpu += num;
    l->x_gpu += num;
    l->x_norm_gpu += num;
#endif
}

layer make_lstm_layer(int batch, int inputs, int outputs, int steps, int batch_normalize, int adam)
{
    fprintf(stderr, "LSTM Layer: %d inputs, %d outputs\n", inputs, outputs);
    batch = batch / steps;
    layer l = { 0 };
    l.batch = batch;
    l.type = LSTM;
    l.steps = steps;
    l.inputs = inputs;

    l.uf = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.uf) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.uf->batch = batch;

    l.ui = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.ui) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.ui->batch = batch;

    l.ug = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.ug) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.ug->batch = batch;

    l.uo = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.uo) = math21_ml_net_fully_connected_layer_create(batch*steps, inputs, outputs, LINEAR, batch_normalize, adam);
    l.uo->batch = batch;

    l.wf = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wf) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wf->batch = batch;

    l.wi = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wi) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wi->batch = batch;

    l.wg = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wg) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wg->batch = batch;

    l.wo = math21_vector_calloc_cpu(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.wo) = math21_ml_net_fully_connected_layer_create(batch*steps, outputs, outputs, LINEAR, batch_normalize, adam);
    l.wo->batch = batch;

    l.batch_normalize = batch_normalize;
    l.outputs = outputs;

    l.output = math21_vector_calloc_cpu(outputs*batch*steps, sizeof(float));
    l.state = math21_vector_calloc_cpu(outputs*batch, sizeof(float));

    l.forward = forward_lstm_layer;
    l.update = update_lstm_layer;

    l.prev_state_cpu =  calloc(batch*outputs, sizeof(float));
    l.prev_cell_cpu =   calloc(batch*outputs, sizeof(float));
    l.cell_cpu =        calloc(batch*outputs*steps, sizeof(float));

    l.f_cpu =           calloc(batch*outputs, sizeof(float));
    l.i_cpu =           calloc(batch*outputs, sizeof(float));
    l.g_cpu =           calloc(batch*outputs, sizeof(float));
    l.o_cpu =           calloc(batch*outputs, sizeof(float));
    l.c_cpu =           calloc(batch*outputs, sizeof(float));
    l.h_cpu =           calloc(batch*outputs, sizeof(float));
    l.temp_cpu =        calloc(batch*outputs, sizeof(float));
    l.temp2_cpu =       calloc(batch*outputs, sizeof(float));
    l.temp3_cpu =       calloc(batch*outputs, sizeof(float));
    l.dc_cpu =          calloc(batch*outputs, sizeof(float));
    l.dh_cpu =          calloc(batch*outputs, sizeof(float));

#ifdef GPU
    l.forward_gpu = forward_lstm_layer_gpu;
    l.backward_gpu = backward_lstm_layer_gpu;
    l.update_gpu = update_lstm_layer_gpu;

    l.output_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs*steps);
    l.delta_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*l.outputs*steps);

    l.prev_state_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.prev_cell_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.cell_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs*steps);

    l.f_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.i_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.g_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.o_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.c_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.h_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.temp_gpu =  math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.temp2_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.temp3_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.dc_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
    l.dh_gpu = math21_cuda_vector_create_with_value_from_cpu(0, batch*outputs);
#endif

    return l;
}

void update_lstm_layer(layer l, update_args a)
{
    math21_ml_net_fully_connected_layer_update(*(l.wf), a);
    math21_ml_net_fully_connected_layer_update(*(l.wi), a);
    math21_ml_net_fully_connected_layer_update(*(l.wg), a);
    math21_ml_net_fully_connected_layer_update(*(l.wo), a);
    math21_ml_net_fully_connected_layer_update(*(l.uf), a);
    math21_ml_net_fully_connected_layer_update(*(l.ui), a);
    math21_ml_net_fully_connected_layer_update(*(l.ug), a);
    math21_ml_net_fully_connected_layer_update(*(l.uo), a);
}

void forward_lstm_layer(layer l, network state)
{
    network s = { 0 };
    s.train = state.train;
    int i;
    layer wf = *(l.wf);
    layer wi = *(l.wi);
    layer wg = *(l.wg);
    layer wo = *(l.wo);

    layer uf = *(l.uf);
    layer ui = *(l.ui);
    layer ug = *(l.ug);
    layer uo = *(l.uo);

    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wf.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wi.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wg.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, wo.delta, 1);

    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, uf.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, ui.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, ug.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, uo.delta, 1);
    if (state.train) {
        math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, l.delta, 1);
    }

    for (i = 0; i < l.steps; ++i) {
        s.input = l.h_cpu;
        math21_ml_net_fully_connected_layer_forward(wf, s);
        math21_ml_net_fully_connected_layer_forward(wi, s);
        math21_ml_net_fully_connected_layer_forward(wg, s);
        math21_ml_net_fully_connected_layer_forward(wo, s);

        s.input = state.input;
        math21_ml_net_fully_connected_layer_forward(uf, s);
        math21_ml_net_fully_connected_layer_forward(ui, s);
        math21_ml_net_fully_connected_layer_forward(ug, s);
        math21_ml_net_fully_connected_layer_forward(uo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wf.output, 1, l.f_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uf.output, 1, l.f_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wi.output, 1, l.i_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ui.output, 1, l.i_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wg.output, 1, l.g_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ug.output, 1, l.g_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wo.output, 1, l.o_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uo.output, 1, l.o_cpu, 1);

        math21_ml_net_activation_vector_cpu(l.f_cpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_cpu(l.i_cpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_cpu(l.g_cpu, l.outputs*l.batch, TANH);
        math21_ml_net_activation_vector_cpu(l.o_cpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.i_cpu, 1, l.temp_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.g_cpu, 1, l.temp_cpu, 1);		
        mul_cpu(l.outputs*l.batch, l.f_cpu, 1, l.c_cpu, 1);			
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, l.temp_cpu, 1, l.c_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_cpu, 1, l.h_cpu, 1);
        math21_ml_net_activation_vector_cpu(l.h_cpu, l.outputs*l.batch, TANH);
        mul_cpu(l.outputs*l.batch, l.o_cpu, 1, l.h_cpu, 1);	

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_cpu, 1, l.cell_cpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.h_cpu, 1, l.output, 1);

        state.input += l.inputs*l.batch;
        l.output    += l.outputs*l.batch;
        l.cell_cpu      += l.outputs*l.batch;

        increment_layer(&wf, 1);
        increment_layer(&wi, 1);
        increment_layer(&wg, 1);
        increment_layer(&wo, 1);

        increment_layer(&uf, 1);
        increment_layer(&ui, 1);
        increment_layer(&ug, 1);
        increment_layer(&uo, 1);
    }
}

void backward_lstm_layer(layer l, network state)
{
    network s = { 0 };
    s.train = state.train;
    int i;
    layer wf = *(l.wf);
    layer wi = *(l.wi);
    layer wg = *(l.wg);
    layer wo = *(l.wo);

    layer uf = *(l.uf);
    layer ui = *(l.ui);
    layer ug = *(l.ug);
    layer uo = *(l.uo);

    increment_layer(&wf, l.steps - 1);
    increment_layer(&wi, l.steps - 1);
    increment_layer(&wg, l.steps - 1);
    increment_layer(&wo, l.steps - 1);

    increment_layer(&uf, l.steps - 1);
    increment_layer(&ui, l.steps - 1);
    increment_layer(&ug, l.steps - 1);
    increment_layer(&uo, l.steps - 1);

    state.input += l.inputs*l.batch*(l.steps - 1);
    if (state.delta) state.delta += l.inputs*l.batch*(l.steps - 1);

    l.output += l.outputs*l.batch*(l.steps - 1);
    l.cell_cpu += l.outputs*l.batch*(l.steps - 1);
    l.delta += l.outputs*l.batch*(l.steps - 1);

    for (i = l.steps - 1; i >= 0; --i) {
        if (i != 0) math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.cell_cpu - l.outputs*l.batch, 1, l.prev_cell_cpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.cell_cpu, 1, l.c_cpu, 1);
        if (i != 0) math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output - l.outputs*l.batch, 1, l.prev_state_cpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output, 1, l.h_cpu, 1);

        l.dh_cpu = (i == 0) ? 0 : l.delta - l.outputs*l.batch;

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wf.output, 1, l.f_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uf.output, 1, l.f_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wi.output, 1, l.i_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ui.output, 1, l.i_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wg.output, 1, l.g_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ug.output, 1, l.g_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wo.output, 1, l.o_cpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uo.output, 1, l.o_cpu, 1);

        math21_ml_net_activation_vector_cpu(l.f_cpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_cpu(l.i_cpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_cpu(l.g_cpu, l.outputs*l.batch, TANH);
        math21_ml_net_activation_vector_cpu(l.o_cpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.delta, 1, l.temp3_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_cpu, 1, l.temp_cpu, 1);
        math21_ml_net_activation_vector_cpu(l.temp_cpu, l.outputs*l.batch, TANH);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp3_cpu, 1, l.temp2_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.o_cpu, 1, l.temp2_cpu, 1);			

        math21_ml_net_activation_gradient_vector_cpu(l.temp_cpu, l.outputs*l.batch, TANH, l.temp2_cpu);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, l.dc_cpu, 1, l.temp2_cpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_cpu, 1, l.temp_cpu, 1);
        math21_ml_net_activation_vector_cpu(l.temp_cpu, l.outputs*l.batch, TANH);
        mul_cpu(l.outputs*l.batch, l.temp3_cpu, 1, l.temp_cpu, 1);		
        math21_ml_net_activation_gradient_vector_cpu(l.o_cpu, l.outputs*l.batch, LOGISTIC, l.temp_cpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, wo.delta, 1);
        s.input = l.prev_state_cpu;
        s.delta = l.dh_cpu;															
        math21_ml_net_fully_connected_layer_backward(wo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, uo.delta, 1);
        s.input = state.input;
        s.delta = state.delta;
        math21_ml_net_fully_connected_layer_backward(uo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_cpu, 1, l.temp_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.i_cpu, 1, l.temp_cpu, 1);				
        math21_ml_net_activation_gradient_vector_cpu(l.g_cpu, l.outputs*l.batch, TANH, l.temp_cpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, wg.delta, 1);
        s.input = l.prev_state_cpu;
        s.delta = l.dh_cpu;														
        math21_ml_net_fully_connected_layer_backward(wg, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, ug.delta, 1);
        s.input = state.input;
        s.delta = state.delta;
        math21_ml_net_fully_connected_layer_backward(ug, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_cpu, 1, l.temp_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.g_cpu, 1, l.temp_cpu, 1);				
        math21_ml_net_activation_gradient_vector_cpu(l.i_cpu, l.outputs*l.batch, LOGISTIC, l.temp_cpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, wi.delta, 1);
        s.input = l.prev_state_cpu;
        s.delta = l.dh_cpu;
        math21_ml_net_fully_connected_layer_backward(wi, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, ui.delta, 1);
        s.input = state.input;
        s.delta = state.delta;
        math21_ml_net_fully_connected_layer_backward(ui, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_cpu, 1, l.temp_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.prev_cell_cpu, 1, l.temp_cpu, 1);
        math21_ml_net_activation_gradient_vector_cpu(l.f_cpu, l.outputs*l.batch, LOGISTIC, l.temp_cpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, wf.delta, 1);
        s.input = l.prev_state_cpu;
        s.delta = l.dh_cpu;
        math21_ml_net_fully_connected_layer_backward(wf, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, uf.delta, 1);
        s.input = state.input;
        s.delta = state.delta;
        math21_ml_net_fully_connected_layer_backward(uf, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_cpu, 1, l.temp_cpu, 1);
        mul_cpu(l.outputs*l.batch, l.f_cpu, 1, l.temp_cpu, 1);				
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_cpu, 1, l.dc_cpu, 1);

        state.input -= l.inputs*l.batch;
        if (state.delta) state.delta -= l.inputs*l.batch;
        l.output -= l.outputs*l.batch;
        l.cell_cpu -= l.outputs*l.batch;
        l.delta -= l.outputs*l.batch;

        increment_layer(&wf, -1);
        increment_layer(&wi, -1);
        increment_layer(&wg, -1);
        increment_layer(&wo, -1);

        increment_layer(&uf, -1);
        increment_layer(&ui, -1);
        increment_layer(&ug, -1);
        increment_layer(&uo, -1);
    }
}

#ifdef GPU
void update_lstm_layer_gpu(layer l, update_args a)
{
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wf), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wi), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wg), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.wo), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.uf), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.ui), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.ug), a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.uo), a);
}

void forward_lstm_layer_gpu(layer l, network state)
{
    network s = { 0 };
    s.train = state.train;
    int i;
    layer wf = *(l.wf);
    layer wi = *(l.wi);
    layer wg = *(l.wg);
    layer wo = *(l.wo);

    layer uf = *(l.uf);
    layer ui = *(l.ui);
    layer ug = *(l.ug);
    layer uo = *(l.uo);

    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wf.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wi.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wg.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, wo.delta_gpu, 1);

    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, uf.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, ui.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, ug.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, uo.delta_gpu, 1);
    if (state.train) {
        math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, l.delta_gpu, 1);
    }

    for (i = 0; i < l.steps; ++i) {
        s.input_gpu = l.h_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(wf, s);
        math21_ml_net_fully_connected_layer_forward_gpu(wi, s);
        math21_ml_net_fully_connected_layer_forward_gpu(wg, s);
        math21_ml_net_fully_connected_layer_forward_gpu(wo, s);

        s.input_gpu = state.input_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(uf, s);
        math21_ml_net_fully_connected_layer_forward_gpu(ui, s);
        math21_ml_net_fully_connected_layer_forward_gpu(ug, s);
        math21_ml_net_fully_connected_layer_forward_gpu(uo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wf.output_gpu, 1, l.f_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uf.output_gpu, 1, l.f_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wi.output_gpu, 1, l.i_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ui.output_gpu, 1, l.i_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wg.output_gpu, 1, l.g_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ug.output_gpu, 1, l.g_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wo.output_gpu, 1, l.o_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uo.output_gpu, 1, l.o_gpu, 1);

        math21_ml_net_activation_vector_gpu(l.f_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.i_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.g_gpu, l.outputs*l.batch, TANH);
        math21_ml_net_activation_vector_gpu(l.o_gpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.i_gpu, 1, l.temp_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.g_gpu, 1, l.temp_gpu, 1);		
        mul_gpu(l.outputs*l.batch, l.f_gpu, 1, l.c_gpu, 1);			
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, l.temp_gpu, 1, l.c_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_gpu, 1, l.h_gpu, 1);
        math21_ml_net_activation_vector_gpu(l.h_gpu, l.outputs*l.batch, TANH);
        mul_gpu(l.outputs*l.batch, l.o_gpu, 1, l.h_gpu, 1);	

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_gpu, 1, l.cell_gpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.h_gpu, 1, l.output_gpu, 1);

        state.input_gpu += l.inputs*l.batch;
        l.output_gpu    += l.outputs*l.batch;
        l.cell_gpu      += l.outputs*l.batch;

        increment_layer(&wf, 1);
        increment_layer(&wi, 1);
        increment_layer(&wg, 1);
        increment_layer(&wo, 1);

        increment_layer(&uf, 1);
        increment_layer(&ui, 1);
        increment_layer(&ug, 1);
        increment_layer(&uo, 1);
    }
}

void backward_lstm_layer_gpu(layer l, network state)
{
    network s = { 0 };
    s.train = state.train;
    int i;
    layer wf = *(l.wf);
    layer wi = *(l.wi);
    layer wg = *(l.wg);
    layer wo = *(l.wo);

    layer uf = *(l.uf);
    layer ui = *(l.ui);
    layer ug = *(l.ug);
    layer uo = *(l.uo);

    increment_layer(&wf, l.steps - 1);
    increment_layer(&wi, l.steps - 1);
    increment_layer(&wg, l.steps - 1);
    increment_layer(&wo, l.steps - 1);

    increment_layer(&uf, l.steps - 1);
    increment_layer(&ui, l.steps - 1);
    increment_layer(&ug, l.steps - 1);
    increment_layer(&uo, l.steps - 1);

    state.input_gpu += l.inputs*l.batch*(l.steps - 1);
    if (state.delta_gpu) state.delta_gpu += l.inputs*l.batch*(l.steps - 1);

    l.output_gpu += l.outputs*l.batch*(l.steps - 1);
    l.cell_gpu += l.outputs*l.batch*(l.steps - 1);
    l.delta_gpu += l.outputs*l.batch*(l.steps - 1);

    for (i = l.steps - 1; i >= 0; --i) {
        if (i != 0) math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.cell_gpu - l.outputs*l.batch, 1, l.prev_cell_gpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.cell_gpu, 1, l.c_gpu, 1);
        if (i != 0) math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output_gpu - l.outputs*l.batch, 1, l.prev_state_gpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.output_gpu, 1, l.h_gpu, 1);

        l.dh_gpu = (i == 0) ? 0 : l.delta_gpu - l.outputs*l.batch;

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wf.output_gpu, 1, l.f_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uf.output_gpu, 1, l.f_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wi.output_gpu, 1, l.i_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ui.output_gpu, 1, l.i_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wg.output_gpu, 1, l.g_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, ug.output_gpu, 1, l.g_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, wo.output_gpu, 1, l.o_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, uo.output_gpu, 1, l.o_gpu, 1);

        math21_ml_net_activation_vector_gpu(l.f_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.i_gpu, l.outputs*l.batch, LOGISTIC);
        math21_ml_net_activation_vector_gpu(l.g_gpu, l.outputs*l.batch, TANH);
        math21_ml_net_activation_vector_gpu(l.o_gpu, l.outputs*l.batch, LOGISTIC);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.delta_gpu, 1, l.temp3_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_gpu, 1, l.temp_gpu, 1);
        math21_ml_net_activation_vector_gpu(l.temp_gpu, l.outputs*l.batch, TANH);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp3_gpu, 1, l.temp2_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.o_gpu, 1, l.temp2_gpu, 1);			

        math21_ml_net_activation_gradient_vector_gpu(l.temp_gpu, l.outputs*l.batch, TANH, l.temp2_gpu);
        math21_vector_kx_add_y_wrapper(l.outputs*l.batch, 1, l.dc_gpu, 1, l.temp2_gpu, 1);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.c_gpu, 1, l.temp_gpu, 1);
        math21_ml_net_activation_vector_gpu(l.temp_gpu, l.outputs*l.batch, TANH);
        mul_gpu(l.outputs*l.batch, l.temp3_gpu, 1, l.temp_gpu, 1);		
        math21_ml_net_activation_gradient_vector_gpu(l.o_gpu, l.outputs*l.batch, LOGISTIC, l.temp_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, wo.delta_gpu, 1);
        s.input_gpu = l.prev_state_gpu;
        s.delta_gpu = l.dh_gpu;															
        math21_ml_net_fully_connected_layer_backward_gpu(wo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, uo.delta_gpu, 1);
        s.input_gpu = state.input_gpu;
        s.delta_gpu = state.delta_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(uo, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_gpu, 1, l.temp_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.i_gpu, 1, l.temp_gpu, 1);				
        math21_ml_net_activation_gradient_vector_gpu(l.g_gpu, l.outputs*l.batch, TANH, l.temp_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, wg.delta_gpu, 1);
        s.input_gpu = l.prev_state_gpu;
        s.delta_gpu = l.dh_gpu;														
        math21_ml_net_fully_connected_layer_backward_gpu(wg, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, ug.delta_gpu, 1);
        s.input_gpu = state.input_gpu;
        s.delta_gpu = state.delta_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(ug, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_gpu, 1, l.temp_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.g_gpu, 1, l.temp_gpu, 1);				
        math21_ml_net_activation_gradient_vector_gpu(l.i_gpu, l.outputs*l.batch, LOGISTIC, l.temp_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, wi.delta_gpu, 1);
        s.input_gpu = l.prev_state_gpu;
        s.delta_gpu = l.dh_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(wi, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, ui.delta_gpu, 1);
        s.input_gpu = state.input_gpu;
        s.delta_gpu = state.delta_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(ui, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_gpu, 1, l.temp_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.prev_cell_gpu, 1, l.temp_gpu, 1);
        math21_ml_net_activation_gradient_vector_gpu(l.f_gpu, l.outputs*l.batch, LOGISTIC, l.temp_gpu);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, wf.delta_gpu, 1);
        s.input_gpu = l.prev_state_gpu;
        s.delta_gpu = l.dh_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(wf, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, uf.delta_gpu, 1);
        s.input_gpu = state.input_gpu;
        s.delta_gpu = state.delta_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(uf, s);

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp2_gpu, 1, l.temp_gpu, 1);
        mul_gpu(l.outputs*l.batch, l.f_gpu, 1, l.temp_gpu, 1);				
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.temp_gpu, 1, l.dc_gpu, 1);

        state.input_gpu -= l.inputs*l.batch;
        if (state.delta_gpu) state.delta_gpu -= l.inputs*l.batch;
        l.output_gpu -= l.outputs*l.batch;
        l.cell_gpu -= l.outputs*l.batch;
        l.delta_gpu -= l.outputs*l.batch;

        increment_layer(&wf, -1);
        increment_layer(&wi, -1);
        increment_layer(&wg, -1);
        increment_layer(&wo, -1);

        increment_layer(&uf, -1);
        increment_layer(&ui, -1);
        increment_layer(&ug, -1);
        increment_layer(&uo, -1);
    }
}
#endif
