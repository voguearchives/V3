#include "deconvolutional_layer.h"
#include "convolutional_layer.h"
#include "batchnorm_layer.h"
#include "utils.h"
#include "im2col.h"
#include "col2im.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <stdio.h>
#include <time.h>

// ...
size_t math21_ml_net_deconvolutional_layer_get_X_prime_size(layer l){
    return (size_t)l.h*l.w*l.size*l.size*l.n*sizeof(float);
}

void bilinear_init(layer l)
{
    int i,j,f;
    float center = (l.size-1) / 2.;
    for(f = 0; f < l.n; ++f){
        for(j = 0; j < l.size; ++j){
            for(i = 0; i < l.size; ++i){
                float val = (1 - fabs(i - center)) * (1 - fabs(j - center));
                int c = f%l.c;
                int ind = f*l.size*l.size*l.c + c*l.size*l.size + j*l.size + i;
                l.weights[ind] = val;
            }
        }
    }
}


layer make_deconvolutional_layer(int batch, int h, int w, int c, int n, int size, int stride, int padding, ACTIVATION activation, int batch_normalize, int adam)
{
    int i;
    layer l = {0};
    l.type = DECONVOLUTIONAL;

    l.h = h;
    l.w = w;
    l.c = c;
    l.n = n;
    l.batch = batch;
    l.stride = stride;
    l.size = size;

    l.nweights = c*n*size*size;

    l.weights = math21_vector_calloc_cpu(c*n*size*size, sizeof(float));
    l.weight_updates = math21_vector_calloc_cpu(c*n*size*size, sizeof(float));

    l.biases = math21_vector_calloc_cpu(n, sizeof(float));
    l.bias_updates = math21_vector_calloc_cpu(n, sizeof(float));
    //float scale = n/(size*size*c);
    //printf("scale: %f\n", scale);
    float scale = .02;
    for(i = 0; i < c*n*size*size; ++i) l.weights[i] = scale*rand_normal();
    //bilinear_init(l);
    for(i = 0; i < n; ++i){
        l.biases[i] = 0;
    }
    l.pad = padding;

    l.out_h = (l.h - 1) * l.stride + l.size - 2*l.pad;
    l.out_w = (l.w - 1) * l.stride + l.size - 2*l.pad;
    l.out_c = n;
    l.outputs = l.out_w * l.out_h * l.out_c;
    l.inputs = l.w * l.h * l.c;

    math21_vector_kx_wrapper(l.nweights, (float)l.out_w*l.out_h/(l.w*l.h), l.weights, 1);

    l.output = math21_vector_calloc_cpu(l.batch*l.outputs, sizeof(float));
    l.delta  = math21_vector_calloc_cpu(l.batch*l.outputs, sizeof(float));

    l.forward = forward_deconvolutional_layer;
    l.backward = backward_deconvolutional_layer;
    l.update = update_deconvolutional_layer;

    l.batch_normalize = batch_normalize;

    if(batch_normalize){
        l.scales = math21_vector_calloc_cpu(n, sizeof(float));
        l.scale_updates = math21_vector_calloc_cpu(n, sizeof(float));
        for(i = 0; i < n; ++i){
            l.scales[i] = 1;
        }

        l.mean = math21_vector_calloc_cpu(n, sizeof(float));
        l.variance = math21_vector_calloc_cpu(n, sizeof(float));

        l.mean_delta = math21_vector_calloc_cpu(n, sizeof(float));
        l.variance_delta = math21_vector_calloc_cpu(n, sizeof(float));

        l.rolling_mean = math21_vector_calloc_cpu(n, sizeof(float));
        l.rolling_variance = math21_vector_calloc_cpu(n, sizeof(float));
        l.x = math21_vector_calloc_cpu(l.batch*l.outputs, sizeof(float));
        l.x_norm = math21_vector_calloc_cpu(l.batch*l.outputs, sizeof(float));
    }
    if(adam){
        l.m = math21_vector_calloc_cpu(c*n*size*size, sizeof(float));
        l.v = math21_vector_calloc_cpu(c*n*size*size, sizeof(float));
        l.bias_m = math21_vector_calloc_cpu(n, sizeof(float));
        l.scale_m = math21_vector_calloc_cpu(n, sizeof(float));
        l.bias_v = math21_vector_calloc_cpu(n, sizeof(float));
        l.scale_v = math21_vector_calloc_cpu(n, sizeof(float));
    }

#ifdef GPU
    l.forward_gpu = forward_deconvolutional_layer_gpu;
    l.backward_gpu = backward_deconvolutional_layer_gpu;
    l.update_gpu = update_deconvolutional_layer_gpu;

    if(gpu_index >= 0){

        if (adam) {
            l.m_gpu = math21_cuda_vector_create_with_value_from_cpu(l.m, c*n*size*size);
            l.v_gpu = math21_cuda_vector_create_with_value_from_cpu(l.v, c*n*size*size);
            l.bias_m_gpu = math21_cuda_vector_create_with_value_from_cpu(l.bias_m, n);
            l.bias_v_gpu = math21_cuda_vector_create_with_value_from_cpu(l.bias_v, n);
            l.scale_m_gpu = math21_cuda_vector_create_with_value_from_cpu(l.scale_m, n);
            l.scale_v_gpu = math21_cuda_vector_create_with_value_from_cpu(l.scale_v, n);
        }
        l.weights_gpu = math21_cuda_vector_create_with_value_from_cpu(l.weights, c*n*size*size);
        l.weight_updates_gpu = math21_cuda_vector_create_with_value_from_cpu(l.weight_updates, c*n*size*size);

        l.biases_gpu = math21_cuda_vector_create_with_value_from_cpu(l.biases, n);
        l.bias_updates_gpu = math21_cuda_vector_create_with_value_from_cpu(l.bias_updates, n);

        l.delta_gpu = math21_cuda_vector_create_with_value_from_cpu(l.delta, l.batch*l.out_h*l.out_w*n);
        l.output_gpu = math21_cuda_vector_create_with_value_from_cpu(l.output, l.batch*l.out_h*l.out_w*n);

        if(batch_normalize){
            l.mean_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);
            l.variance_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);

            l.rolling_mean_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);
            l.rolling_variance_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);

            l.mean_delta_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);
            l.variance_delta_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);

            l.scales_gpu = math21_cuda_vector_create_with_value_from_cpu(l.scales, n);
            l.scale_updates_gpu = math21_cuda_vector_create_with_value_from_cpu(0, n);

            l.x_gpu = math21_cuda_vector_create_with_value_from_cpu(0, l.batch*l.out_h*l.out_w*n);
            l.x_norm_gpu = math21_cuda_vector_create_with_value_from_cpu(0, l.batch*l.out_h*l.out_w*n);
        }
    }
#endif

    l.activation = activation;
    l.workspace_size = math21_ml_net_deconvolutional_layer_get_X_prime_size(l);

    fprintf(stderr, "deconv%5d %2d x%2d /%2d  %4d x%4d x%4d   ->  %4d x%4d x%4d\n", n, size, size, stride, w, h, c, l.out_w, l.out_h, l.out_c);

    return l;
}

void denormalize_deconvolutional_layer(layer l)
{
    int i, j;
    for(i = 0; i < l.n; ++i){
        float scale = l.scales[i]/sqrt(l.rolling_variance[i] + .00001);
        for(j = 0; j < l.c*l.size*l.size; ++j){
            l.weights[i*l.c*l.size*l.size + j] *= scale;
        }
        l.biases[i] -= l.rolling_mean[i] * scale;
        l.scales[i] = 1;
        l.rolling_mean[i] = 0;
        l.rolling_variance[i] = 1;
    }
}

void resize_deconvolutional_layer(layer *l, int h, int w)
{
    l->h = h;
    l->w = w;
    l->out_h = (l->h - 1) * l->stride + l->size - 2*l->pad;
    l->out_w = (l->w - 1) * l->stride + l->size - 2*l->pad;

    l->outputs = l->out_h * l->out_w * l->out_c;
    l->inputs = l->w * l->h * l->c;

    l->output = math21_vector_realloc_cpu(l->output, l->batch*l->outputs*sizeof(float));
    l->delta  = math21_vector_realloc_cpu(l->delta,  l->batch*l->outputs*sizeof(float));
    if(l->batch_normalize){
        l->x = math21_vector_realloc_cpu(l->x, l->batch*l->outputs*sizeof(float));
        l->x_norm  = math21_vector_realloc_cpu(l->x_norm, l->batch*l->outputs*sizeof(float));
    }

#ifdef GPU
    math21_ml_cuda_free(l->delta_gpu);
    math21_ml_cuda_free(l->output_gpu);

    l->delta_gpu =  math21_cuda_vector_create_with_value_from_cpu(l->delta,  l->batch*l->outputs);
    l->output_gpu = math21_cuda_vector_create_with_value_from_cpu(l->output, l->batch*l->outputs);

    if(l->batch_normalize){
        math21_ml_cuda_free(l->x_gpu);
        math21_ml_cuda_free(l->x_norm_gpu);

        l->x_gpu = math21_cuda_vector_create_with_value_from_cpu(l->output, l->batch*l->outputs);
        l->x_norm_gpu = math21_cuda_vector_create_with_value_from_cpu(l->output, l->batch*l->outputs);
    }
#endif
    l->workspace_size = math21_ml_net_deconvolutional_layer_get_X_prime_size(*l);
}

//
void forward_deconvolutional_layer(const layer l, network net)
{
    int i;

    int m = l.size*l.size*l.n;
    int n = l.h*l.w;
    int k = l.c;

    math21_vector_set_cpu(l.outputs*l.batch, 0, l.output, 1);

    for(i = 0; i < l.batch; ++i){
        float *a = l.weights;
        float *b = net.input + i*l.c*l.h*l.w;
        float *c = net.workspace;

        math21_matrix_multiply_k1AB_add_k2C_similar_cpu(1,0,m,n,k,1,a,m,b,n,0,c,n);

        math21_ml_conv_dX_prime_to_dX_cpu(net.workspace, l.out_c, l.out_h, l.out_w, l.size, l.stride, l.pad, l.output+i*l.outputs);
    }
    if (l.batch_normalize) {
        math21_ml_net_batchnorm_layer_forward(l, net);
    } else {
        math21_vector_x_add_b_with_in_class_wrapper(l.output, l.biases, l.batch, l.n, l.out_w*l.out_h);
    }
    math21_ml_net_activation_vector_cpu(l.output, l.batch*l.n*l.out_w*l.out_h, l.activation);
}

void backward_deconvolutional_layer(layer l, network net)
{
    int i;

    math21_ml_net_activation_gradient_vector_cpu(l.output, l.outputs*l.batch, l.activation, l.delta);

    if(l.batch_normalize){
        math21_ml_net_batchnorm_layer_backward(l, net);
    } else {
        math21_ml_conv_bias_backward(l.bias_updates, l.delta, l.batch, l.n, l.out_w*l.out_h);
    }

    //if(net.delta) memset(net.delta, 0, l.batch*l.h*l.w*l.c*sizeof(float));

    for(i = 0; i < l.batch; ++i){
        int m = l.c;
        int n = l.size*l.size*l.n;
        int k = l.h*l.w;

        float *a = net.input + i*m*k;
        float *b = net.workspace;
        float *c = l.weight_updates;

        math21_ml_conv_X_to_X_prime_cpu(l.delta + i*l.outputs, l.out_c, l.out_h, l.out_w,
                l.size, l.stride, l.pad, b);
        math21_matrix_multiply_k1AB_add_k2C_similar_cpu(0,1,m,n,k,1,a,k,b,k,1,c,n);

        if(net.delta){
            int m = l.c;
            int n = l.h*l.w;
            int k = l.size*l.size*l.n;

            float *a = l.weights;
            float *b = net.workspace;
            float *c = net.delta + i*n*m;

            math21_matrix_multiply_k1AB_add_k2C_similar_cpu(0,0,m,n,k,1,a,k,b,n,1,c,n);
        }
    }
}

void update_deconvolutional_layer(layer l, update_args a)
{
    float learning_rate = a.learning_rate*l.learning_rate_scale;
    float momentum = a.momentum;
    float decay = a.decay;
    int batch = a.batch;

    int size = l.size*l.size*l.c*l.n;
    math21_vector_kx_add_y_wrapper(l.n, learning_rate/batch, l.bias_updates, 1, l.biases, 1);
    math21_vector_kx_wrapper(l.n, momentum, l.bias_updates, 1);

    if(l.scales){
        math21_vector_kx_add_y_wrapper(l.n, learning_rate/batch, l.scale_updates, 1, l.scales, 1);
        math21_vector_kx_wrapper(l.n, momentum, l.scale_updates, 1);
    }

    math21_vector_kx_add_y_wrapper(size, -decay*batch, l.weights, 1, l.weight_updates, 1);
    math21_vector_kx_add_y_wrapper(size, learning_rate/batch, l.weight_updates, 1, l.weights, 1);
    math21_vector_kx_wrapper(size, momentum, l.weight_updates, 1);
}



