#include "rnn_layer.h"
#include "connected_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void math21_ml_net_rnn_inner_layer_increase_by_time(layer *l, int steps) {
    int num = l->outputs * l->batch * steps;
    l->output += num;
    l->delta += num;
    l->x += num;
    l->x_norm += num;

#ifdef GPU
    l->output_gpu += num;
    l->delta_gpu += num;
    l->x_gpu += num;
    l->x_norm_gpu += num;
#endif
}

layer
math21_ml_net_rnn_layer_create(int batch_size, int input_size, int output_size, int n_time_step, ACTIVATION activation, int is_batch_normalize, int is_adam) {
    fprintf(stdout, "RNN Layer: input_size %d, output_size %d\n", input_size, output_size);
    int rnn_batch_size = batch_size / n_time_step;
    layer l = {0};
    l.batch = rnn_batch_size;
    l.type = RNN;
    l.steps = n_time_step;
    l.inputs = input_size;

    // added by YE
    l.state = math21_ml_net_io_calloc(rnn_batch_size * (n_time_step+1) * output_size, sizeof(float));
//    l.prev_state = math21_ml_net_io_calloc(rnn_batch_size * n_time_step * output_size, sizeof(float));

    // original
//    l.state = math21_ml_net_io_calloc(rnn_batch_size*output_size, sizeof(float));
//    l.prev_state = math21_ml_net_io_calloc(rnn_batch_size*output_size, sizeof(float));

    l.input_layer = math21_ml_net_io_calloc(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.input_layer) = math21_ml_net_fully_connected_layer_create(rnn_batch_size * n_time_step, input_size, output_size, activation, is_batch_normalize, is_adam);
    l.input_layer->batch = rnn_batch_size;

    l.self_layer = math21_ml_net_io_calloc(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.self_layer) = math21_ml_net_fully_connected_layer_create(rnn_batch_size * n_time_step, output_size, output_size, activation, is_batch_normalize, is_adam);
    l.self_layer->batch = rnn_batch_size;

    l.output_layer = math21_ml_net_io_calloc(1, sizeof(layer));
    fprintf(stderr, "\t\t");
    *(l.output_layer) = math21_ml_net_fully_connected_layer_create(rnn_batch_size * n_time_step, output_size, output_size, activation, is_batch_normalize, is_adam);
    l.output_layer->batch = rnn_batch_size;

//    math21_ml_net_log_layer(l.output_layer);

    l.outputs = output_size;
    l.output = l.output_layer->output;
    l.delta = l.output_layer->delta;

    l.forward = math21_ml_net_rnn_layer_forward;
    l.backward = math21_ml_net_rnn_layer_backward;
    l.update = math21_ml_net_rnn_layer_update;
#ifdef GPU
    l.forward_gpu = math21_ml_net_rnn_layer_forward_gpu;
    l.backward_gpu = math21_ml_net_rnn_layer_backward_gpu;
    l.update_gpu = math21_ml_net_rnn_layer_update_gpu;
    l.state_gpu = math21_cuda_make_vector_from_cpu(0, rnn_batch_size*output_size);
    l.prev_state_gpu = math21_cuda_make_vector_from_cpu(0, rnn_batch_size*output_size);
    l.output_gpu = l.output_layer->output_gpu;
    l.delta_gpu = l.output_layer->delta_gpu;
#endif
    return l;
}

void math21_ml_net_rnn_layer_update(layer l, update_args a) {
    math21_ml_net_fully_connected_layer_update(*(l.input_layer), a);
    math21_ml_net_fully_connected_layer_update(*(l.self_layer), a);
    math21_ml_net_fully_connected_layer_update(*(l.output_layer), a);
}

//static int bbb_debug = 0;

// Y = W*X + b, Y = W*X + b, Y = W*X + b,
void math21_ml_net_rnn_layer_forward(layer l, network net) {
    network s = net;
    s.train = net.train;
    int i;

//    printf("bbb_debug%d\n", bbb_debug);
    layer input_layer = *(l.input_layer);
    layer self_layer = *(l.self_layer);
    layer output_layer = *(l.output_layer);

    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, output_layer.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, self_layer.delta, 1);
    math21_vector_set_cpu(l.outputs * l.batch * l.steps, 0, input_layer.delta, 1);
    if (net.train) math21_vector_set_cpu(l.outputs * l.batch, 0, l.state, 1);

    for (i = 0; i < l.steps; ++i) {
//        printf("ccc_debug%d,%d\n", i, l.steps);

//        math21_ml_net_log_layer(net.layers[0].output_layer);

        s.input = net.input;
        math21_ml_net_fully_connected_layer_forward(input_layer, s);

        s.input = l.state;
        math21_ml_net_fully_connected_layer_forward(self_layer, s);

        float *old_state = l.state;
        if (net.train) l.state += l.outputs * l.batch;
        if (l.shortcut) {
            math21_vector_assign_from_vector_wrapper(l.outputs * l.batch, old_state, 1, l.state, 1);
        } else {
            math21_vector_set_cpu(l.outputs * l.batch, 0, l.state, 1);
        }
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, input_layer.output, 1, l.state, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output, 1, l.state, 1);

        s.input = l.state;
        math21_ml_net_fully_connected_layer_forward(output_layer, s);

        net.input += l.inputs * l.batch;
        math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer, 1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer, 1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, 1);
    }
}

void math21_ml_net_rnn_layer_backward(layer l, network net) {
    network s = net;
    s.train = net.train;
    int i;
    layer input_layer = *(l.input_layer);
    layer self_layer = *(l.self_layer);
    layer output_layer = *(l.output_layer);

    math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer, l.steps - 1);
    math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer, l.steps - 1);
    math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, l.steps - 1);

    l.state += l.outputs * l.batch * l.steps;
    for (i = l.steps - 1; i >= 0; --i) {
        math21_vector_assign_from_vector_wrapper(l.outputs * l.batch, input_layer.output, 1, l.state, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output, 1, l.state, 1);

        s.input = l.state;
        s.delta = self_layer.delta;
        math21_ml_net_fully_connected_layer_backward(output_layer, s);

        l.state -= l.outputs * l.batch;
        /*
           if(i > 0){
           math21_vector_assign_from_vector_wrapper(l.outputs * l.batch, input_layer.output - l.outputs*l.batch, 1, l.state, 1);
           math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output - l.outputs*l.batch, 1, l.state, 1);
           }else{
           math21_vector_set_cpu(l.outputs * l.batch, 0, l.state, 1);
           }
         */

        s.input = l.state;
        s.delta = self_layer.delta - l.outputs * l.batch;
        if (i == 0) s.delta = 0;
        math21_ml_net_fully_connected_layer_backward(self_layer, s);

        math21_vector_assign_from_vector_wrapper(l.outputs * l.batch, self_layer.delta, 1, input_layer.delta, 1);
        if (i > 0 && l.shortcut)
            math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.delta, 1, self_layer.delta - l.outputs * l.batch, 1);
        s.input = net.input + i * l.inputs * l.batch;
        if (net.delta) s.delta = net.delta + i * l.inputs * l.batch;
        else s.delta = 0;
        math21_ml_net_fully_connected_layer_backward(input_layer, s);

        math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer, -1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer, -1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, -1);
    }
}

#ifdef GPU

void pull_rnn_layer(layer l)
{
    pull_connected_layer(*(l.input_layer));
    pull_connected_layer(*(l.self_layer));
    pull_connected_layer(*(l.output_layer));
}

void push_rnn_layer(layer l)
{
    push_connected_layer(*(l.input_layer));
    push_connected_layer(*(l.self_layer));
    push_connected_layer(*(l.output_layer));
}

void math21_ml_net_rnn_layer_update_gpu(layer l, update_args a)
{
    math21_ml_net_fully_connected_layer_update_gpu(*(l.input_layer),  a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.self_layer),   a);
    math21_ml_net_fully_connected_layer_update_gpu(*(l.output_layer), a);
}

void math21_ml_net_rnn_layer_forward_gpu(layer l, network net)
{
    network s = {0};
    s.train = net.train;
    int i;
    layer input_layer = *(l.input_layer);
    layer self_layer = *(l.self_layer);
    layer output_layer = *(l.output_layer);

    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, output_layer.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, self_layer.delta_gpu, 1);
    math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, input_layer.delta_gpu, 1);

    if(net.train) {
        math21_vector_set_wrapper(l.outputs * l.batch * l.steps, 0, l.delta_gpu, 1);
        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.state_gpu, 1, l.prev_state_gpu, 1);
    }

    for (i = 0; i < l.steps; ++i) {
        s.input_gpu = net.input_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(input_layer, s);

        s.input_gpu = l.state_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(self_layer, s);

        math21_vector_set_wrapper(l.outputs * l.batch, 0, l.state_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, input_layer.output_gpu, 1, l.state_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output_gpu, 1, l.state_gpu, 1);

        s.input_gpu = l.state_gpu;
        math21_ml_net_fully_connected_layer_forward_gpu(output_layer, s);

        net.input_gpu += l.inputs*l.batch;
        math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer, 1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer, 1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, 1);
    }
}

void math21_ml_net_rnn_layer_backward_gpu(layer l, network net)
{
    network s = {0};
    s.train = net.train;
    int i;
    layer input_layer = *(l.input_layer);
    layer self_layer = *(l.self_layer);
    layer output_layer = *(l.output_layer);
    math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer,  l.steps - 1);
    math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer,   l.steps - 1);
    math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, l.steps - 1);
    float *last_input = input_layer.output_gpu;
    float *last_self = self_layer.output_gpu;
    for (i = l.steps-1; i >= 0; --i) {
        math21_vector_set_wrapper(l.outputs * l.batch, 0, l.state_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, input_layer.output_gpu, 1, l.state_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output_gpu, 1, l.state_gpu, 1);

        s.input_gpu = l.state_gpu;
        s.delta_gpu = self_layer.delta_gpu;
        math21_ml_net_fully_connected_layer_backward_gpu(output_layer, s);

        if(i != 0) {
            math21_vector_set_wrapper(l.outputs * l.batch, 0, l.state_gpu, 1);
            math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, input_layer.output_gpu - l.outputs*l.batch, 1, l.state_gpu, 1);
            math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, self_layer.output_gpu - l.outputs*l.batch, 1, l.state_gpu, 1);
        }else {
            math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, l.prev_state_gpu, 1, l.state_gpu, 1);
        }

        math21_vector_assign_from_vector_wrapper(l.outputs*l.batch, self_layer.delta_gpu, 1, input_layer.delta_gpu, 1);

        s.input_gpu = l.state_gpu;
        s.delta_gpu = (i > 0) ? self_layer.delta_gpu - l.outputs*l.batch : 0;
        if (i == 0) s.delta_gpu = 0;
        math21_ml_net_fully_connected_layer_backward_gpu(self_layer, s);

        s.input_gpu = net.input_gpu + i*l.inputs*l.batch;
        if(net.delta_gpu) s.delta_gpu = net.delta_gpu + i*l.inputs*l.batch;
        else s.delta_gpu = 0;
        math21_ml_net_fully_connected_layer_backward_gpu(input_layer, s);

        math21_ml_net_rnn_inner_layer_increase_by_time(&input_layer,  -1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&self_layer,   -1);
        math21_ml_net_rnn_inner_layer_increase_by_time(&output_layer, -1);
    }
    math21_vector_set_wrapper(l.outputs * l.batch, 0, l.state_gpu, 1);
    math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, last_input, 1, l.state_gpu, 1);
    math21_vector_kx_add_y_wrapper(l.outputs * l.batch, 1, last_self, 1, l.state_gpu, 1);
}
#endif
