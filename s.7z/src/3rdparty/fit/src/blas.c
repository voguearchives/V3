#include "blas.h"

#include <math.h>
#include <assert.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void reorg_cpu(float *x, int w, int h, int c, int mini_batch_size, int stride, int forward, float *out) {
    int b, i, j, k;
    int out_c = c / (stride * stride);

    for (b = 0; b < mini_batch_size; ++b) {
        for (k = 0; k < c; ++k) {
            for (j = 0; j < h; ++j) {
                for (i = 0; i < w; ++i) {
                    int in_index = i + w * (j + h * (k + c * b));
                    int c2 = k % out_c;
                    int offset = k / out_c;
                    int w2 = i * stride + offset % stride;
                    int h2 = j * stride + offset / stride;
                    int out_index = w2 + w * stride * (h2 + h * stride * (c2 + out_c * b));
                    if (forward) out[out_index] = x[in_index];
                    else out[in_index] = x[out_index];
                }
            }
        }
    }
}

void flatten(float *x, int size, int layers, int mini_batch_size, int forward) {
    float *swap = math21_ml_net_io_calloc(size * layers * mini_batch_size, sizeof(float));
    int i, c, b;
    for (b = 0; b < mini_batch_size; ++b) {
        for (c = 0; c < layers; ++c) {
            for (i = 0; i < size; ++i) {
                int i1 = b * layers * size + c * size + i;
                int i2 = b * layers * size + i * layers + c;
                if (forward) swap[i2] = x[i1];
                else swap[i1] = x[i2];
            }
        }
    }
    memcpy(x, swap, size * layers * mini_batch_size * sizeof(float));
    free(swap);
}

void weighted_sum_cpu(float *a, float *b, float *s, int n, float *c) {
    int i;
    for (i = 0; i < n; ++i) {
        c[i] = s[i] * a[i] + (1 - s[i]) * (b ? b[i] : 0);
    }
}

void weighted_delta_cpu(float *a, float *b, float *s, float *da, float *db, float *ds, int n, float *dc) {
    int i;
    for (i = 0; i < n; ++i) {
        if (da) da[i] += dc[i] * s[i];
        if (db) db[i] += dc[i] * (1 - s[i]);
        ds[i] += dc[i] * (a[i] - b[i]);
    }
}

void
math21_ml_net_blas_l2normalize_cpu(float *x, float *dx, int mini_batch_size, int features_size, int in_class_size) {
    int b, f, i;
    for (b = 0; b < mini_batch_size; ++b) {
        for (i = 0; i < in_class_size; ++i) {
            float sum = 0;
            for (f = 0; f < features_size; ++f) {
                int index = b * features_size * in_class_size + f * in_class_size + i;
                sum += powf(x[index], 2);
            }
            sum = sqrtf(sum);
            for (f = 0; f < features_size; ++f) {
                int index = b * features_size * in_class_size + f * in_class_size + i;
                x[index] /= sum;
                dx[index] = (1 - x[index]) / sum;
            }
        }
    }
}

void const_cpu(int N, float ALPHA, float *X, int stride_x) {
    int i;
    for (i = 0; i < N; ++i) X[i * stride_x] = ALPHA;
}

void mul_cpu(int N, float *X, int stride_x, float *Y, int stride_y) {
    int i;
    for (i = 0; i < N; ++i) Y[i * stride_y] *= X[i * stride_x];
}

void pow_cpu(int N, float ALPHA, float *X, int stride_x, float *Y, int stride_y) {
    int i;
    for (i = 0; i < N; ++i) Y[i * stride_y] = pow(X[i * stride_x], ALPHA);
}

void deinter_cpu(int NX, float *X, int NY, float *Y, int B, float *OUT) {
    int i, j;
    int index = 0;
    for (j = 0; j < B; ++j) {
        for (i = 0; i < NX; ++i) {
            if (X) X[j * NX + i] += OUT[index];
            ++index;
        }
        for (i = 0; i < NY; ++i) {
            if (Y) Y[j * NY + i] += OUT[index];
            ++index;
        }
    }
}

void inter_cpu(int NX, float *X, int NY, float *Y, int B, float *OUT) {
    int i, j;
    int index = 0;
    for (j = 0; j < B; ++j) {
        for (i = 0; i < NX; ++i) {
            OUT[index++] = X[j * NX + i];
        }
        for (i = 0; i < NY; ++i) {
            OUT[index++] = Y[j * NY + i];
        }
    }
}

void mult_add_into_cpu(int N, float *X, float *Y, float *Z) {
    int i;
    for (i = 0; i < N; ++i) Z[i] += X[i] * Y[i];
}

void smooth_l1_cpu(int n, float *pred, float *truth, float *delta, float *error) {
    int i;
    for (i = 0; i < n; ++i) {
        float diff = truth[i] - pred[i];
        float abs_val = fabs(diff);
        if (abs_val < 1) {
            error[i] = diff * diff;
            delta[i] = diff;
        } else {
            error[i] = 2 * abs_val - 1;
            delta[i] = (diff < 0) ? 1 : -1;
        }
    }
}

void l1_cpu(int n, float *pred, float *truth, float *delta, float *error) {
    int i;
    for (i = 0; i < n; ++i) {
        float diff = truth[i] - pred[i];
        error[i] = fabs(diff);
        delta[i] = diff > 0 ? 1 : -1;
    }
}

void softmax_x_ent_cpu(int n, float *pred, float *truth, float *delta, float *error) {
    int i;
    for (i = 0; i < n; ++i) {
        float t = truth[i];
        float p = pred[i];
        error[i] = (t) ? -log(p) : 0;
        delta[i] = t - p;
    }
}

void logistic_x_ent_cpu(int n, float *pred, float *truth, float *delta, float *error) {
    int i;
    for (i = 0; i < n; ++i) {
        float t = truth[i];
        float p = pred[i];
        error[i] = -t * log(p) - (1 - t) * log(1 - p);
        delta[i] = t - p;
    }
}

void l2_cpu(int n, float *pred, float *truth, float *delta, float *error) {
    int i;
    for (i = 0; i < n; ++i) {
        float diff = truth[i] - pred[i];
        error[i] = diff * diff;
        delta[i] = diff;
    }
}

float dot_cpu(int N, float *X, int stride_x, float *Y, int stride_y) {
    int i;
    float dot = 0;
    for (i = 0; i < N; ++i) dot += X[i * stride_x] * Y[i * stride_y];
    return dot;
}

void softmax(float *input, int n, float temp, int stride, float *output) {
    int i;
    float sum = 0;
    float largest = -FLT_MAX;
    for (i = 0; i < n; ++i) {
        if (input[i * stride] > largest) largest = input[i * stride];
    }
    for (i = 0; i < n; ++i) {
        float e = exp(input[i * stride] / temp - largest / temp);
        sum += e;
        output[i * stride] = e;
    }
    for (i = 0; i < n; ++i) {
        output[i * stride] /= sum;
    }
}


void softmax_cpu(float *input, int n, int mini_batch_size, int batch_offset, int groups, int group_offset, int stride,
                 float temp, float *output) {
    int g, b;
    for (b = 0; b < mini_batch_size; ++b) {
        for (g = 0; g < groups; ++g) {
            softmax(input + b * batch_offset + g * group_offset, n, temp, stride,
                    output + b * batch_offset + g * group_offset);
        }
    }
}

