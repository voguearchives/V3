#include "convolutional_layer.h"
#include "batchnorm_layer.h"
#include "blas.h"
#include <stdio.h>

layer math21_ml_net_batch_normalization_layer_create(int batch, int w, int h, int c)
{
    fprintf(stdout, "Batch Normalization Layer: %d x %d x %d image\n", w,h,c);
    layer l = {0};
    l.type = BATCHNORM;
    l.batch = batch;
    l.h = l.out_h = h;
    l.w = l.out_w = w;
    l.c = l.out_c = c;
    l.output = math21_ml_net_io_calloc(h * w * c * batch, sizeof(float));
    l.delta  = math21_ml_net_io_calloc(h * w * c * batch, sizeof(float));
    l.inputs = w*h*c;
    l.outputs = l.inputs;

    l.scales = math21_ml_net_io_calloc(c, sizeof(float));
    l.scale_updates = math21_ml_net_io_calloc(c, sizeof(float));
    l.biases = math21_ml_net_io_calloc(c, sizeof(float));
    l.bias_updates = math21_ml_net_io_calloc(c, sizeof(float));
    int i;
    for(i = 0; i < c; ++i){
        l.scales[i] = 1;
    }

    l.mean = math21_ml_net_io_calloc(c, sizeof(float));
    l.variance = math21_ml_net_io_calloc(c, sizeof(float));

    l.rolling_mean = math21_ml_net_io_calloc(c, sizeof(float));
    l.rolling_variance = math21_ml_net_io_calloc(c, sizeof(float));

    l.forward = math21_ml_net_batchnorm_layer_forward;
    l.backward = math21_ml_net_batchnorm_layer_backward;
#ifdef GPU
    l.forward_gpu = math21_ml_net_batchnorm_layer_forward_gpu;
    l.backward_gpu = math21_ml_net_batchnorm_layer_backward_gpu;

    l.output_gpu =  math21_cuda_make_vector_from_cpu(l.output, h * w * c * batch);
    l.delta_gpu =   math21_cuda_make_vector_from_cpu(l.delta, h * w * c * batch);

    l.biases_gpu = math21_cuda_make_vector_from_cpu(l.biases, c);
    l.bias_updates_gpu = math21_cuda_make_vector_from_cpu(l.bias_updates, c);

    l.scales_gpu = math21_cuda_make_vector_from_cpu(l.scales, c);
    l.scale_updates_gpu = math21_cuda_make_vector_from_cpu(l.scale_updates, c);

    l.mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, c);
    l.variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, c);

    l.rolling_mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, c);
    l.rolling_variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, c);

    l.batchnormalization_backward_mu_gpu = math21_cuda_make_vector_from_cpu(l.mean, c);
    l.variance_delta_gpu = math21_cuda_make_vector_from_cpu(l.variance, c);

    l.x_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*l.outputs);
    l.x_norm_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*l.outputs);

#endif
    return l;
}

void resize_batchnorm_layer(layer *layer, int w, int h)
{
    fprintf(stderr, "Not implemented\n");
}

// Y = BN(X)
void math21_ml_net_batchnorm_layer_forward(layer l, network net)
{
    mlfunction_batchnorm bn = {0};
    bn.input = net.input;
    bn.is_train = net.train;
    bn.is_this_type = (l.type == BATCHNORM);
    bn.outputs = l.outputs;
    bn.mini_batch_size = l.batch;
    bn.output = l.output;
    bn.x = l.x;
    bn.in_class_size = l.out_h*l.out_w;
    bn.out_c = l.out_c;
    bn.mean = l.mean;
    bn.variance = l.variance;
    bn.rolling_mean = l.rolling_mean;
    bn.rolling_variance = l.rolling_variance;
    bn.x_norm = l.x_norm;
    bn.scales = l.scales;
    bn.biases = l.biases;

    math21_ml_function_batchnorm_forward(bn);
}

void math21_ml_net_batchnorm_layer_backward(layer l, network net)
{
    mlfunction_batchnorm bn = {0};
    bn.input = net.input;
    bn.is_train = net.train;
    bn.is_this_type = (l.type == BATCHNORM);
    bn.outputs = l.outputs;
    bn.mini_batch_size = l.batch;
    bn.output = l.output;
    bn.x = l.x;
    bn.in_class_size = l.out_h*l.out_w;
    bn.out_c = l.out_c;
    bn.mean = l.mean;
    bn.variance = l.variance;
    bn.rolling_mean = l.rolling_mean;
    bn.rolling_variance = l.rolling_variance;
    bn.x_norm = l.x_norm;
    bn.scales = l.scales;
    bn.biases = l.biases;

    bn.delta = l.delta;
    bn.out_h = l.out_h;
    bn.out_w = l.out_w;
    bn.net_delta = net.delta;
    bn.bias_updates = l.bias_updates;
    bn.scale_updates = l.scale_updates;
    bn.mean_delta = l.mean_delta;
    bn.variance_delta = l.variance_delta;

    math21_ml_function_batchnorm_backward(bn);
}

#ifdef GPU

void math21_ml_net_batchnorm_layer_backward_gpu(layer l, network net)
{

    mlfunction_batchnorm bn = {0};
    bn.input = net.input;
    bn.is_train = net.train;
    bn.is_this_type = (l.type == BATCHNORM);
    bn.outputs = l.outputs;
    bn.mini_batch_size = l.batch;
    bn.output = l.output_gpu;
    bn.x = l.x_gpu;
    bn.in_class_size = l.out_h*l.out_w;
    bn.out_c = l.out_c;
    bn.mean = l.mean_gpu;
    bn.variance = l.variance_gpu;
    bn.rolling_mean = l.rolling_mean_gpu;
    bn.rolling_variance = l.rolling_variance_gpu;
    bn.x_norm = l.x_norm_gpu;
    bn.scales = l.scales_gpu;
    bn.biases = l.biases_gpu;

    bn.delta = l.delta_gpu;
    bn.out_h = l.out_h;
    bn.out_w = l.out_w;
    bn.net_delta = net.delta_gpu;
    bn.bias_updates = l.bias_updates_gpu;
    bn.scale_updates = l.scale_updates_gpu;
    bn.mean_delta = l.batchnormalization_backward_mu_gpu;
    bn.variance_delta = l.variance_delta_gpu;

    math21_ml_function_batchnorm_backward(bn);
}

void pull_batchnorm_layer(layer l)
{
    math21_cuda_pull_array(l.scales_gpu, l.scales, l.c);
    math21_cuda_pull_array(l.rolling_mean_gpu, l.rolling_mean, l.c);
    math21_cuda_pull_array(l.rolling_variance_gpu, l.rolling_variance, l.c);
}

void push_batchnorm_layer(layer l)
{
    math21_cuda_push_array(l.scales_gpu, l.scales, l.c);
    math21_cuda_push_array(l.rolling_mean_gpu, l.rolling_mean, l.c);
    math21_cuda_push_array(l.rolling_variance_gpu, l.rolling_variance, l.c);
}

void math21_ml_net_batchnorm_layer_forward_gpu(layer l, network net)
{
    mlfunction_batchnorm bn = {0};
    bn.input = net.input;
    bn.is_train = net.train;
    bn.is_this_type = (l.type == BATCHNORM);
    bn.outputs = l.outputs;
    bn.mini_batch_size = l.batch;
    bn.output = l.output_gpu;
    bn.x = l.x_gpu;
    bn.in_class_size = l.out_h*l.out_w;
    bn.out_c = l.out_c;
    bn.mean = l.mean_gpu;
    bn.variance = l.variance_gpu;
    bn.rolling_mean = l.rolling_mean_gpu;
    bn.rolling_variance = l.rolling_variance_gpu;
    bn.x_norm = l.x_norm_gpu;
    bn.scales = l.scales_gpu;
    bn.biases = l.biases_gpu;

    math21_ml_function_batchnorm_forward(bn);
}
#endif
