#include "im2col.h"
#include <stdio.h>

float math21_ml_conv_X_to_X_prime_get_value(const float *X, int nr, int nc, int nch,
                       int ir, int ic, int ich, int pad) {
    ir -= pad;
    ic -= pad;

    if (ir < 0 || ic < 0 ||
        ir >= nr || ic >= nc)
        return 0;
    return X[ic + nc * (ir + nr * ich)];
}

// X -> X_prime, X_prime: n_common*nc_Y_m
// n_common = l.size*l.size*l.c/l.groups
void math21_ml_conv_X_to_X_prime_cpu(const float *X,
                int nch_X, int nr_X, int nc_X,
                int ksize, int stride, int pad, float *X_prime) {
    int ir, ic1, ic2;
    int nc_X_prime_1 = (nr_X + 2 * pad - ksize) / stride + 1;
    int nc_X_prime_2 = (nc_X + 2 * pad - ksize) / stride + 1;

    int nr_X_prime = nch_X * ksize * ksize;
    for (ir = 0; ir < nr_X_prime; ++ir) {
        int ir_K = (ir / ksize) % ksize;
        int ic_K = ir % ksize;
        int ich_X = ir / ksize / ksize; // ich_X = ich_K
        for (ic1 = 0; ic1 < nc_X_prime_1; ++ic1) {
            for (ic2 = 0; ic2 < nc_X_prime_2; ++ic2) {
                int ir_X = ir_K + ic1 * stride;
                int ic_X = ic_K + ic2 * stride;
                int index_X_prime = (ir * nc_X_prime_1 + ic1) * nc_X_prime_2 + ic2;
                X_prime[index_X_prime] = math21_ml_conv_X_to_X_prime_get_value(X, nr_X, nc_X, nch_X,
                                                          ir_X, ic_X, ich_X, pad);
            }
        }
    }
}

