#pragma once
void math21_matrix_multiply_k1AB_add_k2C_similar_bin(int M, int N, int K, float ALPHA,
        char  *A, int lda, 
        float *B, int ldb,
        float *C, int ldc);
        
void math21_matrix_multiply_k1AB_add_k2C_similar(int TA, int TB, int M, int N, int K, float ALPHA,
                    float *A, int lda, 
                    float *B, int ldb,
                    float BETA,
                    float *C, int ldc);

void math21_matrix_multiply_k1AB_add_k2C_similar_cpu(int TA, int TB, int M, int N, int K, float ALPHA,
        float *A, int lda, 
        float *B, int ldb,
        float BETA,
        float *C, int ldc);

#ifdef GPU
void math21_matrix_multiply_k1AB_add_k2C_similar_gpu(int TA, int TB, int M, int N, int K, float ALPHA,
        float *A_gpu, int lda, 
        float *B_gpu, int ldb,
        float BETA,
        float *C_gpu, int ldc);

void math21_matrix_multiply_k1AB_add_k2C_similar_gpu(int TA, int TB, int M, int N, int K, float ALPHA,
        float *A, int lda, 
        float *B, int ldb,
        float BETA,
        float *C, int ldc);
#endif
