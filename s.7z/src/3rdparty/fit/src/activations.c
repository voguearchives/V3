#include "activations.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

ACTIVATION get_activation(char *s) {
    return (ACTIVATION) math21_function_activation_get_type(s);
}

// Y = h(X)
void math21_ml_net_activation_vector_cpu(float *x, const int n, const ACTIVATION a) {
    math21_function_activation_vector_cpu(x, n, *(MATH21_FUNCTION_ACTIVATION_TYPE *) &a);
}

// dL/dx = dL/dy *.ele f.d(x)
void math21_ml_net_activation_gradient_vector_cpu(const float *y, const int n, const ACTIVATION a, float *delta) {
    math21_function_activation_gradient_vector_cpu(y, n, *(MATH21_FUNCTION_ACTIVATION_TYPE *) &a, delta);
}

#ifdef GPU
void math21_ml_net_activation_vector_gpu(float *x, int n, ACTIVATION a)
{
    math21_function_activation_vector_wrapper(x, n, *(MATH21_FUNCTION_ACTIVATION_TYPE*)&a);
}

void math21_ml_net_activation_gradient_vector_gpu(float *x, int n, ACTIVATION a, float *delta)
{
    math21_function_activation_gradient_vector_wrapper(x, n, *(MATH21_FUNCTION_ACTIVATION_TYPE*)&a, delta);
}
#endif
