#pragma once

#include "fit.h"
#include "cuda.h"
#include "math.h"

ACTIVATION get_activation(char *s);

void math21_ml_net_activation_gradient_vector_cpu(const float *x, const int n, const ACTIVATION a, float *delta);
void math21_ml_net_activation_vector_cpu(float *x, const int n, const ACTIVATION a);
#ifdef GPU
void math21_ml_net_activation_vector_gpu(float *x, int n, ACTIVATION a);
void math21_ml_net_activation_gradient_vector_gpu(float *x, int n, ACTIVATION a, float *delta);
#endif