#ifndef LOCAL_LAYER_H
#define LOCAL_LAYER_H

#include "cuda.h"
#include "image.h"
#include "activations.h"
#include "layer.h"
#include "network.h"

typedef layer local_layer;

#ifdef GPU
void math21_ml_net_locally_connected_layer_forward_gpu(local_layer layer, network net);
void math21_ml_net_locally_connected_layer_backward_gpu(local_layer layer, network net);
void update_local_layer_gpu(local_layer layer, update_args a);

void push_local_layer(local_layer layer);
void pull_local_layer(local_layer layer);
#endif

local_layer math21_ml_net_locally_connected_layer_create(int batch, int h, int w, int c, int n, int size, int stride, int pad, ACTIVATION activation);

void math21_ml_net_locally_connected_layer_forward(const local_layer layer, network net);
void math21_ml_net_locally_connected_layer_backward(local_layer layer, network net);
void update_local_layer(local_layer layer, update_args a);
#endif

