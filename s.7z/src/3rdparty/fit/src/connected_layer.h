#ifndef CONNECTED_LAYER_H
#define CONNECTED_LAYER_H

#include "activations.h"
#include "layer.h"
#include "network.h"

layer math21_ml_net_fully_connected_layer_create(int batch, int inputs, int outputs, ACTIVATION activation, int batch_normalize, int adam);

void math21_ml_net_fully_connected_layer_forward(layer l, network net);
void math21_ml_net_fully_connected_layer_backward(layer l, network net);
void math21_ml_net_fully_connected_layer_update(layer l, update_args a);

#ifdef GPU
void math21_ml_net_fully_connected_layer_forward_gpu(layer l, network net);
void math21_ml_net_fully_connected_layer_backward_gpu(layer l, network net);
void math21_ml_net_fully_connected_layer_update_gpu(layer l, update_args a);
void push_connected_layer(layer l);
void pull_connected_layer(layer l);
#endif

#endif

