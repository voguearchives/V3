#include "convolutional_layer.h"
#include "utils.h"
#include "batchnorm_layer.h"
#include "im2col.h"
#include "col2im.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"
#include <stdio.h>
#include <time.h>

#ifdef AI2
#include "xnor_layer.h"
#endif

void swap_binary(convolutional_layer *l) {
    float *swap = l->weights;
    l->weights = l->binary_weights;
    l->binary_weights = swap;

#ifdef GPU
    swap = l->weights_gpu;
    l->weights_gpu = l->binary_weights_gpu;
    l->binary_weights_gpu = swap;
#endif
}

void binarize_weights(float *weights, int n, int size, float *binary) {
    int i, f;
    for (f = 0; f < n; ++f) {
        float mean = 0;
        for (i = 0; i < size; ++i) {
            mean += fabs(weights[f * size + i]);
        }
        mean = mean / size;
        for (i = 0; i < size; ++i) {
            binary[f * size + i] = (weights[f * size + i] > 0) ? mean : -mean;
        }
    }
}

void binarize_cpu(float *input, int n, float *binary) {
    int i;
    for (i = 0; i < n; ++i) {
        binary[i] = (input[i] > 0) ? 1 : -1;
    }
}

void binarize_input(float *input, int n, int size, float *binary) {
    int i, s;
    for (s = 0; s < size; ++s) {
        float mean = 0;
        for (i = 0; i < n; ++i) {
            mean += fabs(input[i * size + s]);
        }
        mean = mean / n;
        for (i = 0; i < n; ++i) {
            binary[i * size + s] = (input[i * size + s] > 0) ? mean : -mean;
        }
    }
}

int math21_ml_net_conv_cal_nr_Y(convolutional_layer l) {
    return (l.h + 2 * l.pad - l.size) / l.stride + 1;
}

int math21_ml_net_conv_cal_nc_Y(convolutional_layer l) {
    return (l.w + 2 * l.pad - l.size) / l.stride + 1;
}

image get_convolutional_image(convolutional_layer l) {
    return float_to_image(l.out_w, l.out_h, l.out_c, l.output);
}

image get_convolutional_delta(convolutional_layer l) {
    return float_to_image(l.out_w, l.out_h, l.out_c, l.delta);
}

size_t math21_ml_net_conv_layer_get_X_prime_size(layer l) {
    return (size_t) l.out_h * l.out_w * l.size * l.size * l.c / l.groups * sizeof(float);
}

convolutional_layer math21_ml_net_conv_layer_create(
        int mini_batch_size, int nr_X, int nc_X, int nch_X, int nch_Y, int num_group,
        int k_size, int stride, int padding, ACTIVATION activation, int is_batch_normalize,
        int binary, int xnor, int adam) {
    int i;
    convolutional_layer l = {0};
    l.type = CONVOLUTIONAL;

    l.groups = num_group;
    l.h = nr_X;
    l.w = nc_X;
    l.c = nch_X;
    l.n = nch_Y;
    l.binary = binary;
    l.xnor = xnor;
    l.batch = mini_batch_size;
    l.stride = stride;
    l.size = k_size;
    l.pad = padding;
    l.batch_normalize = is_batch_normalize;

    l.weights = math21_ml_net_io_calloc(nch_X / num_group * nch_Y * k_size * k_size, sizeof(float));
    l.weight_updates = math21_ml_net_io_calloc(nch_X / num_group * nch_Y * k_size * k_size, sizeof(float));

    l.biases = math21_ml_net_io_calloc(nch_Y, sizeof(float));
    l.bias_updates = math21_ml_net_io_calloc(nch_Y, sizeof(float));

    l.nweights = nch_X / num_group * nch_Y * k_size * k_size;
    l.nbiases = nch_Y;

    // float scale = 1./sqrt(k_size*k_size*c);
    float scale = sqrt(2. / (k_size * k_size * nch_X / l.groups));
    //printf("convscale %f\n", scale);
    //scale = .02;
    //for(i = 0; i < c*n*k_size*k_size; ++i) l.weights[i] = scale*rand_uniform(-1, 1);
    for (i = 0; i < l.nweights; ++i) l.weights[i] = scale * rand_normal();
    int nr_Y = math21_ml_net_conv_cal_nr_Y(l);
    int nc_Y = math21_ml_net_conv_cal_nc_Y(l);
    l.out_h = nr_Y;
    l.out_w = nc_Y;
    l.out_c = nch_Y;
    l.outputs = l.out_h * l.out_w * l.out_c;
    l.inputs = l.w * l.h * l.c;

    l.output = math21_ml_net_io_calloc(l.batch * l.outputs, sizeof(float));
    l.delta = math21_ml_net_io_calloc(l.batch * l.outputs, sizeof(float));

    l.forward = math21_ml_net_conv_layer_forward;
    l.backward = math21_ml_net_conv_layer_backward;
    l.update = update_convolutional_layer;
    if (binary) {
        l.binary_weights = math21_ml_net_io_calloc(l.nweights, sizeof(float));
        l.cweights = math21_ml_net_io_calloc(l.nweights, sizeof(char));
        l.scales = math21_ml_net_io_calloc(nch_Y, sizeof(float));
    }
    if (xnor) {
        l.binary_weights = math21_ml_net_io_calloc(l.nweights, sizeof(float));
        l.binary_input = math21_ml_net_io_calloc(l.inputs * l.batch, sizeof(float));
    }

    if (is_batch_normalize) {
        l.scales = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.scale_updates = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        for (i = 0; i < nch_Y; ++i) {
            l.scales[i] = 1;
        }

        l.mean = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.variance = math21_ml_net_io_calloc(nch_Y, sizeof(float));

        l.mean_delta = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.variance_delta = math21_ml_net_io_calloc(nch_Y, sizeof(float));

        l.rolling_mean = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.rolling_variance = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.x = math21_ml_net_io_calloc(l.batch * l.outputs, sizeof(float));
        l.x_norm = math21_ml_net_io_calloc(l.batch * l.outputs, sizeof(float));
    }
    if (adam) {
        l.m = math21_ml_net_io_calloc(l.nweights, sizeof(float));
        l.v = math21_ml_net_io_calloc(l.nweights, sizeof(float));
        l.bias_m = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.scale_m = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.bias_v = math21_ml_net_io_calloc(nch_Y, sizeof(float));
        l.scale_v = math21_ml_net_io_calloc(nch_Y, sizeof(float));
    }

#ifdef GPU
    l.forward_gpu = math21_ml_net_conv_layer_forward_gpu;
    l.backward_gpu = math21_ml_net_conv_layer_backward_gpu;
    l.update_gpu = update_convolutional_layer_gpu;

    if(gpu_index >= 0){
        if (adam) {
            l.m_gpu = math21_cuda_make_vector_from_cpu(l.m, l.nweights);
            l.v_gpu = math21_cuda_make_vector_from_cpu(l.v, l.nweights);
            l.bias_m_gpu = math21_cuda_make_vector_from_cpu(l.bias_m, nch_Y);
            l.bias_v_gpu = math21_cuda_make_vector_from_cpu(l.bias_v, nch_Y);
            l.scale_m_gpu = math21_cuda_make_vector_from_cpu(l.scale_m, nch_Y);
            l.scale_v_gpu = math21_cuda_make_vector_from_cpu(l.scale_v, nch_Y);
        }

        l.weights_gpu = math21_cuda_make_vector_from_cpu(l.weights, l.nweights);
        l.weight_updates_gpu = math21_cuda_make_vector_from_cpu(l.weight_updates, l.nweights);

        l.biases_gpu = math21_cuda_make_vector_from_cpu(l.biases, nch_Y);
        l.bias_updates_gpu = math21_cuda_make_vector_from_cpu(l.bias_updates, nch_Y);

        l.delta_gpu = math21_cuda_make_vector_from_cpu(l.delta, l.batch*nr_Y*nc_Y*nch_Y);
        l.output_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*nr_Y*nc_Y*nch_Y);

        if(binary){
            l.binary_weights_gpu = math21_cuda_make_vector_from_cpu(l.weights, l.nweights);
        }
        if(xnor){
            l.binary_weights_gpu = math21_cuda_make_vector_from_cpu(l.weights, l.nweights);
            l.binary_input_gpu = math21_cuda_make_vector_from_cpu(0, l.inputs*l.batch);
        }

        if(is_batch_normalize){
            l.mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, nch_Y);
            l.variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, nch_Y);

            l.rolling_mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, nch_Y);
            l.rolling_variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, nch_Y);

            l.batchnormalization_backward_mu_gpu = math21_cuda_make_vector_from_cpu(l.mean, nch_Y);
            l.variance_delta_gpu = math21_cuda_make_vector_from_cpu(l.variance, nch_Y);

            l.scales_gpu = math21_cuda_make_vector_from_cpu(l.scales, nch_Y);
            l.scale_updates_gpu = math21_cuda_make_vector_from_cpu(l.scale_updates, nch_Y);

            l.x_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*nr_Y*nc_Y*nch_Y);
            l.x_norm_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*nr_Y*nc_Y*nch_Y);
        }
    }
#endif
    l.workspace_size = math21_ml_net_conv_layer_get_X_prime_size(l);
    l.activation = activation;

    fprintf(stdout, "conv  %5d x%2d x%2d x%4d /%2d  %4d x%4d x%4d   ->  %4d x%4d x%4d  %5.3f BFLOPs\n", nch_Y, k_size,
            k_size, nch_X, stride, nr_X, nc_X, nch_X, l.out_h, l.out_w, l.out_c,
            (2.0 * l.n * l.size * l.size * l.c / l.groups * l.out_h * l.out_w) / 1000000000.);

    return l;
}

void denormalize_convolutional_layer(convolutional_layer l) {
    int i, j;
    for (i = 0; i < l.n; ++i) {
        float scale = l.scales[i] / sqrt(l.rolling_variance[i] + .00001);
        for (j = 0; j < l.c / l.groups * l.size * l.size; ++j) {
            l.weights[i * l.c / l.groups * l.size * l.size + j] *= scale;
        }
        l.biases[i] -= l.rolling_mean[i] * scale;
        l.scales[i] = 1;
        l.rolling_mean[i] = 0;
        l.rolling_variance[i] = 1;
    }
}

/*
void test_convolutional_layer()
{
    convolutional_layer l = math21_ml_net_conv_layer_create(1, 5, 5, 3, 2, 5, 2, 1, LEAKY, 1, 0, 0, 0);
    l.batch_normalize = 1;
    float data[] = {1,1,1,1,1,
        1,1,1,1,1,
        1,1,1,1,1,
        1,1,1,1,1,
        1,1,1,1,1,
        2,2,2,2,2,
        2,2,2,2,2,
        2,2,2,2,2,
        2,2,2,2,2,
        2,2,2,2,2,
        3,3,3,3,3,
        3,3,3,3,3,
        3,3,3,3,3,
        3,3,3,3,3,
        3,3,3,3,3};
    //net.input = data;
    //math21_ml_net_conv_layer_forward(l);
}
*/

void resize_convolutional_layer(convolutional_layer *l, int w, int h) {
    l->w = w;
    l->h = h;
    int out_w = math21_ml_net_conv_cal_nc_Y(*l);
    int out_h = math21_ml_net_conv_cal_nr_Y(*l);

    l->out_w = out_w;
    l->out_h = out_h;

    l->outputs = l->out_h * l->out_w * l->out_c;
    l->inputs = l->w * l->h * l->c;

    l->output = math21_ml_net_io_realloc(l->output, l->batch * l->outputs * sizeof(float));
    l->delta = math21_ml_net_io_realloc(l->delta, l->batch * l->outputs * sizeof(float));
    if (l->batch_normalize) {
        l->x = math21_ml_net_io_realloc(l->x, l->batch * l->outputs * sizeof(float));
        l->x_norm = math21_ml_net_io_realloc(l->x_norm, l->batch * l->outputs * sizeof(float));
    }

#ifdef GPU
    math21_ml_cuda_free(l->delta_gpu);
    math21_ml_cuda_free(l->output_gpu);

    l->delta_gpu =  math21_cuda_make_vector_from_cpu(l->delta,  l->batch*l->outputs);
    l->output_gpu = math21_cuda_make_vector_from_cpu(l->output, l->batch*l->outputs);

    if(l->batch_normalize){
        math21_ml_cuda_free(l->x_gpu);
        math21_ml_cuda_free(l->x_norm_gpu);

        l->x_gpu = math21_cuda_make_vector_from_cpu(l->output, l->batch*l->outputs);
        l->x_norm_gpu = math21_cuda_make_vector_from_cpu(l->output, l->batch*l->outputs);
    }
#endif
    l->workspace_size = math21_ml_net_conv_layer_get_X_prime_size(*l);
}

//  Z = h(Y), Y = W*X + b, or Y = X*W.t + b
//  Y_m = K_m * X_prime + b ...
void math21_ml_net_conv_layer_forward(convolutional_layer l, network net) {
    int imb, j;

    // Y_m = 0
    math21_vector_set_cpu(l.outputs * l.batch, 0, l.output, 1);

    if (l.xnor) {
        binarize_weights(l.weights, l.n, l.c / l.groups * l.size * l.size, l.binary_weights);
        swap_binary(&l);
        binarize_cpu(net.input, l.c * l.h * l.w * l.batch, l.binary_input);
        net.input = l.binary_input;
    }

    int nr_Y_m = l.n / l.groups;
    int n_common = l.size * l.size * l.c / l.groups;
    int nc_Y_m = l.out_w * l.out_h;
    for (imb = 0; imb < l.batch; ++imb) {
        for (j = 0; j < l.groups; ++j) {
            float *K_m = l.weights + j * l.nweights / l.groups;
            float *X_prime = net.workspace;
            float *Y_m = l.output + (imb * l.groups + j) * nc_Y_m * nr_Y_m;
            float *X = net.input + (imb * l.groups + j) * l.c / l.groups * l.h * l.w;

            if (l.size == 1) {
                X_prime = X;
            } else {
                // X -> X_prime
                math21_ml_conv_X_to_X_prime_cpu(X, l.c / l.groups, l.h, l.w, l.size, l.stride, l.pad, X_prime);
            }
            // Y_m = K_m * X_prime + Y_m, K_m: nr_Y_m*n_common, X_prime: n_common*nc_Y_m, Y_m: nr_Y_m*nc_Y_m
            math21_matrix_multiply_k1AB_add_k2C_similar(0, 0, nr_Y_m, nc_Y_m, n_common, 1, K_m, n_common, X_prime,
                                                        nc_Y_m, 1, Y_m, nc_Y_m);
        }
    }

    if (l.batch_normalize) {
        // ...
        math21_ml_net_batchnorm_layer_forward(l, net);
    } else {
        // Y += b
        math21_vector_x_add_b_with_in_class_wrapper(l.output, l.biases, l.batch, l.n, l.out_h * l.out_w);
    }

    // Z = h(Y)
    math21_ml_net_activation_vector_cpu(l.output, l.outputs * l.batch, l.activation);
    if (l.binary || l.xnor) swap_binary(&l);
}

// dL/dZ => dL/dK, dL/dX
void math21_ml_net_conv_layer_backward(convolutional_layer l, network net) {
    int imb, j;
    int nr_dK_m = l.n / l.groups;
    int nc_dK_m = l.size * l.size * l.c / l.groups;
    int nc_dY_m = l.out_w * l.out_h;

    // dL/dY = dL/dZ *.ele h.d(Y)
    math21_ml_net_activation_gradient_vector_cpu(l.output, l.outputs * l.batch, l.activation, l.delta);

    if (l.batch_normalize) {
        math21_ml_net_batchnorm_layer_backward(l, net);
    } else {
        // dL/db += sum(dL/dY(i))
        math21_ml_conv_bias_backward(l.bias_updates, l.delta, l.batch, l.n, nc_dY_m);
    }

    for (imb = 0; imb < l.batch; ++imb) {
        for (j = 0; j < l.groups; ++j) {
            float *dY_m = l.delta + (imb * l.groups + j) * nr_dK_m * nc_dY_m;
            float *dK_m = l.weight_updates + j * l.nweights / l.groups;
            float *X_prime = net.workspace;

            float *X = net.input + (imb * l.groups + j) * l.c / l.groups * l.h * l.w;

            if (l.size == 1) {
                X_prime = X;
            } else {
                // X -> X_prime
                math21_ml_conv_X_to_X_prime_cpu(X, l.c / l.groups, l.h, l.w,
                                                l.size, l.stride, l.pad, X_prime);
            }
            // dL/dW += dL/dY * X.t
            // dL/dK_m += dL/dY_m * X_prime.t
            math21_matrix_multiply_k1AB_add_k2C_similar(0, 1, nr_dK_m, nc_dK_m, nc_dY_m, 1, dY_m, nc_dY_m, X_prime,
                                                        nc_dY_m, 1, dK_m, nc_dK_m);

            if (net.delta) {
                float *dX = net.delta + (imb * l.groups + j) * l.c / l.groups * l.h * l.w;

                float *K_m = l.weights + j * l.nweights / l.groups;
                float *dX_prime = net.workspace;
                if (l.size == 1) {
                    dX_prime = dX;
                }

                // dL/dX = W.t * dL/dY
                // dL/dX_prime = K_m.t * dL/dY_m
                math21_matrix_multiply_k1AB_add_k2C_similar(1, 0, nc_dK_m, nc_dY_m, nr_dK_m, 1, K_m, nc_dK_m, dY_m,
                                                            nc_dY_m, 0, dX_prime, nc_dY_m);

                if (l.size != 1) {
                    // dX_prime -> dX
                    math21_ml_conv_dX_prime_to_dX_cpu(dX_prime, l.c / l.groups, l.h, l.w, l.size, l.stride, l.pad, dX);
                }
            }
        }
    }
}

void update_convolutional_layer(convolutional_layer l, update_args a) {
    float learning_rate = a.learning_rate * l.learning_rate_scale;
    float momentum = a.momentum;
    float decay = a.decay;
    int batch = a.batch;

    // b = b - alpha * dL/db
    // l.bias_updates = -dL/db because of loss function L is -L.
    math21_vector_kx_add_y_wrapper(l.n, learning_rate / batch, l.bias_updates, 1, l.biases, 1);
    // dL/db = momentum * dL/db
    math21_vector_kx_wrapper(l.n, momentum, l.bias_updates, 1);

    if (l.scales) {
        math21_vector_kx_add_y_wrapper(l.n, learning_rate / batch, l.scale_updates, 1, l.scales, 1);
        math21_vector_kx_wrapper(l.n, momentum, l.scale_updates, 1);
    }

    // dL/dW = dL/dW + decay * W
    math21_vector_kx_add_y_wrapper(l.nweights, -decay * batch, l.weights, 1, l.weight_updates, 1);
    // W = W - alpha * dL/dW
    math21_vector_kx_add_y_wrapper(l.nweights, learning_rate / batch, l.weight_updates, 1, l.weights, 1);
    // dL/dW = momentum * dL/dW
    math21_vector_kx_wrapper(l.nweights, momentum, l.weight_updates, 1);
}


image get_convolutional_weight(convolutional_layer l, int i) {
    int h = l.size;
    int w = l.size;
    int c = l.c / l.groups;
    return float_to_image(w, h, c, l.weights + i * h * w * c);
}

void rgbgr_weights(convolutional_layer l) {
    int i;
    for (i = 0; i < l.n; ++i) {
        image im = get_convolutional_weight(l, i);
        if (im.c == 3) {
            rgbgr_image(im);
        }
    }
}

void rescale_weights(convolutional_layer l, float scale, float trans) {
    int i;
    for (i = 0; i < l.n; ++i) {
        image im = get_convolutional_weight(l, i);
        if (im.c == 3) {
            scale_image(im, scale);
            float sum = math21_vector_sum(im.data, im.w * im.h * im.c);
            l.biases[i] += sum * trans;
        }
    }
}

image *get_weights(convolutional_layer l) {
    image *weights = math21_ml_net_io_calloc(l.n, sizeof(image));
    int i;
    for (i = 0; i < l.n; ++i) {
        weights[i] = copy_image(get_convolutional_weight(l, i));
        normalize_image(weights[i]);
        /*
           char buff[256];
           sprintf(buff, "filter%d", i);
           save_image(weights[i], buff);
         */
    }
    //error("hey");
    return weights;
}

image *visualize_convolutional_layer(convolutional_layer l, char *window, image *prev_weights) {
    image *single_weights = get_weights(l);
    show_images(single_weights, l.n, window);

    image delta = get_convolutional_image(l);
    image dc = collapse_image_layers(delta, 1);
    char buff[256];
    sprintf(buff, "%s: Output", window);
    //show_image(dc, buff);
    //save_image(dc, buff);
    free_image(dc);
    return single_weights;
}

