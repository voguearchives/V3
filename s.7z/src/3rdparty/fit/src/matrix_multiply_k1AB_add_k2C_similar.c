#include "matrix_multiply_k1AB_add_k2C_similar.h"
#include "utils.h"
#include "cuda.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

void math21_matrix_multiply_k1AB_add_k2C_similar_bin(int M, int N, int K, float ALPHA,
        char  *A, int lda, 
        float *B, int ldb,
        float *C, int ldc)
{
    int i,j,k;
    for(i = 0; i < M; ++i){
        for(k = 0; k < K; ++k){
            char A_PART = A[i*lda+k];
            if(A_PART){
                for(j = 0; j < N; ++j){
                    C[i*ldc+j] += B[k*ldb+j];
                }
            } else {
                for(j = 0; j < N; ++j){
                    C[i*ldc+j] -= B[k*ldb+j];
                }
            }
        }
    }
}

float *random_matrix(int rows, int cols)
{
    int i;
    float *m = math21_ml_net_io_calloc(rows*cols, sizeof(float));
    for(i = 0; i < rows*cols; ++i){
        m[i] = (float)rand()/RAND_MAX;
    }
    return m;
}

void time_random_matrix(int TA, int TB, int m, int k, int n)
{
    float *a;
    if(!TA) a = random_matrix(m,k);
    else a = random_matrix(k,m);
    int lda = (!TA)?k:m;
    float *b;
    if(!TB) b = random_matrix(k,n);
    else b = random_matrix(n,k);
    int ldb = (!TB)?n:k;

    float *c = random_matrix(m,n);
    int i;
    clock_t start = clock(), end;
    for(i = 0; i<10; ++i){
        math21_matrix_multiply_k1AB_add_k2C_similar_cpu(TA,TB,m,n,k,1,a,lda,b,ldb,1,c,n);
    }
    end = clock();
    printf("Matrix Multiplication %dx%d * %dx%d, TA=%d, TB=%d: %lf ms\n",m,k,k,n, TA, TB, (float)(end-start)/CLOCKS_PER_SEC);
    free(a);
    free(b);
    free(c);
}

// math21_matrix_multiply_k1AB_add_k2C_similar
// C = k1*(A*B) + k2*C or similar
void math21_matrix_multiply_k1AB_add_k2C_similar(int TA, int TB, int nr_C, int nc_C, int n_common, float k1,
        float *A, int lda,
        float *B, int ldb,
        float k2,
        float *C, int ldc)
{
    math21_matrix_multiply_k1AB_add_k2C_similar_cpu( TA,  TB,  nr_C, nc_C, n_common, k1,A,lda, B, ldb,k2,C,ldc);
}

// C = alpha*A*B + C
void math21_matrix_multiply_k1AB_add_k2C_similar_nn(int nr_C, int nc_C, int n_common, float alpha,
        float *A, int lda,
        float *B, int ldb,
        float *C, int ldc)
{
    int i,j,k;
    #pragma omp parallel for
    for(i = 0; i < nr_C; ++i){
        for(k = 0; k < n_common; ++k){
            register float A_PART = alpha*A[i*lda+k];
            for(j = 0; j < nc_C; ++j){
                C[i*ldc+j] += A_PART*B[k*ldb+j];
            }
        }
    }
}

// C = alpha*A*B.t + C
void math21_matrix_multiply_k1AB_add_k2C_similar_nt(int nr_C, int nc_C, int n_common, float alpha,
        float *A, int lda, 
        float *B, int ldb,
        float *C, int ldc)
{
    int i,j,k;
    #pragma omp parallel for
    for(i = 0; i < nr_C; ++i){
        for(j = 0; j < nc_C; ++j){
            register float sum = 0;
            for(k = 0; k < n_common; ++k){
                sum += alpha*A[i*lda+k]*B[j*ldb + k];
            }
            C[i*ldc+j] += sum;
        }
    }
}

// C = alpha*A.t*B + C
void math21_matrix_multiply_k1AB_add_k2C_similar_tn(int nr_C, int nc_C, int n_common, float alpha,
        float *A, int lda, 
        float *B, int ldb,
        float *C, int ldc)
{
    int i,j,k;
    #pragma omp parallel for
    for(i = 0; i < nr_C; ++i){
        for(k = 0; k < n_common; ++k){
            register float A_PART = alpha*A[k*lda+i];
            for(j = 0; j < nc_C; ++j){
                C[i*ldc+j] += A_PART*B[k*ldb+j];
            }
        }
    }
}

// C = alpha*A.t*B.t + C
void math21_matrix_multiply_k1AB_add_k2C_similar_tt(int nr_C, int nc_C, int n_common, float alpha,
        float *A, int lda, 
        float *B, int ldb,
        float *C, int ldc)
{
    int i,j,k;
    #pragma omp parallel for
    for(i = 0; i < nr_C; ++i){
        for(j = 0; j < nc_C; ++j){
            register float sum = 0;
            for(k = 0; k < n_common; ++k){
                sum += alpha*A[i+k*lda]*B[k+j*ldb];
            }
            C[i*ldc+j] += sum;
        }
    }
}


void math21_matrix_multiply_k1AB_add_k2C_similar_cpu(int TA, int TB, int nr_C, int nc_C, int n_common, float alpha,
        float *A, int lda, 
        float *B, int ldb,
        float beta,
        float *C, int ldc)
{
    //printf("cpu: %d %d %d %d %d %f %d %d %f %d\n",TA, TB, M, N, K, alpha, lda, ldb, beta, ldc);
    int i, j;
    for(i = 0; i < nr_C; ++i){
        for(j = 0; j < nc_C; ++j){
            C[i*ldc + j] *= beta;
        }
    }
    if(!TA && !TB)
        math21_matrix_multiply_k1AB_add_k2C_similar_nn(nr_C, nc_C, n_common, alpha,A,lda, B, ldb,C,ldc);
    else if(TA && !TB)
        math21_matrix_multiply_k1AB_add_k2C_similar_tn(nr_C, nc_C, n_common, alpha,A,lda, B, ldb,C,ldc);
    else if(!TA && TB)
        math21_matrix_multiply_k1AB_add_k2C_similar_nt(nr_C, nc_C, n_common, alpha,A,lda, B, ldb,C,ldc);
    else
        math21_matrix_multiply_k1AB_add_k2C_similar_tt(nr_C, nc_C, n_common, alpha,A,lda, B, ldb,C,ldc);
}

#ifdef GPU

#include <math.h>

void math21_matrix_multiply_k1AB_add_k2C_similar_gpu(int TA, int TB, int M, int N, int K, float ALPHA,
        float *A_gpu, int lda, 
        float *B_gpu, int ldb,
        float BETA,
        float *C_gpu, int ldc)
{
    cublasHandle_t handle = blas_handle();
    cudaError_t status = cublasSgemm(handle, (TB ? CUBLAS_OP_T : CUBLAS_OP_N), 
            (TA ? CUBLAS_OP_T : CUBLAS_OP_N), N, M, K, &ALPHA, B_gpu, ldb, A_gpu, lda, &BETA, C_gpu, ldc);
    math21_cuda_check_error(status);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void time_gpu_random_matrix(int TA, int TB, int m, int k, int n)
{
    float *a;
    if(!TA) a = random_matrix(m,k);
    else a = random_matrix(k,m);
    int lda = (!TA)?k:m;
    float *b;
    if(!TB) b = random_matrix(k,n);
    else b = random_matrix(n,k);
    int ldb = (!TB)?n:k;

    float *c = random_matrix(m,n);
    int i;
    clock_t start = clock(), end;
    for(i = 0; i<32; ++i){
        math21_matrix_multiply_k1AB_add_k2C_similar_gpu(TA,TB,m,n,k,1,a,lda,b,ldb,1,c,n);
    }
    end = clock();
    printf("Matrix Multiplication %dx%d * %dx%d, TA=%d, TB=%d: %lf s\n",m,k,k,n, TA, TB, (float)(end-start)/CLOCKS_PER_SEC);
    free(a);
    free(b);
    free(c);
}

void time_gpu(int TA, int TB, int m, int k, int n)
{
    int iter = 10;
    float *a = random_matrix(m,k);
    float *b = random_matrix(k,n);

    int lda = (!TA)?k:m;
    int ldb = (!TB)?n:k;

    float *c = random_matrix(m,n);

    float *a_cl = math21_cuda_make_vector_from_cpu(a, m*k);
    float *b_cl = math21_cuda_make_vector_from_cpu(b, k*n);
    float *c_cl = math21_cuda_make_vector_from_cpu(c, m*n);

    int i;
    clock_t start = clock(), end;
    for(i = 0; i<iter; ++i){
        math21_matrix_multiply_k1AB_add_k2C_similar_gpu(TA,TB,m,n,k,1,a_cl,lda,b_cl,ldb,1,c_cl,n);
        cudaDeviceSynchronize();
    }
    double flop = ((double)m)*n*(2.*k + 2.)*iter;
    double gflop = flop/pow(10., 9);
    end = clock();
    double seconds = sec(end-start);
    printf("Matrix Multiplication %dx%d * %dx%d, TA=%d, TB=%d: %lf s, %lf GFLOPS\n",m,k,k,n, TA, TB, seconds, gflop/seconds);
    math21_ml_cuda_free(a_cl);
    math21_ml_cuda_free(b_cl);
    math21_ml_cuda_free(c_cl);
    free(a);
    free(b);
    free(c);
}


void test_gpu_accuracy(int TA, int TB, int m, int k, int n)
{
    srand(0);
    float *a;
    if(!TA) a = random_matrix(m,k);
    else a = random_matrix(k,m);
    int lda = (!TA)?k:m;
    float *b;
    if(!TB) b = random_matrix(k,n);
    else b = random_matrix(n,k);
    int ldb = (!TB)?n:k;

    float *c = random_matrix(m,n);
    float *c_gpu = random_matrix(m,n);
    memset(c, 0, m*n*sizeof(float));
    memset(c_gpu, 0, m*n*sizeof(float));
    int i;
    //pm(m,k,b);
    math21_matrix_multiply_k1AB_add_k2C_similar_gpu(TA,TB,m,n,k,1,a,lda,b,ldb,1,c_gpu,n);
    //printf("GPU\n");
    //pm(m, n, c_gpu);

    math21_matrix_multiply_k1AB_add_k2C_similar_cpu(TA,TB,m,n,k,1,a,lda,b,ldb,1,c,n);
    //printf("\n\nCPU\n");
    //pm(m, n, c);
    double sse = 0;
    for(i = 0; i < m*n; ++i) {
        //printf("%f %f\n", c[i], c_gpu[i]);
        sse += pow(c[i]-c_gpu[i], 2);
    }
    printf("Matrix Multiplication %dx%d * %dx%d, TA=%d, TB=%d: %g SSE\n",m,k,k,n, TA, TB, sse/(m*n));
    free(a);
    free(b);
    free(c);
    free(c_gpu);
}

int test_gpu_blas()
{
    /*
       test_gpu_accuracy(0,0,10,576,75); 

       test_gpu_accuracy(0,0,17,10,10); 
       test_gpu_accuracy(1,0,17,10,10); 
       test_gpu_accuracy(0,1,17,10,10); 
       test_gpu_accuracy(1,1,17,10,10); 

       test_gpu_accuracy(0,0,1000,10,100); 
       test_gpu_accuracy(1,0,1000,10,100); 
       test_gpu_accuracy(0,1,1000,10,100); 
       test_gpu_accuracy(1,1,1000,10,100); 

       test_gpu_accuracy(0,0,10,10,10); 

       time_gpu(0,0,64,2916,363); 
       time_gpu(0,0,64,2916,363); 
       time_gpu(0,0,64,2916,363); 
       time_gpu(0,0,192,729,1600); 
       time_gpu(0,0,384,196,1728); 
       time_gpu(0,0,256,196,3456); 
       time_gpu(0,0,256,196,2304); 
       time_gpu(0,0,128,4096,12544); 
       time_gpu(0,0,128,4096,4096); 
     */
    time_gpu(0,0,64,75,12544); 
    time_gpu(0,0,64,75,12544); 
    time_gpu(0,0,64,75,12544); 
    time_gpu(0,0,64,576,12544); 
    time_gpu(0,0,256,2304,784); 
    time_gpu(1,1,2304,256,784); 
    time_gpu(0,0,512,4608,196); 
    time_gpu(1,1,4608,512,196); 

    return 0;
}
#endif

