// Oh boy, why am I about to do this....
#ifndef NETWORK_H
#define NETWORK_H
#include "fit.h"

#include "image.h"
#include "layer.h"
#include "data.h"
#include "tree.h"


#ifdef GPU
void pull_network_output(network *net);
#endif

void compare_networks(network *n1, network *n2, data d);
char *get_layer_string(LAYER_TYPE a);


mlfunction_node *math21_ml_function_node_create();

// user should set node to 0 after the call.
void math21_ml_function_node_destroy(mlfunction_node *node);

network *make_network(int n);


float network_accuracy_multi(network *net, data d, int n);
int get_predicted_class_network(network *net);
void print_network(network *net);
int resize_network(network *net, int w, int h);
void math21_ml_net_calculate_cost(network *net);

#endif

