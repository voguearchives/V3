#include "yolo_layer.h"
#include "activations.h"
#include "blas.h"
#include "cuda.h"
#include "utils.h"

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

layer math21_ml_function_convert_yolo_to_layer(mlfunction_yolo f) {
    layer l = {0};
    if (f.is_this_type) {
        l.type = YOLO;
    }
    l.n = f.n;
    l.total = f.total;
    l.batch = f.batch;
    l.h = f.h;
    l.w = f.w;
    l.c = f.c;
    l.out_h = f.out_h;
    l.out_w = f.out_w;
    l.out_c = f.out_c;
    l.classes = f.classes;
    l.cost = f.cost;
    l.biases = f.biases;
    l.mask = f.mask;
    l.bias_updates = f.bias_updates;
    l.outputs = f.outputs;
    l.inputs = f.inputs;
    l.truths = f.truths;
    l.output = f.output;
    l.delta = f.delta;
    l.output = f.output;
    l.delta = f.delta;
#ifndef GPU
    l.forward = f.forward;
    l.backward = f.backward;
#else
    l.output_gpu = f.output_gpu;
    l.delta_gpu = f.delta_gpu;
    l.forward_gpu = f.forward;
    l.backward_gpu = f.backward;
#endif
    l.map = f.map;
    l.max_boxes = f.max_boxes;
    l.ignore_thresh = f.ignore_thresh;
    l.truth_thresh = f.truth_thresh;
    l.onlyforward = f.onlyforward;
    return l;
}

void math21_ml_function_convert_net_to_yolo(mlfunction_yolo *f, const network* net) {
    f->net_train = net->train;
    f->net_truth = net->truth;
    f->net_h = net->h;
    f->net_w = net->w;
    f->net_index = net->index;
    f->net_input = net->input;
    f->net_delta = net->delta;
#ifdef GPU
    f->net_input_gpu = net->input_gpu;
    f->net_delta_gpu = net->delta_gpu;
#endif
}

mlfunction_yolo math21_ml_function_convert_layer_to_yolo(layer f) {
    mlfunction_yolo l = {0};
    l.is_this_type = (f.type == YOLO);
    l.n = f.n;
    l.total = f.total;
    l.batch = f.batch;
    l.h = f.h;
    l.w = f.w;
    l.c = f.c;
    l.out_h = f.out_h;
    l.out_w = f.out_w;
    l.out_c = f.out_c;
    l.classes = f.classes;
    l.cost = f.cost;
    l.biases = f.biases;
    l.mask = f.mask;
    l.bias_updates = f.bias_updates;
    l.outputs = f.outputs;
    l.inputs = f.inputs;
    l.truths = f.truths;
    l.output = f.output;
    l.delta = f.delta;
    l.output = f.output;
    l.delta = f.delta;
#ifndef GPU
    l.forward = f.forward;
    l.backward = f.backward;
#else
    l.output_gpu= f.output_gpu;
    l.delta_gpu= f.delta_gpu;
    l.forward = f.forward_gpu;
    l.backward = f.backward_gpu;
#endif
    l.map = f.map;
    l.max_boxes = f.max_boxes;
    l.ignore_thresh = f.ignore_thresh;
    l.truth_thresh = f.truth_thresh;
    l.onlyforward = f.onlyforward;
    return l;
}

layer make_yolo_layer(int mini_batch_size, int nc_grids, int nr_grids, int num_box, int total_prior, int *prior_mask,
                      int num_class) {
    mlfunction_yolo f = math21_ml_function_yolo_create(mini_batch_size, nc_grids, nr_grids, num_box, total_prior,
                                                       prior_mask, num_class);
    layer l = math21_ml_function_convert_yolo_to_layer(f);
#ifndef GPU
    l.forward = forward_yolo_layer;
    l.backward = backward_yolo_layer;
#else
    l.forward_gpu = forward_yolo_layer_gpu;
    l.backward_gpu = backward_yolo_layer_gpu;
#endif
    return l;
}

void resize_yolo_layer(layer *l, int w, int h) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(*l);
    math21_ml_function_yolo_resize(&f, w, h);
    *l = math21_ml_function_convert_yolo_to_layer(f);
}

void forward_yolo_layer(const layer l, network net) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    math21_ml_function_convert_net_to_yolo(&f, &net);
    math21_ml_function_yolo_forward_cpu(f);
}

void backward_yolo_layer(const layer l, network net) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    math21_ml_function_convert_net_to_yolo(&f, &net);
    math21_ml_function_yolo_backward_cpu(f);
}

int yolo_num_detections(layer l, float thresh) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    return math21_ml_function_yolo_num_detections(f, thresh);
}

int get_yolo_detections(layer l, int w, int h, int netw, int neth, float thresh, int *map, int relative, detection *dets) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    return math21_ml_function_yolo_get_detections(f, w, h, netw, neth, thresh, map, relative, dets);
}

#ifdef GPU

void forward_yolo_layer_gpu(const layer l, network net) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    math21_ml_function_convert_net_to_yolo(&f, &net);
    math21_ml_function_yolo_forward_cuda(f);
}

void backward_yolo_layer_gpu(const layer l, network net) {
    mlfunction_yolo f = math21_ml_function_convert_layer_to_yolo(l);
    math21_ml_function_convert_net_to_yolo(&f, &net);
    math21_ml_function_yolo_backward_cuda(f);
}

#endif

