#include "route_layer.h"
#include "cuda.h"
#include "blas.h"

#include <stdio.h>

typedef struct mlfunction_route mlfunction_route;

struct mlfunction_route {
    void *forward; // function pointer
    void *backward; // function pointer
    int mini_batch_size;
    int num_layer;
    int   * input_layers;
    int   * input_sizes;
    int inputs; // x_size, no batch
    int outputs; // y_size, no batch
    int out_h, out_w, out_c; // nr_Y, nc_Y, nch_Y
    float * output; // Y, with batch
    float * delta; // dL/dY
};

void math21_ml_function_convert_route_to_layer(const mlfunction_route *f, layer *l) {
    l->type = ROUTE;
    l->batch = f->mini_batch_size;
    l->n = f->num_layer;
    l->input_layers = f->input_layers;
    l->input_sizes = f->input_sizes;
    l->outputs = f->outputs;
    l->inputs = f->inputs;
    l->out_h = f->out_h;
    l->out_w = f->out_w;
    l->out_c = f->out_c;
#ifndef GPU
    l->output = f->output;
    l->delta = f->delta;
    l->forward = f->forward;
    l->backward = f->backward;
#else
    l->output_gpu = f->output;
    l->delta_gpu = f->delta;
    l->forward_gpu = f->forward;
    l->backward_gpu = f->backward;
#endif
}

void math21_ml_function_convert_layer_to_route(const layer *f, mlfunction_route *l) {
    l->mini_batch_size = f->batch;
    l->num_layer = f->n;
    l->input_layers = f->input_layers;
    l->input_sizes = f->input_sizes;
    l->outputs = f->outputs;
    l->inputs = f->inputs;
    l->out_h = f->out_h;
    l->out_w = f->out_w;
    l->out_c = f->out_c;
#ifndef GPU
    l->output = f->output;
    l->delta = f->delta;
    l->forward = f->forward;
    l->backward = f->backward;
#else
    l->output = f->output_gpu;
    l->delta = f->delta_gpu;
    l->forward = f->forward_gpu;
    l->backward = f->backward_gpu;
#endif
}

// y has shape (nch, nr, nc)
mlfunction_route math21_ml_function_route_create(network *net, int mini_batch_size, int num_layer, int *input_layers)
{
    fprintf(stdout,"route  ");
    mlfunction_route l = {0};
    l.mini_batch_size = mini_batch_size;
    l.num_layer = num_layer;
    l.input_layers = input_layers;
    l.input_sizes = math21_ml_net_io_calloc(num_layer, sizeof(int));

    int i;
    layer first = net->layers[l.input_layers[0]];
    fprintf(stdout," %d", l.input_layers[0]);
    l.out_w = first.out_w;
    l.out_h = first.out_h;
    l.out_c = first.out_c;
    l.outputs = first.outputs;
    l.input_sizes[0] = first.outputs;
    for(i = 1; i < l.num_layer; ++i){
        int index = l.input_layers[i];
        fprintf(stdout," %d", l.input_layers[i]);
        layer next = net->layers[index];
        l.outputs += next.outputs;
        l.input_sizes[i] = next.outputs;
        if(next.out_w == first.out_w && next.out_h == first.out_h){
            l.out_c += next.out_c;
        }else{
            printf("%d %d, %d %d\n", next.out_w, next.out_h, first.out_w, first.out_h);
            math21_error("route fail"); // ye add
            l.out_h = l.out_w = l.out_c = 0;
        }
    }
    l.inputs = l.outputs;
    fprintf(stdout, "\n");

#ifndef GPU
    l.output = math21_ml_net_io_calloc(mini_batch_size*l.outputs, sizeof(float));
    l.delta =  math21_ml_net_io_calloc(mini_batch_size*l.outputs, sizeof(float));
#else
    l.output = math21_cuda_make_vector_from_cpu(0, mini_batch_size*l.outputs);
    l.delta =  math21_cuda_make_vector_from_cpu(0, mini_batch_size*l.outputs);
#endif
    return l;
}

void math21_ml_function_route_resize(mlfunction_route *l, network *net)
{
    int i;
    layer first = net->layers[l->input_layers[0]];
    l->out_w = first.out_w;
    l->out_h = first.out_h;
    l->out_c = first.out_c;
    l->outputs = first.outputs;
    l->input_sizes[0] = first.outputs;
    for(i = 1; i < l->num_layer; ++i){
        int index = l->input_layers[i];
        layer next = net->layers[index];
        l->outputs += next.outputs;
        l->input_sizes[i] = next.outputs;
        if(next.out_w == first.out_w && next.out_h == first.out_h){
            l->out_c += next.out_c;
        }else{
            printf("%d %d, %d %d\n", next.out_w, next.out_h, first.out_w, first.out_h);
            math21_error("route fail"); // ye add
            l->out_h = l->out_w = l->out_c = 0;
        }
    }
    l->inputs = l->outputs;

#ifndef GPU
    l->output = math21_ml_net_io_realloc(l->output, l->outputs*l->mini_batch_size*sizeof(float));
    l->delta =  math21_ml_net_io_realloc(l->delta, l->outputs*l->mini_batch_size*sizeof(float));
#else
    math21_ml_cuda_free(l->output);
    math21_ml_cuda_free(l->delta);
    l->output  = math21_cuda_make_vector_from_cpu(0, l->outputs*l->mini_batch_size);
    l->delta   = math21_cuda_make_vector_from_cpu(0,  l->outputs*l->mini_batch_size);
#endif
}

route_layer make_route_layer(network *net, int mini_batch_size, int num_layer, int *input_layers)
{
    mlfunction_route f = math21_ml_function_route_create(net, mini_batch_size, num_layer, input_layers);
    route_layer l = {0};
    math21_ml_function_convert_route_to_layer(&f, &l);
#ifndef GPU
    l.forward = forward_route_layer;
    l.backward = backward_route_layer;
#else
    l.forward_gpu = forward_route_layer_gpu;
    l.backward_gpu = backward_route_layer_gpu;
#endif
    return l;
}

void resize_route_layer(route_layer *l, network *net)
{
    mlfunction_route f = {0};
    math21_ml_function_convert_layer_to_route(l, &f);
    math21_ml_function_route_resize(&f, net);
    math21_ml_function_convert_route_to_layer(&f, l);
}

// concatenate convolution features
// Y = (X1, Xn), Y = (y1, yb), Xi = (xi1, xib), yb = (x1b, xnb)
void math21_ml_function_route_forward_wrapper(const mlfunction_route l, network net)
{
    int ilayer, imb;
    int offset = 0;
    for(ilayer = 0; ilayer < l.num_layer; ++ilayer){
        int index = l.input_layers[ilayer];
#ifndef GPU
        float *input = net.layers[index].output;
#else
        float *input = net.layers[index].output_gpu;
#endif
        int input_size = l.input_sizes[ilayer];
        // Y <- Xi
        for(imb = 0; imb < l.mini_batch_size; ++imb){
            // yb <- xib
            // x and y have same stride because of same shape order.
            math21_vector_assign_from_vector_wrapper(input_size, input + imb*input_size, 1, l.output + offset + imb*l.outputs, 1);
        }
        offset += input_size;
    }
}

// (dX1, dXn) += dY, dY = (dy1, dyb), dXi = (dxi1, dxib), (dx1b, dxnb) += dyb
void math21_ml_function_route_backward_wrapper(const mlfunction_route l, network net)
{
    int ilayer, imb;
    int offset = 0;
    for(ilayer = 0; ilayer < l.num_layer; ++ilayer){
        int index = l.input_layers[ilayer];
#ifndef GPU
        float *delta = net.layers[index].delta;
#else
        float *delta = net.layers[index].delta_gpu;
#endif
        int input_size = l.input_sizes[ilayer];
        for(imb = 0; imb < l.mini_batch_size; ++imb){
            math21_vector_kx_add_y_wrapper(input_size, 1, l.delta + offset + imb*l.outputs, 1, delta + imb*input_size, 1);
        }
        offset += input_size;
    }
}

void forward_route_layer(const route_layer l, network net)
{
    mlfunction_route f = {0};
    math21_ml_function_convert_layer_to_route(&l, &f);
    math21_ml_function_route_forward_wrapper(f, net);
}

void backward_route_layer(const route_layer l, network net)
{
    mlfunction_route f = {0};
    math21_ml_function_convert_layer_to_route(&l, &f);
    math21_ml_function_route_backward_wrapper(f, net);
}

#ifdef GPU
void forward_route_layer_gpu(const route_layer l, network net)
{
    mlfunction_route f = {0};
    math21_ml_function_convert_layer_to_route(&l, &f);
    math21_ml_function_route_forward_wrapper(f, net);
}

void backward_route_layer_gpu(const route_layer l, network net)
{
    mlfunction_route f = {0};
    math21_ml_function_convert_layer_to_route(&l, &f);
    math21_ml_function_route_backward_wrapper(f, net);
}
#endif
