#include "connected_layer.h"
#include "convolutional_layer.h"
#include "batchnorm_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "matrix_multiply_k1AB_add_k2C_similar.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Z = h(Y), Y = X*W.t + b
layer math21_ml_net_fully_connected_layer_create(int batch_size, int input_size, int output_size, ACTIVATION activation, int is_batch_normalize, int is_adam) {
    int i;
    layer l = {0};
    l.learning_rate_scale = 1;
    l.type = CONNECTED;

    l.inputs = input_size;
    l.outputs = output_size;
    l.batch = batch_size;
    l.batch_normalize = is_batch_normalize;
    l.h = 1;
    l.w = 1;
    l.c = input_size;
    l.out_h = 1;
    l.out_w = 1;
    l.out_c = output_size;

    l.output = math21_ml_net_io_calloc(batch_size * output_size, sizeof(float));
    l.delta = math21_ml_net_io_calloc(batch_size * output_size, sizeof(float));

    l.weight_updates = math21_ml_net_io_calloc( output_size* input_size, sizeof(float));
    l.bias_updates = math21_ml_net_io_calloc(output_size, sizeof(float));

    l.weights = math21_ml_net_io_calloc(output_size * input_size, sizeof(float));
    l.biases = math21_ml_net_io_calloc(output_size, sizeof(float));

    l.forward = math21_ml_net_fully_connected_layer_forward;
    l.backward = math21_ml_net_fully_connected_layer_backward;
    l.update = math21_ml_net_fully_connected_layer_update;

    //float scale = 1./sqrt(input_size);
    float scale = sqrt(2. / input_size);
    for (i = 0; i < output_size * input_size; ++i) {
        l.weights[i] = scale * rand_uniform(-1, 1);
    }

    for (i = 0; i < output_size; ++i) {
        l.biases[i] = 0;
    }

    // ..
    if (is_adam) {
        l.m = math21_ml_net_io_calloc(l.inputs * l.outputs, sizeof(float));
        l.v = math21_ml_net_io_calloc(l.inputs * l.outputs, sizeof(float));
        l.bias_m = math21_ml_net_io_calloc(l.outputs, sizeof(float));
        l.scale_m = math21_ml_net_io_calloc(l.outputs, sizeof(float));
        l.bias_v = math21_ml_net_io_calloc(l.outputs, sizeof(float));
        l.scale_v = math21_ml_net_io_calloc(l.outputs, sizeof(float));
    }
    if (is_batch_normalize) {
        l.scales = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.scale_updates = math21_ml_net_io_calloc(output_size, sizeof(float));
        for (i = 0; i < output_size; ++i) {
            l.scales[i] = 1;
        }

        l.mean = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.mean_delta = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.variance = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.variance_delta = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.rolling_mean = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.rolling_variance = math21_ml_net_io_calloc(output_size, sizeof(float));
        l.x = math21_ml_net_io_calloc(batch_size * output_size, sizeof(float));
        l.x_norm = math21_ml_net_io_calloc(batch_size * output_size, sizeof(float));
    }

#ifdef GPU
    l.forward_gpu = math21_ml_net_fully_connected_layer_forward_gpu;
    l.backward_gpu = math21_ml_net_fully_connected_layer_backward_gpu;
    l.update_gpu = math21_ml_net_fully_connected_layer_update_gpu;

    l.weights_gpu = math21_cuda_make_vector_from_cpu(l.weights, output_size*input_size);
    l.biases_gpu = math21_cuda_make_vector_from_cpu(l.biases, output_size);

    l.weight_updates_gpu = math21_cuda_make_vector_from_cpu(l.weight_updates, output_size*input_size);
    l.bias_updates_gpu = math21_cuda_make_vector_from_cpu(l.bias_updates, output_size);

    l.output_gpu = math21_cuda_make_vector_from_cpu(l.output, output_size*batch_size);
    l.delta_gpu = math21_cuda_make_vector_from_cpu(l.delta, output_size*batch_size);
    if (is_adam) {
        l.m_gpu =       math21_cuda_make_vector_from_cpu(0, input_size*output_size);
        l.v_gpu =       math21_cuda_make_vector_from_cpu(0, input_size*output_size);
        l.bias_m_gpu =  math21_cuda_make_vector_from_cpu(0, output_size);
        l.bias_v_gpu =  math21_cuda_make_vector_from_cpu(0, output_size);
        l.scale_m_gpu = math21_cuda_make_vector_from_cpu(0, output_size);
        l.scale_v_gpu = math21_cuda_make_vector_from_cpu(0, output_size);
    }

    if(is_batch_normalize){
        l.mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, output_size);
        l.variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, output_size);

        l.rolling_mean_gpu = math21_cuda_make_vector_from_cpu(l.mean, output_size);
        l.rolling_variance_gpu = math21_cuda_make_vector_from_cpu(l.variance, output_size);

        l.batchnormalization_backward_mu_gpu = math21_cuda_make_vector_from_cpu(l.mean, output_size);
        l.variance_delta_gpu = math21_cuda_make_vector_from_cpu(l.variance, output_size);

        l.scales_gpu = math21_cuda_make_vector_from_cpu(l.scales, output_size);
        l.scale_updates_gpu = math21_cuda_make_vector_from_cpu(l.scale_updates, output_size);

        l.x_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*output_size);
        l.x_norm_gpu = math21_cuda_make_vector_from_cpu(l.output, l.batch*output_size);
    }
#endif
    l.activation = activation;
    fprintf(stderr, "fully connected                            %4d  ->  %4d\n", input_size, output_size);
    return l;
}

void math21_ml_net_fully_connected_layer_update(layer l, update_args a) {
    float learning_rate = a.learning_rate * l.learning_rate_scale;
    float momentum = a.momentum;
    float decay = a.decay;
    int batch = a.batch;

    math21_vector_kx_add_y_wrapper(l.outputs, learning_rate / batch, l.bias_updates, 1, l.biases, 1);
    math21_vector_kx_wrapper(l.outputs, momentum, l.bias_updates, 1);

    if (l.batch_normalize) {
        math21_vector_kx_add_y_wrapper(l.outputs, learning_rate / batch, l.scale_updates, 1, l.scales, 1);
        math21_vector_kx_wrapper(l.outputs, momentum, l.scale_updates, 1);
    }

    math21_vector_kx_add_y_wrapper(l.inputs * l.outputs, -decay * batch, l.weights, 1, l.weight_updates, 1);
    math21_vector_kx_add_y_wrapper(l.inputs * l.outputs, learning_rate / batch, l.weight_updates, 1, l.weights, 1);
    math21_vector_kx_wrapper(l.inputs * l.outputs, momentum, l.weight_updates, 1);
}

// Z = h(Y), Y = W*X + b, or Y = X*W.t + b
void math21_ml_net_fully_connected_layer_forward(layer l, network net) {
    math21_vector_set_cpu(l.outputs * l.batch, 0, l.output, 1);
    int sb = l.batch;
    int sx = l.inputs;
    int sy = l.outputs;
    float *x = net.input;
    float *w = l.weights;
    float *y = l.output;
    // Y += X*W.t
    math21_matrix_multiply_k1AB_add_k2C_similar(0, 1, sb, sy, sx, 1, x, sx, w, sx, 1, y, sy);
    if (l.batch_normalize) {
        // Y = BN(Y)
        math21_ml_net_batchnorm_layer_forward(l, net);
    } else {
        // Y += b
        math21_vector_x_add_b_with_in_class_wrapper(l.output, l.biases, l.batch, l.outputs, 1);
    }
    // Z = h(Y)
    math21_ml_net_activation_vector_cpu(l.output, l.outputs * l.batch, l.activation);
}

// Z = h(Y), Y = W*X + b, or Y = X*W.t + b
// dL/dZ => dL/dW, dL/dX
void math21_ml_net_fully_connected_layer_backward(layer l, network net) {
    // dL/dY = dL/dZ *.ele h.d(Y)
    math21_ml_net_activation_gradient_vector_cpu(l.output, l.outputs * l.batch, l.activation, l.delta);

    if (l.batch_normalize) {
        math21_ml_net_batchnorm_layer_backward(l, net);
    } else {
        // dL/db += sum(dL/dY(i))
        math21_ml_conv_bias_backward(l.bias_updates, l.delta, l.batch, l.outputs, 1);
    }

    int m = l.outputs;
    int k = l.batch;
    int n = l.inputs;
    float *a = l.delta;
    float *b = net.input;
    float *c = l.weight_updates;
    // dL/dW += dL/dY * X.t
    math21_matrix_multiply_k1AB_add_k2C_similar(1, 0, m, n, k, 1, a, m, b, n, 1, c, n);

    m = l.batch;
    k = l.outputs;
    n = l.inputs;

    a = l.delta;
    b = l.weights;
    c = net.delta;

    // dL/dX = W.t * dL/dY
    // but here is addTo dX ...
    if (net.delta) math21_matrix_multiply_k1AB_add_k2C_similar(0, 0, m, n, k, 1, a, k, b, n, 1, c, n);
}

void denormalize_connected_layer(layer l) {
    int i, j;
    for (i = 0; i < l.outputs; ++i) {
        float scale = l.scales[i] / sqrt(l.rolling_variance[i] + .000001);
        for (j = 0; j < l.inputs; ++j) {
            l.weights[i * l.inputs + j] *= scale;
        }
        l.biases[i] -= l.rolling_mean[i] * scale;
        l.scales[i] = 1;
        l.rolling_mean[i] = 0;
        l.rolling_variance[i] = 1;
    }
}


void statistics_connected_layer(layer l) {
    if (l.batch_normalize) {
        printf("Scales ");
        print_statistics(l.scales, l.outputs);
        /*
           printf("Rolling Mean ");
           print_statistics(l.rolling_mean, l.outputs);
           printf("Rolling Variance ");
           print_statistics(l.rolling_variance, l.outputs);
         */
    }
    printf("Biases ");
    print_statistics(l.biases, l.outputs);
    printf("Weights ");
    print_statistics(l.weights, l.outputs);
}

#ifdef GPU

void pull_connected_layer(layer l)
{
    math21_cuda_pull_array(l.weights_gpu, l.weights, l.inputs*l.outputs);
    math21_cuda_pull_array(l.biases_gpu, l.biases, l.outputs);
    math21_cuda_pull_array(l.weight_updates_gpu, l.weight_updates, l.inputs*l.outputs);
    math21_cuda_pull_array(l.bias_updates_gpu, l.bias_updates, l.outputs);
    if (l.batch_normalize){
        math21_cuda_pull_array(l.scales_gpu, l.scales, l.outputs);
        math21_cuda_pull_array(l.rolling_mean_gpu, l.rolling_mean, l.outputs);
        math21_cuda_pull_array(l.rolling_variance_gpu, l.rolling_variance, l.outputs);
    }
}

void push_connected_layer(layer l)
{
    math21_cuda_push_array(l.weights_gpu, l.weights, l.inputs*l.outputs);
    math21_cuda_push_array(l.biases_gpu, l.biases, l.outputs);
    math21_cuda_push_array(l.weight_updates_gpu, l.weight_updates, l.inputs*l.outputs);
    math21_cuda_push_array(l.bias_updates_gpu, l.bias_updates, l.outputs);
    if (l.batch_normalize){
        math21_cuda_push_array(l.scales_gpu, l.scales, l.outputs);
        math21_cuda_push_array(l.rolling_mean_gpu, l.rolling_mean, l.outputs);
        math21_cuda_push_array(l.rolling_variance_gpu, l.rolling_variance, l.outputs);
    }
}

void math21_ml_net_fully_connected_layer_update_gpu(layer l, update_args a)
{
    float learning_rate = a.learning_rate*l.learning_rate_scale;
    float momentum = a.momentum;
    float decay = a.decay;
    int batch = a.batch;
    if(a.adam){
        adam_update_gpu(l.weights_gpu, l.weight_updates_gpu, l.m_gpu, l.v_gpu, a.B1, a.B2, a.eps, decay, learning_rate, l.inputs*l.outputs, batch, a.t);
        adam_update_gpu(l.biases_gpu, l.bias_updates_gpu, l.bias_m_gpu, l.bias_v_gpu, a.B1, a.B2, a.eps, decay, learning_rate, l.outputs, batch, a.t);
        if(l.scales_gpu){
            adam_update_gpu(l.scales_gpu, l.scale_updates_gpu, l.scale_m_gpu, l.scale_v_gpu, a.B1, a.B2, a.eps, decay, learning_rate, l.outputs, batch, a.t);
        }
    }else{
        math21_vector_kx_add_y_wrapper(l.outputs, learning_rate/batch, l.bias_updates_gpu, 1, l.biases_gpu, 1);
        math21_vector_kx_wrapper(l.outputs, momentum, l.bias_updates_gpu, 1);

        if(l.batch_normalize){
            math21_vector_kx_add_y_wrapper(l.outputs, learning_rate/batch, l.scale_updates_gpu, 1, l.scales_gpu, 1);
            math21_vector_kx_wrapper(l.outputs, momentum, l.scale_updates_gpu, 1);
        }

        math21_vector_kx_add_y_wrapper(l.inputs*l.outputs, -decay*batch, l.weights_gpu, 1, l.weight_updates_gpu, 1);
        math21_vector_kx_add_y_wrapper(l.inputs*l.outputs, learning_rate/batch, l.weight_updates_gpu, 1, l.weights_gpu, 1);
        math21_vector_kx_wrapper(l.inputs*l.outputs, momentum, l.weight_updates_gpu, 1);
    }
}

void math21_ml_net_fully_connected_layer_forward_gpu(layer l, network net)
{
    math21_vector_set_wrapper(l.outputs*l.batch, 0, l.output_gpu, 1);

    int m = l.batch;
    int k = l.inputs;
    int n = l.outputs;
    float * a = net.input_gpu;
    float * b = l.weights_gpu;
    float * c = l.output_gpu;
    math21_matrix_multiply_k1AB_add_k2C_similar_gpu(0,1,m,n,k,1,a,k,b,k,1,c,n);

    if (l.batch_normalize) {
        math21_ml_net_batchnorm_layer_forward_gpu(l, net);
    } else {
        math21_vector_x_add_b_with_in_class_wrapper(l.output_gpu, l.biases_gpu, l.batch, l.outputs, 1);
    }
    math21_ml_net_activation_vector_gpu(l.output_gpu, l.outputs*l.batch, l.activation);
}

void math21_ml_net_fully_connected_layer_backward_gpu(layer l, network net)
{
    constrain_gpu(l.outputs*l.batch, 1, l.delta_gpu, 1);
    math21_ml_net_activation_gradient_vector_gpu(l.output_gpu, l.outputs*l.batch, l.activation, l.delta_gpu);
    if(l.batch_normalize){
        math21_ml_net_batchnorm_layer_backward_gpu(l, net);
    } else {
        math21_ml_conv_bias_backward(l.bias_updates_gpu, l.delta_gpu, l.batch, l.outputs, 1);
    }

    int m = l.outputs;
    int k = l.batch;
    int n = l.inputs;
    float * a = l.delta_gpu;
    float * b = net.input_gpu;
    float * c = l.weight_updates_gpu;
    math21_matrix_multiply_k1AB_add_k2C_similar_gpu(1,0,m,n,k,1,a,m,b,n,1,c,n);

    m = l.batch;
    k = l.outputs;
    n = l.inputs;

    a = l.delta_gpu;
    b = l.weights_gpu;
    c = net.delta_gpu;

    if(c) math21_matrix_multiply_k1AB_add_k2C_similar_gpu(0,0,m,n,k,1,a,k,b,n,1,c,n);
}
#endif
