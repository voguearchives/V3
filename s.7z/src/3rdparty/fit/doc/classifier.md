## final Train The Model
./fit classifier train config/cifar.data config/cifar_small.cfg


/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit classifier train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar_small.cfg -gpus 0,1


/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit classifier train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar_small.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/cifar_small.theta

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit classifier train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar_small.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/backup/cifar_small_1.theta


D:/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit classifier train D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar.data.win D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar_small.cfg D:/Yolsa/download/tmp/vision/assets/fit/assets/cifar_small.theta


./fit classifier train config/cifar.data config/cifar_small.cfg

## final Validate The Model

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit classifier valid  /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/cifar_small.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/cifar_small.theta


# Get The Data
cd data
wget https://pjreddie.com/media/files/cifar.tgz
tar xzf cifar.tgz

cat cifar/labels.txt

cd cifar
find `pwd`/train -name \*.png > train.list
find `pwd`/test -name \*.png > test.list
cd ../..


# Make A Dataset Config File

open up a new file in the cfg/ directory called
cfg/cifar.data

classes=10
train  = data/cifar/train.list
valid  = data/cifar/test.list
labels = data/cifar/labels.txt
backup = backup/
top=2


# Make A Network Config File
cfg/cifar_small.cfg

``
[net]
batch=128
subdivisions=1
height=28
width=28
channels=3
max_crop=32
min_crop=32

hue=.1
saturation=.75
exposure=.75

learning_rate=0.1
policy=poly
power=4
max_batches = 5000
momentum=0.9
decay=0.0005

[convolutional]
batch_normalize=1
filters=32
size=3
stride=1
pad=1
activation=leaky

[maxpool]
size=2
stride=2

[convolutional]
batch_normalize=1
filters=16
size=1
stride=1
pad=1
activation=leaky

[convolutional]
batch_normalize=1
filters=64
size=3
stride=1
pad=1
activation=leaky

[maxpool]
size=2
stride=2

[convolutional]
batch_normalize=1
filters=32
size=1
stride=1
pad=1
activation=leaky

[convolutional]
batch_normalize=1
filters=128
size=3
stride=1
pad=1
activation=leaky

[convolutional]
batch_normalize=1
filters=64
size=1
stride=1
pad=1
activation=leaky

[convolutional]
filters=10
size=1
stride=1
pad=1
activation=leaky

[avgpool]

[softmax]

``
# Train The Model

./fit classifier train config/cifar.data config/cifar_small.cfg

## Restarting Training
./fit classifier train config/cifar.data config/cifar_small.cfg backup/cifar_small.backup

# Validate The Model

./fit classifier valid config/cifar.data config/cifar_small.cfg backup/cifar_small.backup


