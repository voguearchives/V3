##
./fit classify /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/tiny.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/tiny.weights /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/imagenet1k.data /home/yol/Yolsa/download/tmp/vision/assets/fit/data/dog.jpg

##
wget https://pjreddie.com/media/files/tiny.weights
### fit classify cfg/tiny.cfg tiny.weights data/dog.jpg
./fit classify cfg/tiny.cfg assets/tiny.weights data/dog.jpg
fit classify tiny.cfg tiny.weights dog.jpg