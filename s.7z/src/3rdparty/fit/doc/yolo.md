## final
./darknet detector train cfg/coco.data cfg/yolov3.cfg darknet53.conv.74

./darknet detector train D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/coco.data

D:/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detector train D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/coco.data.win D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3.cfg

D:/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detector train D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/coco.data.win D:/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3-tiny.cfg

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detector train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/coco.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3.cfg


./fit detect /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3-tiny.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/yolov3-tiny.weights /home/yol/Yolsa/download/tmp/vision/assets/fit/data/coco.names /home/yol/Yolsa/download/tmp/vision/assets/fit/data/dog.jpg

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detect /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3-tiny.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/yolov3-tiny.weights /home/yol/Yolsa/download/tmp/vision/assets/fit/data/coco.names /home/yol/Yolsa/download/tmp/vision/assets/ABC/IMG_1300.JPG

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detect /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/backup/yolov3_300.theta /home/yol/Yolsa/download/tmp/vision/assets/fit/data/coco.names /home/yol/Yolsa/download/tmp/vision/assets/ABC/IMG_1300.JPG

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detect /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3-tiny.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/yolov3-tiny.weights /home/yol/Yolsa/download/tmp/vision/assets/fit/data/coco.names /home/yol/Yolsa/download/tmp/vision/assets/fit/data/dog.jpg

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit detect /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/yolov3-tiny.cfg /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/yolov3-tiny.weights /home/yol/Yolsa/download/tmp/vision/assets/fit/data/coco.names /home/yol/Yolsa/download/tmp/vision/assets/ABC/IMG_1300.JPG

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/darknet/dn  detector train app/my_captcha/my_captcha.data app/my_captcha/my_captcha_train.yolov3.cfg darknet53.conv.74  -gpus 0,1

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit  detector train app/my_captcha/my_captcha.data app/my_captcha/my_captcha_train.yolov3.cfg darknet53.conv.74  -gpus 0,1

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/darknet/dn detect /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha_valid.yolov3.cfg /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/backup/my_captcha_train_800.weights /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/images_data/JPEGImages/0_15793183319780664.jpg

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/darknet/dn detect /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha_valid.yolov3.cfg /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/backup/my_captcha_train_800.weights /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/images_data/JPEGImages/258_15793183607076762.jpg


/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit  detect  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha_train.yolov3.cfg /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/backup/my_captcha_train_200.theta  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha.names /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/images_data/JPEGImages/0_15793183319780664.jpg


/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit  detect  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha_train.yolov3.cfg /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/backup/my_captcha_train_200.theta  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha.names /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/images_data/JPEGImages/258_15793183607076762.jpg



/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit  detect  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha_train.yolov3.cfg /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/backup/my_captcha_train_200.theta  /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/my_captcha.names /home/yol/Yolsa/download/tmp/vision/darknet_captcha-master/app/my_captcha/images_data/JPEGImages/281_1579318363219096.jpg


classifier train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/mnist.data /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/mnist_lenet.cfg -gpus 0,1

# run
wget https://pjreddie.com/media/files/yolov3.weights
./fit detect cfg/yolov3.cfg yolov3.weights data/dog.jpg

## ./darknet detector test cfg/coco.data cfg/yolov3.cfg yolov3.weights data/dog.jpg
./darknet detect cfg/yolov3.cfg yolov3.weights data/dog.jpg -thresh 0


wget https://pjreddie.com/media/files/yolov3-tiny.weights
./darknet detect cfg/yolov3-tiny.cfg yolov3-tiny.weights data/dog.jpg
fit detect cfg/yolov3-tiny.cfg yolov3-tiny.weights data/dog.jpg

# Training YOLO on VOC

### Get The Pascal VOC Data

wget https://pjreddie.com/media/files/VOCtrainval_11-May-2012.tar
wget https://pjreddie.com/media/files/VOCtrainval_06-Nov-2007.tar
wget https://pjreddie.com/media/files/VOCtest_06-Nov-2007.tar
tar xf VOCtrainval_11-May-2012.tar
tar xf VOCtrainval_06-Nov-2007.tar
tar xf VOCtest_06-Nov-2007.tar

### Generate Labels for VOC

wget https://pjreddie.com/media/files/voc_label.py
python voc_label.py

cat 2007_train.txt 2007_val.txt 2012_*.txt > train.txt

### Modify Cfg for Pascal Data

cfg/voc.data
  1 classes= 20
  2 train  = <path-to-voc>/train.txt
  3 valid  = <path-to-voc>2007_test.txt
  4 names = data/voc.names
  5 backup = backup

### Download Pretrained Convolutional Weights
wget https://pjreddie.com/media/files/darknet53.conv.74


### Train The Model
./darknet detector train cfg/voc.data cfg/yolov3-voc.cfg darknet53.conv.74


# Training YOLO on COCO

### Get The COCO Data
cp scripts/get_coco_dataset.sh data
cd data
bash get_coco_dataset.sh


### Modify cfg for COCO

change the cfg/coco.data config file

 1 classes= 80
  2 train  = <path-to-coco>/trainvalno5k.txt
  3 valid  = <path-to-coco>/5k.txt
  4 names = data/coco.names
  5 backup = backup

 modify your model cfg for training instead of testing. cfg/yolo.cfg

### Train The Model

./darknet detector train cfg/coco.data cfg/yolov3.cfg darknet53.conv.74

./darknet detector train cfg/coco.data cfg/yolov3.cfg darknet53.conv.74 -gpus 0,1,2,3

./darknet detector train cfg/coco.data cfg/yolov3.cfg backup/yolov3.backup -gpus 0,1,2,3
