## final

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit rnn train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/rnn.train.cfg -file /home/yol/Yolsa/download/tmp/vision/assets/fit/assets/input.txt

./fit rnn train config/rnn.train.cfg -file config/rnn.train.cfg

./fit rnn train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/rnn.train.cfg -file /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/rnn.train.cfg

/home/yol/Yolsa/download/tmp/vision/cmake-build-debug/src/3rdparty/star/src/3rdparty/fit/fit rnn train /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/rnn.train.cfg -file /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/config/rnn.train.cfg


# Generating Text with Darknet

./darknet rnn generate cfg/rnn.cfg <weights>

-len <int>: change the length of text generated, default 1,000
-seed <string>: seed the RNN with the given string, default "\n"
-srand <int>: seed the random number generator, for repeatable runs
-temp <float>: set the temperature for sampling, default 0.7

#
wget https://pjreddie.com/media/files/grrm.weights
./fit rnn generate config/rnn.cfg assets/grrm.weights -srand 0 -seed Alice
./fit rnn generate config/rnn.cfg rnn.backup -srand 0 -seed Alice


#
wget https://pjreddie.com/media/files/shakespeare.weights
./darknet rnn generate cfg/rnn.cfg shakespeare.weights -srand 0


# Train Your Own Model

The model will save periodic backups to the directory specified in src/rnn.c
in the function star_net_train_char_rnn,
you probably want to change this directory to a good location for your machine.


###./fit rnn train cfg/rnn.train.cfg -file data.txt
###
./fit rnn train cfg/rnn.train.cfg -file data/9k.names
./fit rnn train config/rnn.train.cfg -file data/coco.names
./fit rnn train config/rnn.train.cfg -file assets/input.txt
./fit rnn train config/rnn.train.cfg -file /home/yol/Yolsa/download/tmp/vision/src/3rdparty/star/src/3rdparty/fit/assets/input.txt
fit rnn train rnn.train.cfg -file data.txt

### ./darknet rnn train cfg/rnn.train.cfg backup/rnn.train.backup -file data.txt
### ./fit rnn train cfg/rnn.train.cfg backup/rnn.train.backup -file data.txt
fit rnn train rnn.train.cfg rnn.train.backup -file data.txt

rnn train config/rnn.train.cfg -file data/coco.names

