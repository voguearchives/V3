/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "vector_cpu.h"


// mu = E(X)
// X shape: mini_batch_size*features_size*in_class_size
// rnn: in_class_size=1
// cnn: in_class_size=nr_Y*nc_Y
void math21_vector_mean_cpu(const float *X, int mini_batch_size, int features_size, int in_class_size, float *mean) {
    float scale = 1.f / (mini_batch_size * in_class_size);
    int ifeature, imb, imember;
    for (ifeature = 0; ifeature < features_size; ++ifeature) {
        mean[ifeature] = 0;
        for (imb = 0; imb < mini_batch_size; ++imb) {
            for (imember = 0; imember < in_class_size; ++imember) {
                int index = imb * features_size * in_class_size + ifeature * in_class_size + imember;
                mean[ifeature] += X[index];
            }
        }
        mean[ifeature] *= scale;
    }
}

// sigma_square = Var(X) if in_class_size is 1.
void
math21_vector_variance_cpu(const float *X, const float *mean, int mini_batch_size, int features_size, int in_class_size,
                           float *variance) {
    float scale = 1.f / (mini_batch_size * in_class_size - 1);
    int ifeature, imb, imember;
    for (ifeature = 0; ifeature < features_size; ++ifeature) {
        variance[ifeature] = 0;
        for (imb = 0; imb < mini_batch_size; ++imb) {
            for (imember = 0; imember < in_class_size; ++imember) {
                int index = imb * features_size * in_class_size + ifeature * in_class_size + imember;
                variance[ifeature] += pow((X[index] - mean[ifeature]), 2);
            }
        }
        variance[ifeature] *= scale;
    }
}

// y = x, y(i) = x(i)
void math21_vector_assign_from_vector_cpu(int n, const float *x, int stride_x, float *y, int stride_y) {
    int i;
    for (i = 0; i < n; ++i) y[i * stride_y] = x[i * stride_x];
}

// x = k*x
void math21_vector_kx_cpu(int n, float k, float *x, int stride_x) {
    int i;
    for (i = 0; i < n; ++i) x[i * stride_x] *= k;
}

// y = k*x + y
void math21_vector_kx_add_y_cpu(int n, float k, const float *x, int stride_x, float *y, int stride_y) {
    int i;
    for (i = 0; i < n; ++i) y[i * stride_y] += k * x[i * stride_x];
}

void
math21_vector_normalize_cpu(float *x, const float *mean, const float *variance, int mini_batch_size, int features_size,
                            int in_class_size) {
    int b, f, i;
    for (b = 0; b < mini_batch_size; ++b) {
        for (f = 0; f < features_size; ++f) {
            for (i = 0; i < in_class_size; ++i) {
                int index = b * features_size * in_class_size + f * in_class_size + i;
                x[index] = (x[index] - mean[f]) / (sqrt(variance[f]) + .000001f);
            }
        }
    }
}

// y = k*x
void math21_vector_kx_with_in_class_cpu(float *x, const float *k, int mini_batch_size, int features_size, int in_class_size) {
    int imb, ifeature, imember;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ifeature = 0; ifeature < features_size; ++ifeature) {
            for (imember = 0; imember < in_class_size; ++imember) {
                x[(imb * features_size + ifeature) * in_class_size + imember] *= k[ifeature];
            }
        }
    }
}

// Y = X + b
// Y(imb, ifeature) = X(imb, ifeature) + b(ifeature)
// Y(imb, ifeature, imember) = X(imb, ifeature, imember) + b(ifeature)
void math21_vector_x_add_b_with_in_class_cpu(float *x, const float *b, int mini_batch_size, int features_size, int in_class_size) {
    int imb, ifeature, imember;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ifeature = 0; ifeature < features_size; ++ifeature) {
            for (imember = 0; imember < in_class_size; ++imember) {
                x[(imb * features_size + ifeature) * in_class_size + imember] += b[ifeature];
            }
        }
    }
}

float math21_vector_sum_cpu(const float *v, int n) {
    int i;
    float sum = 0;
    for (i = 0; i < n; ++i) sum += v[i];
    return sum;
}

// Y = W*X + b, dL/db += sum(dL/dY(i))
// db(ifeature) = sum(dY(ib, ifeature, imember))
void math21_vector_sum_with_in_class_cpu(float *db, const float *dY, int mini_batch_size, int features_size, int in_class_size) {
    int ifeature, imb;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ifeature = 0; ifeature < features_size; ++ifeature) {
            db[ifeature] += math21_vector_sum_cpu(dY + (imb * features_size + ifeature) * in_class_size, in_class_size);
        }
    }
}

// Y = k*X + b, dL/dk += sum(dL/dY(i) *.ele X(i))
void math21_vector_sum_SchurProduct_with_in_class_cpu(float *X, float *dY, int mini_batch_size, int features_size, int in_class_size, float *dk)
{
    int imb,ifeature,imember;
    for(ifeature = 0; ifeature < features_size; ++ifeature){
        float sum = 0;
        for(imb = 0; imb < mini_batch_size; ++imb){
            for(imember = 0; imember < in_class_size; ++imember){
                int index = (imb * features_size + ifeature)*in_class_size + imember ;
                sum += dY[index] * X[index];
            }
        }
        dk[ifeature] += sum;
    }
}

void math21_vector_set_cpu(int n, float value, float *x, int stride)
{
    int i;
    for(i = 0; i < n; ++i) x[i*stride] = value;
}

// Y <- kx*X + ky*Y
// Y(imb, ich, ir*stride_y, ic*stride_y) <- kx * X(imb, ich, ir*stride_x, ic*stride_x) + ky * Y(imb, ich, ir*stride_y, ic*stride_y)
void math21_vector_feature2d_add_2_cpu(
        int mini_batch_size,
        float kx, const float *X, int nch_X, int nr_X, int nc_X,
        float ky, float *Y, int nch_Y, int nr_Y, int nc_Y){

    int nch = math21_number_min_2_int(nch_X, nch_Y);
    int nr = math21_number_min_2_int(nr_X, nr_Y);
    int nc = math21_number_min_2_int(nc_X, nc_Y);

    float stride_r_x = (float) nr_X / nr;
    float stride_r_y = (float) nr_Y / nr;
    float stride_c_x = (float) nc_X / nc;
    float stride_c_y = (float) nc_Y / nc;

    int ic, ir, ich, imb;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ich = 0; ich < nch; ++ich) {
            for (ir = 0; ir < nr; ++ir) {
                for (ic = 0; ic < nc; ++ic) {
                    // X(imb, ich, ir*stride_r_x, ic*stride_c_x)
                    int index_X = (int) (((imb * nch_X + ich) * nr_X + ir * stride_r_x) * nc_X + ic * stride_c_x);
                    // Y(imb, ich, ir*stride_r_y, ic*stride_c_y)
                    int index_Y = (int) (((imb * nch_Y + ich) * nr_Y + ir * stride_r_y) * nc_Y + ic * stride_c_y);
                    Y[index_Y] = kx * X[index_X] + ky * Y[index_Y];
                }
            }
        }
    }
}

// Y <- kx1*X1 + kx2*X2 + ky*Y
// Y(imb, ich, ir*stride_y, ic*stride_y) <- kx * X(imb, ich, ir*stride_x, ic*stride_x) + ky * Y(imb, ich, ir*stride_y, ic*stride_y)
void math21_vector_feature2d_add_3_cpu(
        int mini_batch_size,
        float kx, const float *X, int nch_X, int nr_X, int nc_X,
        float kx2, const float *X2, int nch_X2, int nr_X2, int nc_X2,
        float ky, float *Y, int nch_Y, int nr_Y, int nc_Y) {

    int nch = math21_number_min_3_int(nch_X, nch_X2, nch_Y);
    int nr = math21_number_min_3_int(nr_X, nr_X2, nr_Y);
    int nc = math21_number_min_3_int(nc_X, nc_X2, nc_Y);

    float stride_r_x = (float) nr_X / nr;
    float stride_r_x2 = (float) nr_X2 / nr;
    float stride_r_y = (float) nr_Y / nr;
    float stride_c_x = (float) nc_X / nc;
    float stride_c_x2 = (float) nc_X2 / nc;
    float stride_c_y = (float) nc_Y / nc;

    int ic, ir, ich, imb;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ich = 0; ich < nch; ++ich) {
            for (ir = 0; ir < nr; ++ir) {
                for (ic = 0; ic < nc; ++ic) {
                    // X(imb, ich, ir*stride_r_x, ic*stride_c_x)
                    int index_X = (int) (((imb * nch_X + ich) * nr_X + ir * stride_r_x) * nc_X + ic * stride_c_x);
                    // X2(imb, ich, ir*stride_r_x2, ic*stride_c_x2)
                    int index_X2 = (int) (((imb * nch_X2 + ich) * nr_X2 + ir * stride_r_x2) * nc_X2 + ic * stride_c_x2);
                    // Y(imb, ich, ir*stride_r_y, ic*stride_c_y)
                    int index_Y = (int) (((imb * nch_Y + ich) * nr_Y + ir * stride_r_y) * nc_Y + ic * stride_c_y);
                    Y[index_Y] = kx * X[index_X] + kx2 * X2[index_X2] + ky * Y[index_Y];
                }
            }
        }
    }
}

// Y <- k * upsample(X)
// X <- k * downsample(Y), downsample is sumdownsample
void math21_vector_feature2d_sample_cpu(
        int mini_batch_size,
        float *X, int nch_X, int nr_X, int nc_X, int stride_X, int is_upsample, float k, float *Y) {
    int ic, ir, ich, imb;
    for (imb = 0; imb < mini_batch_size; ++imb) {
        for (ich = 0; ich < nch_X; ++ich) {
            for (ir = 0; ir < nr_X * stride_X; ++ir) {
                for (ic = 0; ic < nc_X * stride_X; ++ic) {
                    int index_X = imb * nch_X * nr_X * nc_X + ich * nr_X * nc_X + (ir / stride_X) * nc_X + ic / stride_X;
                    int index_Y =
                            imb * nch_X * nr_X * nc_X * stride_X * stride_X + ich * nc_X * nr_X * stride_X * stride_X + ir * nc_X * stride_X +
                            ic;
                    // upsample
                    if (is_upsample) Y[index_Y] += k * X[index_X];
                        // sumdownsample
                    else X[index_X] += k * Y[index_Y];
                }
            }
        }
    }
}
