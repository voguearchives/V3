/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <stdio.h>
#include <assert.h>
#include "inner_c.h"
#include "vector_cpu.h"
#include "vector_cuda.h"
#include "vector_wrapper.h"

float *math21_vector_create_with_default_value_wrapper(size_t n, float value) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_create_with_default_value_cpu(n, value);
#else
    math21_vector_create_with_default_value_cuda(n, value);
#endif
}

float *math21_vector_resize_with_default_value_wrapper(float* v, size_t n, float value){
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_resize_with_default_value_cpu(v, n, value);
#else
    math21_vector_resize_with_default_value_cuda(v, n, value);
#endif
}

// mu = E(X)
// X shape: mini_batch_size*features_size*in_class_size
// rnn: in_class_size=1
// cnn: in_class_size=nr_Y*nc_Y
void
math21_vector_mean_wrapper(const float *X, int mini_batch_size, int features_size, int in_class_size, float *mean) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_mean_cpu(X, mini_batch_size, features_size, in_class_size, mean);
#else
    math21_vector_mean_fast_cuda(X, mini_batch_size, features_size, in_class_size, mean);
#endif
}

void
math21_vector_variance_wrapper(const float *X, const float *mean, int mini_batch_size, int features_size,
                               int in_class_size,
                               float *variance) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_variance_cpu(X, mean, mini_batch_size, features_size, in_class_size, variance);
#else
    math21_vector_variance_fast_cuda(X, mean, mini_batch_size, features_size, in_class_size, variance);
#endif
}

void math21_vector_assign_from_vector_wrapper(int n, const float *x, int stride_x, float *y, int stride_y) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_assign_from_vector_cpu(n, x, stride_x, y, stride_y);
#else
    math21_vector_assign_from_vector_cuda(n, x, stride_x, y, stride_y);
#endif
}

void math21_vector_kx_wrapper(int n, float k, float *x, int stride_x) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_kx_cpu(n, k, x, stride_x);
#else
    math21_vector_kx_cuda(n, k, x, stride_x);
#endif
}

void math21_vector_kx_add_y_wrapper(int n, float k, const float *x, int stride_x, float *y, int stride_y) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_kx_add_y_cpu(n, k, x, stride_x, y, stride_y);
#else
    math21_vector_kx_add_y_cuda(n, k, x, stride_x, y, stride_y);
#endif
}

void math21_vector_normalize_wrapper(float *x, float *mean, float *variance, int mini_batch_size, int features_size,
                                     int in_class_size) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_normalize_cpu(x, mean, variance, mini_batch_size, features_size, in_class_size);
#else
    math21_vector_normalize_cuda(x, mean, variance, mini_batch_size, features_size, in_class_size);
#endif
}

void
math21_vector_kx_with_in_class_wrapper(float *x, const float *k, int mini_batch_size, int features_size,
                                       int in_class_size) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_kx_with_in_class_cpu(x, k, mini_batch_size, features_size, in_class_size);
#else
    math21_vector_kx_with_in_class_cuda(x, k, mini_batch_size, features_size, in_class_size);
#endif
}

void math21_vector_x_add_b_with_in_class_wrapper(float *x, const float *b, int mini_batch_size, int features_size,
                                                 int in_class_size) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_x_add_b_with_in_class_cpu(x, b, mini_batch_size, features_size, in_class_size);
#else
    math21_vector_x_add_b_with_in_class_cuda(x, b, mini_batch_size, features_size, in_class_size);
#endif
}

float math21_vector_sum(const float *x, int n) {
    math21_vector_sum_cpu(x, n);
}

void math21_vector_sum_with_in_class_wrapper(float *db, const float *dY, int mini_batch_size, int features_size,
                                             int in_class_size) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_sum_with_in_class_cpu(db, dY, mini_batch_size, features_size, in_class_size);
#else
    math21_vector_sum_with_in_class_cuda(db, dY, mini_batch_size, features_size, in_class_size);
#endif
}

void math21_vector_sum_SchurProduct_with_in_class_wrapper(float *X, float *dY, int mini_batch_size, int features_size,
                                                          int in_class_size, float *dk) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_sum_SchurProduct_with_in_class_cpu(X, dY, mini_batch_size, features_size, in_class_size, dk);
#else
    math21_vector_sum_SchurProduct_with_in_class_cuda(X, dY, mini_batch_size, features_size, in_class_size, dk);
#endif
}

void math21_vector_set_wrapper(int n, float value, float *X, int stride_x) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_set_cpu(n, value, X, stride_x);
#else
    math21_vector_set_cuda(n, value, X, stride_x);
#endif
}

void math21_vector_feature2d_add_2_wrapper(
        int mini_batch_size,
        float kx, const float *X, int nch_X, int nr_X, int nc_X,
        float ky, float *Y, int nch_Y, int nr_Y, int nc_Y) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_feature2d_add_2_cpu(mini_batch_size,
                                           kx, X, nch_X, nr_X, nc_X,
                                       ky, Y, nch_Y, nr_Y, nc_Y);
#else
    math21_vector_feature2d_add_2_cuda(mini_batch_size,
                                       kx, X, nch_X, nr_X, nc_X,
                                       ky, Y, nch_Y, nr_Y, nc_Y);
#endif
}

void math21_vector_feature2d_add_3_wrapper(
        int mini_batch_size,
        float kx, const float *X, int nch_X, int nr_X, int nc_X,
        float kx2, const float *X2, int nch_X2, int nr_X2, int nc_X2,
        float ky, float *Y, int nch_Y, int nr_Y, int nc_Y) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_feature2d_add_3_cpu(mini_batch_size,
                                       kx, X, nch_X, nr_X, nc_X,
                                       kx2, X2, nch_X2, nr_X2, nc_X2,
                                       ky, Y, nch_Y, nr_Y, nc_Y);
#else
    math21_vector_feature2d_add_3_cuda(mini_batch_size,
                                       kx, X, nch_X, nr_X, nc_X,
                                       kx2, X2, nch_X2, nr_X2, nc_X2,
                                       ky, Y, nch_Y, nr_Y, nc_Y);
#endif
}

void math21_vector_feature2d_sample_wrapper(
        int mini_batch_size,
        float *X, int nch_X, int nr_X, int nc_X, int stride_X, int is_upsample, float k, float *Y) {
#ifndef MATH21_FLAG_USE_CUDA
    math21_vector_feature2d_sample_cpu(
            mini_batch_size, X, nch_X, nr_X, nc_X, stride_X, is_upsample, k, Y);
#else
    math21_vector_feature2d_sample_cuda(
            mini_batch_size, X, nch_X, nr_X, nc_X, stride_X, is_upsample, k, Y);
#endif
}
