/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <cstring>
#include "string.h"
#include "string_c.h"

namespace math21 {
    void math21_string_argv_2_string(int &argc, const char **&argv, Seqce<std::string> &strs, NumN offset) {
        NumZ n = argc - offset;
        if (n <= 0) {
            strs.clear();
            return;
        }
        strs.setSize((NumN) n);
        for (NumN i = 1; i <= strs.size(); ++i) {
            strs(i) = argv[i - 1 + offset];
        }
    }

    void math21_string_2_argv(const Seqce<std::string> &strs, int &argc, const char **&argv, NumN offset) {
        argc = (int) strs.size() - (int) offset;
        if (argc <= 0) {
            argc = 0;
            return;
        }
        argv = (const char **) (new char *[argc]);
        for (NumN i = 1 + offset; i <= strs.size(); ++i) {
            const std::string &str = strs(i);
            auto *cstr = new char[str.length() + 1];
            strcpy(cstr, str.c_str());
            argv[i - 1] = cstr;
        }
    }

    void math21_string_2_argv(const Seqce<std::string> &strs, int &argc, char **&argv, NumN offset) {
        math21_string_2_argv(strs, argc, (const char **&) argv, offset);
    }

    void math21_string_log_argv(const int &argc, const char **argv) {
        m21log(argc);
        for (NumN i = 0; i < argc; ++i) {
            m21log(argv[i]);
        }
    }

    void math21_string_log_argv(const int &argc, char **argv) {
        math21_string_log_argv(argc, (const char **) argv);
    }

    void math21_string_free_argv(const int &argc, const char **&argv) {
        for (NumN i = 0; i < argc; ++i) {
            delete[] argv[i];
        }
        delete[] argv;
    }

    void math21_string_free_argv(const int &argc, char **&argv) {
        math21_string_free_argv(argc, (const char **&) argv);
    }

    NumB math21_string_find_last(const char *path, char c, NumZ &index0) {
        NumZ size, index;
        size = 0;
        index = -1;
        index0 = 0;
        MATH21_ASSERT(path != 0 && "path is null");
        while (path[size] != '\0') {
            if (path[size] == c) {
                index = size;
            }
            size++;
        }
        if (index != -1) {
            index0 = index;
            return 1;
        }
        return 0;
    }

}

using namespace math21;

NumN math21_string_length(const char *s) {
    NumN i = 0;
    MATH21_ASSERT(s)
    while (s[i] != '\0')
        ++i;
    return i;
}

NumB _math21_string_get_file_name(const char *s, char *buffer, NumN bufferSize, NumB isRemoveSuffix) {
    NumZ index;
    NumZ s_size = math21_string_length(s);
    NumB flag = math21_string_find_last(s, '/', index);

    // if not find, we return s directly.
    if (flag == 0) {
        return 0;
    }

    NumZ nameSize = s_size - 1 - index;

    // if find, but at end, return empty.
    if (nameSize == 0) {
        return 0;
    }

    if (nameSize + 1 > bufferSize) {
        printf("buffer not enough!\n");
        return 0;
    }
    memcpy(buffer, s + index + 1, nameSize);
    buffer[nameSize] = 0;

    if (isRemoveSuffix) {
        flag = math21_string_find_last(buffer, '.', index);

        // if not find, we return s directly.
        if (flag == 0) {
            return 1;
        }
        buffer[index] = 0;
    }
    return 1;
}

NumB math21_string_get_file_name(const char *s, char *buffer, NumN bufferSize) {
    return _math21_string_get_file_name(s, buffer, bufferSize, 0);
}

NumB math21_string_get_file_name_without_suffix(const char *s, char *buffer, NumN bufferSize) {
    return _math21_string_get_file_name(s, buffer, bufferSize, 1);
}
