/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>


#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t NumN8;
typedef int8_t NumZ8; // 8 bit integer
typedef uint32_t NumN32;
typedef int32_t NumZ32; // 32 bit integer

// Type used:
typedef NumZ32 NumZ;
typedef NumN32 NumN;
typedef double NumR; // default floating type

// Type not used
typedef NumN32 NumB;


#define MATH21_TIME_MAX (10000000)
#define MATH21_OPT_TIME_MAX (10000000)
#define XJ_TRUE 1
#define XJ_FALSE 0

#define MATH21_EPS2 (1e-10)
#define MATH21_EPS (0.000001)
#define MATH21_10NEG6 (0.000001)
#define MATH21_10NEG7 (0.0000001)
#define MATH21_EPS_NEG (-0.000001)
#define XJ_EPS (0.000001)
#define XJ_PI (3.14159265357989323)
#define XJ_MAX (10000000)
#define XJ_MIN (-10000000)
#define MATH21_GPU_BLOCK_SIZE 16
#define MATH21_CUDA_BLOCK_SIZE 512 // number of threads per dimension of block

#ifdef __cplusplus
}
#endif
