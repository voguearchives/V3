/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include <fstream>
#include "inner.h"
#include "number.h"
#include "_assert.h"

namespace math21 {
    enum {
        math21_type_default = 1,
        math21_type_NumN,
        math21_type_NumZ,
        math21_type_NumR,
        math21_type_Seqce,
        math21_type_Tensor,
        math21_type_Digraph,
    };

    class SerializeNumInterface {
    public:
        SerializeNumInterface() {}

        virtual void serialize(std::ostream &out, const NumN &m) = 0;

        virtual void serialize(std::ostream &out, const NumZ &m) = 0;

        virtual void serialize(std::ostream &out, const NumR &m) = 0;
    };

    class DeserializeNumInterface {
    public:
        DeserializeNumInterface() {}

        virtual void deserialize(std::istream &in, NumN &m) = 0;

        virtual void deserialize(std::istream &in, NumZ &m) = 0;

        virtual void deserialize(std::istream &in, NumR &m) = 0;
    };

    class SerializeNumInterface_simple : public SerializeNumInterface {
    public:
        SerializeNumInterface_simple() {}

        void serialize(std::ostream &out, const NumN &m) {
            out.write((const char *) &m, sizeof(m));
        }

        void serialize(std::ostream &out, const NumZ &m) {
            out.write((const char *) &m, sizeof(m));
        }

        void serialize(std::ostream &out, const NumR &m) {
            out.write((const char *) &m, sizeof(m));
        }
    };

    class DeserializeNumInterface_simple : public DeserializeNumInterface {
    public:
        DeserializeNumInterface_simple() {}

        void deserialize(std::istream &in, NumN &m) {
            in.read((char *) &m, sizeof(m));
        }

        void deserialize(std::istream &in, NumZ &m) {
            in.read((char *) &m, sizeof(m));
        }

        void deserialize(std::istream &in, NumR &m) {
            in.read((char *) &m, sizeof(m));
        }
    };

    class SerializeNumInterface_text : public SerializeNumInterface {
    public:
        SerializeNumInterface_text() {}

        void serialize(std::ostream &out, const NumN &m) {
            out << m << std::endl;
        }

        void serialize(std::ostream &out, const NumZ &m) {
            out << m << std::endl;
        }

        void serialize(std::ostream &out, const NumR &m) {
            out << m << std::endl;
        }
    };

    class DeserializeNumInterface_text : public DeserializeNumInterface {
    public:
        DeserializeNumInterface_text() {}

        void deserialize(std::istream &in, NumN &m) {
            in >> m;
        }

        void deserialize(std::istream &in, NumZ &m) {
            in >> m;
        }

        void deserialize(std::istream &in, NumR &m) {
            in >> m;
        }
    };

    NumN math21_type_get(const NumN &m);

    NumN math21_type_get(const NumZ &m);

    NumN math21_type_get(const NumR &m);

    void math21_io_serialize(std::ostream &out, const NumN &m, SerializeNumInterface &sn);

    void math21_io_serialize(std::ostream &out, const NumZ &m, SerializeNumInterface &sn);

    void math21_io_serialize(std::ostream &out, const NumR &m, SerializeNumInterface &sn);

    void math21_io_serialize_header(std::ostream &out, SerializeNumInterface &sn);

    void math21_io_serialize(std::ostream &out, const std::string &m, SerializeNumInterface &sn);

    void math21_io_deserialize(std::istream &in, NumN &m, DeserializeNumInterface &sn);

    void math21_io_deserialize(std::istream &in, NumZ &m, DeserializeNumInterface &sn);

    void math21_io_deserialize(std::istream &in, NumR &m, DeserializeNumInterface &sn);

    NumB math21_io_deserialize_header(std::istream &in, DeserializeNumInterface &sn);

    void math21_io_deserialize(std::istream &in, std::string &m, DeserializeNumInterface &sn);

    NumN math21_io_read_file(const char *path, NumN8 *&data, size_t size);

    NumN math21_io_write_file(const char *path, const NumN8 *data, size_t size);

    void math21_io_serialize_type(std::ostream &out, SerializeNumInterface &sn,
                                  const NumN &type);

    NumB math21_io_deserialize_type(std::istream &in, DeserializeNumInterface &dsn, NumN &type);

    NumB math21_io_read_type_from_file(const char *path, NumN &type);

    template<typename T>
    NumB math21_io_generic_type_write_to_file(const T &A, const char *path, NumB isUseHeader = 1, NumB binary = 1) {
        NumB flag = 1;
        std::ofstream out;

        SerializeNumInterface *p_sn;
        SerializeNumInterface_text sn_text;
        SerializeNumInterface_simple sn_bin;
        if (!binary) {
            p_sn = &sn_text;
        } else {
            p_sn = &sn_bin;
        }
        SerializeNumInterface &sn = *p_sn;

        if (!binary) {
            out.open(path);
        } else {
            out.open(path, std::ofstream::binary);
        }

        if (out.is_open()) {
            if (isUseHeader) {
                NumN type;
                type = math21_type_get(A);
                math21_io_serialize_type(out, sn, type);
            }
            math21_io_serialize(out, A, sn);
        } else {
            printf("open %s fail!\n", path);
            flag = 0;
        }
        out.close();
        return flag;
    }

    template<typename T>
    NumB math21_io_generic_type_read_from_file(T &A, const char *path, NumB isUseHeader = 1, NumB binary = 1) {
        NumB flag = 1;
        std::ifstream in;

        DeserializeNumInterface *p_sn;
        DeserializeNumInterface_text sn_text;
        DeserializeNumInterface_simple sn_bin;
        if (!binary) {
            p_sn = &sn_text;
        } else {
            p_sn = &sn_bin;
        }
        DeserializeNumInterface &dsn = *p_sn;

        if (!binary) {
            in.open(path);
        } else {
            in.open(path, std::ifstream::binary);
        }

        if (in.is_open()) {
            if (isUseHeader) {
                NumN type;
                flag = math21_io_deserialize_type(in, dsn, type);
                if (!flag) {
                    in.close();
                    return 0;
                }
                if (type != math21_type_get(A)) {
                    in.close();
                    return 0;
                }
            }
            math21_io_deserialize(in, A, dsn);
        } else {
            printf("open %s fail!\n", path);
            flag = 0;
        }
        in.close();
        return flag;
    }
}