/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "inner_c.h"

typedef struct mlfunction_batchnorm mlfunction_batchnorm;

struct mlfunction_batchnorm {
    int is_this_type;

//    void (*forward)(struct layer, struct network);
//    void (*backward)(struct layer, struct network);

//    void (*update)(struct layer, update_args);

    float *input; // net input
    int is_train; // is train

    int batch_normalize; // is_batch_normalize
    int outputs; // y_size, no batch
    int mini_batch_size; // mini_batch_size
    float *output; // Y
    float *x; // ?
//    int features_size;
    int out_c; // features_size
    int in_class_size;
    float *mean;
    float *variance;
    float *mean_delta;
    float *variance_delta;
    float *rolling_mean;
    float *rolling_variance;
    float *x_norm;
    float * biases; // b
    float * bias_updates; // dL/db
    float * scales;
    float * scale_updates;

    float * delta; // dL/dY
    int out_h, out_w; // nr_Y, nc_Y, nch_Y
    float *net_delta;
    int h,w,c; // nr_X, nc_X, nch_X
    int inputs; // x_size, no batch
};

void math21_ml_function_batchnorm_forward(mlfunction_batchnorm l);

void math21_ml_function_batchnorm_backward(mlfunction_batchnorm l);

void math21_ml_batch_normalization_scale_backward(float *X, float *dY, int mini_batch_size, int features_size, int in_class_size, float *dk);

void math21_ml_batchnormalization_backward_mu_wrapper(const float *dX_hat, const float *variance, int mini_batch_size, int features_size, int in_class_size, float *dmu);

void math21_ml_batchnormalization_backward_sigma_square_wrapper(const float *X, const float *dX_hat, const float *mu, const float *variance, int mini_batch_size, int features_size, int in_class_size, float *dvariance);

void math21_ml_batchnormalization_backward_input_wrapper(const float *X, const float *mu, const float *variance, const float *dmu, const float *dvariance, int mini_batch_size, int features_size, int in_class_size, float *dX_hat);

#ifdef __cplusplus
}
#endif
