/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <stdio.h>
#include "batch_normalization_cpu.h"
#include "batch_normalization_cuda.h"
#include "batch_normalization.h"
#include "../conv.h"


mlfunction_batchnorm math21_ml_function_batchnorm_create(int mini_batch_size, int w, int h, int c)
{
    fprintf(stdout, "Batch Normalization Layer: %d x %d x %d image\n", w,h,c);
    mlfunction_batchnorm l = {0};
    l.is_this_type = 1;
    l.mini_batch_size = mini_batch_size;
    l.h = l.out_h = h;
    l.w = l.out_w = w;
    l.c = l.out_c = c;

    l.inputs = w*h*c;
    l.outputs = l.inputs;


    l.output = math21_vector_calloc_cpu(h * w * c * mini_batch_size, sizeof(float));
    l.delta  = math21_vector_calloc_cpu(h * w * c * mini_batch_size, sizeof(float));

    l.biases = math21_vector_calloc_cpu(c, sizeof(float));
    l.bias_updates = math21_vector_calloc_cpu(c, sizeof(float));
    l.scales = math21_vector_calloc_cpu(c, sizeof(float));
    l.scale_updates = math21_vector_calloc_cpu(c, sizeof(float));
    int i;
    for(i = 0; i < c; ++i){
        l.scales[i] = 1;
    }

    l.mean = math21_vector_calloc_cpu(c, sizeof(float));
    l.variance = math21_vector_calloc_cpu(c, sizeof(float));

    l.rolling_mean = math21_vector_calloc_cpu(c, sizeof(float));
    l.rolling_variance = math21_vector_calloc_cpu(c, sizeof(float));

//    l.forward = math21_ml_net_batchnorm_layer_forward;
//    l.backward = math21_ml_net_batchnorm_layer_backward;
#ifdef MATH21_FLAG_USE_CUDA

    l.output =  math21_cuda_vector_create_with_value_from_cpu(l.output, h * w * c * mini_batch_size);
    l.delta =   math21_cuda_vector_create_with_value_from_cpu(l.delta, h * w * c * mini_batch_size);

    l.biases = math21_cuda_vector_create_with_value_from_cpu(l.biases, c);
    l.bias_updates = math21_cuda_vector_create_with_value_from_cpu(l.bias_updates, c);

    l.scales = math21_cuda_vector_create_with_value_from_cpu(l.scales, c);
    l.scale_updates = math21_cuda_vector_create_with_value_from_cpu(l.scale_updates, c);

    l.mean = math21_cuda_vector_create_with_value_from_cpu(l.mean, c);
    l.variance = math21_cuda_vector_create_with_value_from_cpu(l.variance, c);

    l.rolling_mean = math21_cuda_vector_create_with_value_from_cpu(l.mean, c);
    l.rolling_variance = math21_cuda_vector_create_with_value_from_cpu(l.variance, c);

    l.mean_delta = math21_cuda_vector_create_with_value_from_cpu(l.mean, c);
    l.variance_delta = math21_cuda_vector_create_with_value_from_cpu(l.variance, c);

    l.x = math21_cuda_vector_create_with_value_from_cpu(l.output, l.mini_batch_size*l.outputs);
    l.x_norm = math21_cuda_vector_create_with_value_from_cpu(l.output, l.mini_batch_size*l.outputs);

#endif
    return l;
}

// Y = BN(X)
void math21_ml_function_batchnorm_forward(mlfunction_batchnorm l)
{
    // not for fully connected layer
    if(l.is_this_type) math21_vector_assign_from_vector_wrapper(l.outputs*l.mini_batch_size, l.input, 1, l.output, 1);
    // get X for what
    math21_vector_assign_from_vector_wrapper(l.outputs*l.mini_batch_size, l.output, 1, l.x, 1);
    if(l.is_train){
        // mu = E(X) for rnn, cnn
        math21_vector_mean_wrapper(l.output, l.mini_batch_size, l.out_c, l.in_class_size, l.mean);
        // sigma_square = Var(X)
        math21_vector_variance_wrapper(l.output, l.mean, l.mini_batch_size, l.out_c, l.in_class_size, l.variance);

        // update rolling mean
        math21_vector_kx_wrapper(l.out_c, .99, l.rolling_mean, 1);
        math21_vector_kx_add_y_wrapper(l.out_c, .01, l.mean, 1, l.rolling_mean, 1);
        // update rolling variance
        math21_vector_kx_wrapper(l.out_c, .99, l.rolling_variance, 1);
        math21_vector_kx_add_y_wrapper(l.out_c, .01, l.variance, 1, l.rolling_variance, 1);


#ifdef MATH21_FLAG_USE_CUDA
        // get X for what
        math21_vector_assign_from_vector_wrapper(l.outputs*l.mini_batch_size, l.output, 1, l.x, 1);
#endif

        // X_hat = (X-mu)/sigma
        math21_vector_normalize_wrapper(l.output, l.mean, l.variance, l.mini_batch_size, l.out_c, l.in_class_size);
        // get X_norm for what
        math21_vector_assign_from_vector_wrapper(l.outputs*l.mini_batch_size, l.output, 1, l.x_norm, 1);
    } else {
        math21_vector_normalize_wrapper(l.output, l.rolling_mean, l.rolling_variance, l.mini_batch_size, l.out_c, l.in_class_size);
    }

    // Y = scale * X_hat + bias
    math21_vector_kx_with_in_class_wrapper(l.output, l.scales, l.mini_batch_size, l.out_c, l.in_class_size);
    math21_vector_x_add_b_with_in_class_wrapper(l.output, l.biases, l.mini_batch_size, l.out_c, l.in_class_size);
}

void math21_ml_function_batchnorm_backward(mlfunction_batchnorm l)
{
    if(!l.is_train){
        l.mean = l.rolling_mean;
        l.variance = l.rolling_variance;
    }
    // dL/db += sum(dL/dY(i))
    math21_ml_conv_bias_backward(l.bias_updates, l.delta, l.mini_batch_size, l.out_c, l.out_w*l.out_h);
    // dL/dk += sum(dL/dY(i) *.ele X_hat(i))
    math21_ml_batch_normalization_scale_backward(l.x_norm, l.delta, l.mini_batch_size, l.out_c, l.out_w*l.out_h, l.scale_updates);
    // dL/dX_hat = dL/dY * k
    math21_vector_kx_with_in_class_wrapper(l.delta, l.scales, l.mini_batch_size, l.out_c, l.out_h*l.out_w);
    // Todo: sum(dL/dX_hat(i) * dX_hat(i)/dmu) + dL/dsigma_square * dsigma_square/dmu
    math21_ml_batchnormalization_backward_mu_wrapper(l.delta, l.variance, l.mini_batch_size, l.out_c, l.out_w*l.out_h, l.mean_delta);
    // dL/dsigma_square = sum(dL/dX_hat(i) * dX_hat(i)/dsigma_square)
    math21_ml_batchnormalization_backward_sigma_square_wrapper(l.x, l.delta, l.mean, l.variance, l.mini_batch_size, l.out_c, l.out_w*l.out_h, l.variance_delta);
    // dL/dX
    math21_ml_batchnormalization_backward_input_wrapper(l.x, l.mean, l.variance, l.mean_delta, l.variance_delta, l.mini_batch_size, l.out_c, l.out_w*l.out_h, l.delta);
    if(l.is_this_type) math21_vector_assign_from_vector_wrapper(l.outputs*l.mini_batch_size, l.delta, 1, l.net_delta, 1);
}

void math21_ml_batch_normalization_scale_backward(float *X, float *dY, int mini_batch_size, int features_size, int in_class_size, float *dk){
    math21_vector_sum_SchurProduct_with_in_class_wrapper(X, dY, mini_batch_size, features_size, in_class_size, dk);
}

// error: dL/dmu = sum(dL/dX_hat(i) * dX_hat(i)/dmu)
// Todo: dL/dmu = sum(dL/dX_hat(i) * dX_hat(i)/dmu) + dL/dsigma_square * dsigma_square/dmu
void math21_ml_batchnormalization_backward_mu_wrapper(const float *dX_hat, const float *variance, int mini_batch_size, int features_size, int in_class_size, float *dmu)
{
#ifndef MATH21_FLAG_USE_CUDA
    math21_ml_batchnormalization_backward_mu_cpu(dX_hat, variance, mini_batch_size, features_size, in_class_size, dmu);
#else
    math21_ml_batchnormalization_backward_mu_fast_cuda(dX_hat, variance, mini_batch_size, features_size, in_class_size, dmu);
#endif
}

void math21_ml_batchnormalization_backward_sigma_square_wrapper(const float *X, const float *dX_hat, const float *mu, const float *variance, int mini_batch_size, int features_size, int in_class_size, float *dvariance)
{
#ifndef MATH21_FLAG_USE_CUDA
    math21_ml_batchnormalization_backward_sigma_square_cpu(X, dX_hat, mu, variance, mini_batch_size, features_size, in_class_size, dvariance);
#else
    math21_ml_batchnormalization_backward_sigma_square_fast_cuda(X, dX_hat, mu, variance, mini_batch_size, features_size, in_class_size, dvariance);
#endif
}

void math21_ml_batchnormalization_backward_input_wrapper(const float *X, const float *mu, const float *variance, const float *dmu, const float *dvariance, int mini_batch_size, int features_size, int in_class_size, float *dX_hat)
{
#ifndef MATH21_FLAG_USE_CUDA
    math21_ml_batchnormalization_backward_input_cpu(X, mu, variance, dmu, dvariance, mini_batch_size, features_size, in_class_size, dX_hat);
#else
    math21_ml_batchnormalization_backward_input_cuda(X, mu, variance, dmu, dvariance, mini_batch_size, features_size, in_class_size, dX_hat);
#endif
}