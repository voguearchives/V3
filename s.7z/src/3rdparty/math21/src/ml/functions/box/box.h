/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include "inner_c.h"

#ifdef __cplusplus
extern "C" {
#endif

// (x, y) is box center
struct mlbox{
    float x, y, w, h;
};

typedef struct mlbox mlbox;

struct mldbox{
    float dx, dy, dw, dh;
};

typedef struct mldbox mldbox;

struct mldetection{
    mlbox bbox;
    int classes;
    float *prob;
    float *mask;
    float objectness;
    int sort_class;
};

typedef struct mldetection mldetection;

void math21_ml_box_do_nms_obj(mldetection *dets, int total, int classes, float thresh);
void math21_ml_box_do_nms_sort(mldetection *dets, int total, int classes, float thresh);
float math21_ml_box_rmse(mlbox a, mlbox b);
mlbox math21_ml_box_vector_to_box(float *f, int stride);
float math21_ml_box_iou(mlbox a, mlbox b);

#ifdef __cplusplus
}
#endif
