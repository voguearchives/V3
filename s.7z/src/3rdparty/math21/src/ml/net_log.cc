///* Copyright 2015 The math21 Authors. All Rights Reserved.
//
//Licensed under the Apache License, Version 2.0 (the "License");
//you may not use this file except in compliance with the License.
//You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
//Unless required by applicable law or agreed to in writing, software
//distributed under the License is distributed on an "AS IS" BASIS,
//WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//See the License for the specific language governing permissions and
//limitations under the License.
//==============================================================================*/
//
//#include "inner.h"
//#include "net_log_c.h"
//
//using namespace math21;
//
//void math21_ml_net_log_layer(const layer *pl) {
//    if (!pl) {
//        printf("layer is null\n");
//        return;
//    }
//
//    const layer &l = *pl;
//    MATH21_LOG_NAME_VALUE(l.type);
//    MATH21_LOG_NAME_VALUE(l.activation);
//    MATH21_LOG_NAME_VALUE(l.cost_type);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forward);
//    MATH21_LOG_NAME_VALUE_POINTER(l.backward);
//    MATH21_LOG_NAME_VALUE_POINTER(l.update);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forward_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.backward_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.update_gpu);
//    MATH21_LOG_NAME_VALUE(l.batch_normalize);
//    MATH21_LOG_NAME_VALUE(l.shortcut);
//    MATH21_LOG_NAME_VALUE(l.batch);
//    MATH21_LOG_NAME_VALUE(l.forced);
//    MATH21_LOG_NAME_VALUE(l.flipped);
//    MATH21_LOG_NAME_VALUE(l.inputs);
//    MATH21_LOG_NAME_VALUE(l.outputs);
//    MATH21_LOG_NAME_VALUE(l.nweights);
//    MATH21_LOG_NAME_VALUE(l.extra);
//    MATH21_LOG_NAME_VALUE(l.truths);
//    MATH21_LOG_NAME_VALUE(l.h);
//    MATH21_LOG_NAME_VALUE(l.w);
//    MATH21_LOG_NAME_VALUE(l.c);
//    MATH21_LOG_NAME_VALUE(l.out_h);
//    MATH21_LOG_NAME_VALUE(l.out_w);
//    MATH21_LOG_NAME_VALUE(l.out_c);
//    MATH21_LOG_NAME_VALUE(l.n);
//    MATH21_LOG_NAME_VALUE(l.max_boxes);
//    MATH21_LOG_NAME_VALUE(l.groups);
//    MATH21_LOG_NAME_VALUE(l.size);
//    MATH21_LOG_NAME_VALUE(l.side);
//    MATH21_LOG_NAME_VALUE(l.stride);
//    MATH21_LOG_NAME_VALUE(l.reverse);
//    MATH21_LOG_NAME_VALUE(l.flatten);
//    MATH21_LOG_NAME_VALUE(l.spatial);
//    MATH21_LOG_NAME_VALUE(l.pad);
//    MATH21_LOG_NAME_VALUE(l.sqrt);
//    MATH21_LOG_NAME_VALUE(l.flip);
//    MATH21_LOG_NAME_VALUE(l.index);
//    MATH21_LOG_NAME_VALUE(l.binary);
//    MATH21_LOG_NAME_VALUE(l.xnor);
//    MATH21_LOG_NAME_VALUE(l.steps);
//    MATH21_LOG_NAME_VALUE(l.hidden);
//    MATH21_LOG_NAME_VALUE(l.truth);
//    MATH21_LOG_NAME_VALUE(l.smooth);
//    MATH21_LOG_NAME_VALUE(l.dot);
//    MATH21_LOG_NAME_VALUE(l.angle);
//    MATH21_LOG_NAME_VALUE(l.jitter);
//    MATH21_LOG_NAME_VALUE(l.saturation);
//    MATH21_LOG_NAME_VALUE(l.exposure);
//    MATH21_LOG_NAME_VALUE(l.shift);
//    MATH21_LOG_NAME_VALUE(l.ratio);
//    MATH21_LOG_NAME_VALUE(l.learning_rate_scale);
//    MATH21_LOG_NAME_VALUE(l.clip);
//    MATH21_LOG_NAME_VALUE(l.noloss);
//    MATH21_LOG_NAME_VALUE(l.softmax);
//    MATH21_LOG_NAME_VALUE(l.classes);
//    MATH21_LOG_NAME_VALUE(l.coords);
//    MATH21_LOG_NAME_VALUE(l.background);
//    MATH21_LOG_NAME_VALUE(l.rescore);
//    MATH21_LOG_NAME_VALUE(l.objectness);
//    MATH21_LOG_NAME_VALUE(l.joint);
//    MATH21_LOG_NAME_VALUE(l.noadjust);
//    MATH21_LOG_NAME_VALUE(l.reorg);
//    MATH21_LOG_NAME_VALUE(l.log);
//    MATH21_LOG_NAME_VALUE(l.tanh);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.mask);
//    MATH21_LOG_NAME_VALUE_POINTER(l.mask);
//    MATH21_LOG_NAME_VALUE(l.total);
//    MATH21_LOG_NAME_VALUE(l.alpha);
//    MATH21_LOG_NAME_VALUE(l.beta);
//    MATH21_LOG_NAME_VALUE(l.kappa);
//    MATH21_LOG_NAME_VALUE(l.coord_scale);
//    MATH21_LOG_NAME_VALUE(l.object_scale);
//    MATH21_LOG_NAME_VALUE(l.noobject_scale);
//    MATH21_LOG_NAME_VALUE(l.mask_scale);
//    MATH21_LOG_NAME_VALUE(l.class_scale);
//    MATH21_LOG_NAME_VALUE(l.bias_match);
//    MATH21_LOG_NAME_VALUE(l.random);
//    MATH21_LOG_NAME_VALUE(l.ignore_thresh);
//    MATH21_LOG_NAME_VALUE(l.truth_thresh);
//    MATH21_LOG_NAME_VALUE(l.thresh);
//    MATH21_LOG_NAME_VALUE(l.focus);
//    MATH21_LOG_NAME_VALUE(l.classfix);
//    MATH21_LOG_NAME_VALUE(l.absolute);
//    MATH21_LOG_NAME_VALUE(l.onlyforward);
//    MATH21_LOG_NAME_VALUE(l.stopbackward);
//    MATH21_LOG_NAME_VALUE(l.dontload);
//    MATH21_LOG_NAME_VALUE(l.dontsave);
//    MATH21_LOG_NAME_VALUE(l.dontloadscales);
//    MATH21_LOG_NAME_VALUE(l.numload);
//    MATH21_LOG_NAME_VALUE(l.temperature);
//    MATH21_LOG_NAME_VALUE(l.probability);
//    MATH21_LOG_NAME_VALUE(l.scale);
//
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.cweights);
//    MATH21_LOG_NAME_VALUE_POINTER(l.cweights);
//    MATH21_LOG_NAME_VALUE(l.indexes);
//    MATH21_LOG_NAME_VALUE_POINTER(l.indexes);
//    MATH21_LOG_NAME_VALUE_POINTER(l.input_layers);
//    MATH21_LOG_NAME_VALUE_POINTER(l.input_sizes);
//    MATH21_LOG_NAME_VALUE_POINTER(l.map);
//    MATH21_LOG_NAME_VALUE_POINTER(l.counts);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.sums);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rand);
//    MATH21_LOG_NAME_VALUE_POINTER(l.cost);
//    MATH21_LOG_NAME_VALUE_POINTER(l.state);
//    MATH21_LOG_NAME_VALUE_POINTER(l.prev_state);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forgot_state);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forgot_delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.state_delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.combine_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.combine_delta_cpu);
//
//    MATH21_LOG_NAME_VALUE_POINTER(l.concat);
//    MATH21_LOG_NAME_VALUE_POINTER(l.concat_delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.binary_weights);
//    MATH21_LOG_NAME_VALUE_POINTER(l.biases);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_updates);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scales);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_updates);
//    MATH21_LOG_NAME_VALUE_POINTER(l.weights);
//    MATH21_LOG_NAME_VALUE_POINTER(l.weight_updates);
//    MATH21_LOG_NAME_VALUE_POINTER(l.delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.output);
//    MATH21_LOG_NAME_VALUE_POINTER(l.loss);
//    MATH21_LOG_NAME_VALUE_POINTER(l.squared);
//    MATH21_LOG_NAME_VALUE_POINTER(l.norms);
//    MATH21_LOG_NAME_VALUE_POINTER(l.spatial_mean);
//    MATH21_LOG_NAME_VALUE_POINTER(l.mean);
//    MATH21_LOG_NAME_VALUE_POINTER(l.variance);
//    MATH21_LOG_NAME_VALUE_POINTER(l.mean_delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.variance_delta);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rolling_mean);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rolling_variance);
//    MATH21_LOG_NAME_VALUE_POINTER(l.x);
//    MATH21_LOG_NAME_VALUE_POINTER(l.x_norm);
//    MATH21_LOG_NAME_VALUE_POINTER(l.m);
//    MATH21_LOG_NAME_VALUE_POINTER(l.v);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_m);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_v);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_m);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_v);
//    MATH21_LOG_NAME_VALUE_POINTER(l.z_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.r_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.h_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.prev_state_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp2_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp3_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.dh_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.hh_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.prev_cell_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.cell_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.f_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.i_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.g_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.o_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.c_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.dc_cpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.binary_input);
//
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.self_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.output_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.reset_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.update_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_gate_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_gate_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_save_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_save_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_state_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_state_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_z_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_z_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_r_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_r_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.input_h_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.state_h_layer);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wz);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.uz);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wr);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.ur);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wh);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.uh);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.uo);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wo);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.uf);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wf);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.ui);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wi);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.ug);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.wg);
//    MATH21_LOG_NAME_VALUE_POINTER_ONLY(l.softmax_tree);
//    MATH21_LOG_NAME_VALUE(l.workspace_size);
//
//#ifdef GPU
//    MATH21_LOG_NAME_VALUE_POINTER(l.indexes_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.z_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.r_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.h_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp2_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.temp3_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.dh_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.hh_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.prev_cell_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.cell_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.f_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.i_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.g_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.o_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.c_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.dc_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.m_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.v_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_m_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_m_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_v_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_v_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.combine_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.combine_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.prev_state_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forgot_state_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.forgot_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.state_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.state_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.gate_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.gate_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.save_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.save_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.concat_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.concat_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.binary_input_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.binary_weights_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.mean_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.variance_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rolling_mean_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rolling_variance_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.variance_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.mean_delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.x_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.x_norm_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.weights_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.weight_updates_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.weight_change_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.biases_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_updates_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.bias_change_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scales_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_updates_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.scale_change_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.output_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.loss_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.rand_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.squared_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(l.norms_gpu);
//#endif
//}
//
//void math21_ml_net_log(const network *pnet) {
//    if (!pnet) {
//        printf("net is null\n");
//        return;
//    }
//
//    const network &net = *pnet;
//    MATH21_LOG_NAME_VALUE(net.n);
//    MATH21_LOG_NAME_VALUE(net.batch);
//    MATH21_LOG_NAME_VALUE_POINTER(net.seen);
//    MATH21_LOG_NAME_VALUE_POINTER(net.t);
//    MATH21_LOG_NAME_VALUE(net.epoch);
//    MATH21_LOG_NAME_VALUE(net.subdivisions);
//    MATH21_LOG_NAME_VALUE(net.layers);
//    MATH21_LOG_NAME_VALUE_POINTER(net.output);
//    MATH21_LOG_NAME_VALUE(net.policy);
//    MATH21_LOG_NAME_VALUE(net.learning_rate);
//    MATH21_LOG_NAME_VALUE(net.momentum);
//    MATH21_LOG_NAME_VALUE(net.decay);
//    MATH21_LOG_NAME_VALUE(net.gamma);
//    MATH21_LOG_NAME_VALUE(net.scale);
//    MATH21_LOG_NAME_VALUE(net.power);
//    MATH21_LOG_NAME_VALUE(net.time_steps);
//    MATH21_LOG_NAME_VALUE(net.step);
//    MATH21_LOG_NAME_VALUE(net.max_batches);
//
//    if (net.policy == STEPS) {
//        NumN size = net.num_steps;
//        MATH21_LOG_NAME_VALUE(net.num_steps);
//        MATH21_LOG_NAME_VALUE(net.scales);
//        math21::math21_tool_log_c_array(net.scales, size);
//        MATH21_LOG_NAME_VALUE(net.steps);
//        math21::math21_tool_log_c_array(net.steps, size);
//    } else {
//        MATH21_LOG_NAME_VALUE(net.num_steps);
//        MATH21_LOG_NAME_VALUE_POINTER(net.scales);
//        MATH21_LOG_NAME_VALUE_POINTER(net.steps);
//    }
//    MATH21_LOG_NAME_VALUE(net.burn_in);
//    MATH21_LOG_NAME_VALUE(net.adam);
//    MATH21_LOG_NAME_VALUE(net.B1);
//    MATH21_LOG_NAME_VALUE(net.B2);
//    MATH21_LOG_NAME_VALUE(net.eps);
//    MATH21_LOG_NAME_VALUE(net.inputs);
//    MATH21_LOG_NAME_VALUE(net.outputs);
//    MATH21_LOG_NAME_VALUE(net.truths);
//    MATH21_LOG_NAME_VALUE(net.notruth);
//    MATH21_LOG_NAME_VALUE(net.h);
//    MATH21_LOG_NAME_VALUE(net.w);
//    MATH21_LOG_NAME_VALUE(net.c);
//    MATH21_LOG_NAME_VALUE(net.max_crop);
//    MATH21_LOG_NAME_VALUE(net.min_crop);
//    MATH21_LOG_NAME_VALUE(net.max_ratio);
//    MATH21_LOG_NAME_VALUE(net.min_ratio);
//    MATH21_LOG_NAME_VALUE(net.center);
//    MATH21_LOG_NAME_VALUE(net.angle);
//    MATH21_LOG_NAME_VALUE(net.aspect);
//    MATH21_LOG_NAME_VALUE(net.exposure);
//    MATH21_LOG_NAME_VALUE(net.saturation);
//    MATH21_LOG_NAME_VALUE(net.hue);
//    MATH21_LOG_NAME_VALUE(net.random);
//    MATH21_LOG_NAME_VALUE(net.gpu_index);
//    MATH21_LOG_NAME_VALUE(net.hierarchy);
//    MATH21_LOG_NAME_VALUE_POINTER(net.input);
//    MATH21_LOG_NAME_VALUE_POINTER(net.truth);
//    MATH21_LOG_NAME_VALUE_POINTER(net.delta);
//    MATH21_LOG_NAME_VALUE_POINTER(net.workspace);
//    MATH21_LOG_NAME_VALUE(net.train);
//    MATH21_LOG_NAME_VALUE(net.index);
//    MATH21_LOG_NAME_VALUE_POINTER(net.cost);
//    MATH21_LOG_NAME_VALUE(net.clip);
//
//#ifdef GPU
//    MATH21_LOG_NAME_VALUE_POINTER(net.input_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(net.truth_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(net.delta_gpu);
//    MATH21_LOG_NAME_VALUE_POINTER(net.output_gpu);
//#endif
//
//}
