# A simple, small, math library in the 21th century.

# Change log
* 2014.07.14
float representation, uniform representation of numbers.
* 2014.05.01
serialize, deserialize.
* 2013 mlp, cnn
* 2012 optimization
* 2011 matrix design using template.
* 2010 matrix design
