#pragma once

#include <math21_feature_config.h>

#define STAR_FLAG_USE_PNG
#define STAR_FLAG_USE_JPEG
#define STAR_FLAG_USE_BMP

#define STAR_ALGORITHM_SPEED
